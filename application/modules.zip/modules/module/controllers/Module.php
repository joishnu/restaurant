<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * @author Bimlesh
 *
 */
class Module extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('module_model','module');

	}
	public function add(){
		$data['title'] = 'Module';
        $data['list']=$this->module->module_result();
		$data['page'] = 'add';       
		$this->load->view('template',$data);
	}
    public function edit($id=""){
        $data['title'] = 'Edit Module';
        $data['list']=$this->module->module_results($id);
        $data['page'] = 'edit';       
        $this->load->view('template',$data);
    }


	public function add_module(){
        $this->form_validation->set_rules('module_name','module_name','trim|required');
        $info = $this->input->post(NULL,true);
        if($this->form_validation->run()) {
        $rs = $this->module->do_add_module($info);
        if($rs) {
        $this->session->set_flashdata('success', 'Module has been updated successfully');
        redirect(site_url('module/add'));
        } 
        else {
        $this->session->set_flashdata('error', 'Some error occurred. Please try again.');
        }
        } 
        else {
        $this->session->set_flashdata('error',validation_errors());
        }
        redirect(site_url('module/add'));
    }
    public function update_module(){
        $this->form_validation->set_rules('module_name','module_name','trim|required');
        $info = $this->input->post(NULL,true);

        if($this->form_validation->run()) {
        $rs = $this->module->do_update_module($info);
        if($rs) {
        $this->session->set_flashdata('success', 'module has been updated successfully');
        redirect(site_url('module/add'));
        } 
        else {
        $this->session->set_flashdata('error', 'Some error occurred. Please try again.');
        }
        } 
        else {
        $this->session->set_flashdata('error',validation_errors());
        }
        redirect(site_url('module/add/'.$info['mod_id']));
    }

}