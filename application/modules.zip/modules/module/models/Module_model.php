<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * @author bimlesh
 *
 */
class Module_model extends CI_Model {

	public function do_add_module($params){

        try {
            $this->db->trans_begin();
                    $module= array(
                        'module_name' => $params['module_name'],
                    );
                $this->db->insert('modules',$module);

            if(!$this->db->affected_rows()) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return 1;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }
    public function do_update_module($params){
     //echo"<pre>";print_r($params);die;
       try { 
            $this->db->trans_begin();
            $where = array(
                'id' => $params['mod_id']
            );
                $update_data = array(
                'module_name' => $params['module_name']
            );
            if(!$this->db->update('modules', $update_data, $where)) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return TRUE;
            
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return FALSE;
        }
    }
    
    public function module_result(){
        $this->db->select("*");
        $this->db->from("modules");
        $return=$this->db->get()->result_array();
        return $return ;
    }
    public function module_results($id=""){
        $this->db->select("*");
        $this->db->from("modules");
        $this->db->where('id',$id);
        $return=$this->db->get()->row_array();
        return $return ;
    }
  	
}
