<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class General extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('general_model','general');
		$this->load->library('external');
	}

	public function index(){
		$data['title'] = 'Users Management';
		$data['page'] = 'vendor_list';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();       
		$this->load->view('template',$data);
	}

	public function category($cat_id = null){
		if($cat_id != null){
			$data['cat_info'] = $this->general->cat_info($cat_id);	
		}
		$data['title'] = 'Category Management';
		$data['page'] = 'category';   
		$data['categories'] = $this->general->categories_list();   
		
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();       
		$data['extra_datatable_data'] .= $this->external->validation_extra_js_css();       
		$data['extra_datatable_data'] .= $this->external->dropdown_search(); 
		$area=$this->general->get_area_type_info();
		$data['area']=$area;
		$data['extra_datatable_data'] .= '<script>
											function change_status(that){
												var number = $(that).attr("data-number");
												var status = $(that).val();
												$.ajax({
													url: "'.base_url('general/change_status').'",
													data: { 
														"number": number, 
														"status": status
													},
													cache: false,
													type: "POST",
													success: function(response) {
														location.reload();
													},
													error: function(xhr) {
														console.log(xhr);
													}
												});
											}
											$("#area").select2({
										        placeholder: "Select Area",
										        width: "resolve" 
										     
										    });
										</script>';       
		$this->load->view('template',$data);
	}

	public function addattributes(){
		$this->form_validation->set_rules('subcat_category','subcat_category','required');
		$this->form_validation->set_rules('subcat_category','subcat_category','required');
		$this->form_validation->set_rules('attributes_name','attributes_name','required');
		$this->form_validation->set_rules('attributes_description','attributes_description','required');
		if ($this->form_validation->run() == FALSE){
			echo validation_errors();			
		}else{
			$attr=array(
				'category_id'=>$this->input->post('subcat_category'),
				'subcategory_id'=>$this->input->post('subcat_category'),
				'name'=>$this->input->post('attributes_name'),
				'description'=>$this->input->post('attributes_description'),
				'status'=>($this->input->post('attributes_status'))?$this->input->post('attributes_status'):1,
				'updated_on'=>date('Y-m-d h:i:s')
			);

			if($this->input->post('attributes_id')){
				$attributes_id = $this->input->post('attributes_id');
				$this->general->update('attributes', $attr, $attributes_id);
				redirect('/general/attributes', 'refresh');
	        }else{
	        	$this->general->insert('attributes',$attr );
	        	redirect('/general/attributes', 'refresh');
	        }

		}

	}
	public function add_assignment(){
		try {
			$this->form_validation->set_rules('category','category','required');
			$this->form_validation->set_rules('subcat_category','subcat_category','required');

			if ($this->form_validation->run() == FALSE){
				throw new Exception("Error Processing Request", 1);   	
			}else{

				$data=$this->input->post(NULL, TRUE);
				if($this->general->add_assignment($data))
				{
					$this->session->set_flashdata('success', 'Assignment is added successfully');
            		redirect(site_url('general/assignment'));
				}

				$this->session->set_flashdata('error', 'Something Went Worng');
            	redirect(site_url('general/assignment'));

			}
		} catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(site_url('general/assignment'));

        }

	}
	
	public function addcategory(){
		$this->form_validation->set_rules('cat_name','Category Name','required');
		$this->form_validation->set_rules('cat_description','Category Description','required');
		if ($this->form_validation->run() == FALSE){
			echo validation_errors();			
		}else{

			$cat = array(
				'name'=>$this->input->post('cat_name'),
				'description'=>$this->input->post('cat_description'),
				'status'=>$this->input->post('cat_status'),
				'added_by'=> 1, // admin id
				'updated_by'=>1, // admin Id
				'updated_on'=>date('Y-m-d h:i:s')
			);
			if($this->input->post('subcat_category'))
				$cat['parent_id'] = $this->input->post('subcat_category');

			if(isset($_FILES['cat_icon'])){
	            foreach ($_FILES['cat_icon']['name'] as $key => $value) {
	                $_FILES['images[]']['name']= $_FILES['cat_icon']['name'][$key];
	                $_FILES['images[]']['type']= $_FILES['cat_icon']['type'][$key];
	                $_FILES['images[]']['tmp_name']= $_FILES['cat_icon']['tmp_name'][$key];
	                $_FILES['images[]']['error']= $_FILES['cat_icon']['error'][$key];
	                $_FILES['images[]']['size']= $_FILES['cat_icon']['size'][$key];
					unset( $config);
	                $config['upload_path']          = './assets/uploads/icons/';
	                $config['allowed_types']        = 'gif|jpg|png|jpeg';
	                $config['max_size']             = '*';
	                $config['max_width']            = '*';
	                $config['max_height']           = '*';
	                $config['file_name']            = date('ymdHis').mt_rand(1000,99999) ;
	                $images = array();
	                $this->load->library('upload', $config);

	                if ( ! $this->upload->do_upload('images[]')){
	                    $error = array('error' => $this->upload->display_errors());
	                    print_r($error);
	                    break;
	                }else{
	                    $data = array('upload_data' => $this->upload->data());
	                    $arr[]=  $data['upload_data']['raw_name'].$data['upload_data']['file_ext'];
	                }
	            }
	            if(isset($arr)){
	                $cat['icon'] = implode(',', $arr);
	                unset($arr);
	            }
	        }			
	        if($this->input->post('cat_id')){
	        	unset($cat['added_by']);
				$cat_id = $this->input->post('cat_id');
				$this->general->update_cat($cat, $cat_id);
				redirect('/general/subcategory', 'refresh');
	        }else{
	        	$ins_id=$this->general->add_cat($cat);
	        	if($ins_id)
	        	{
	        		$params=$this->input->post(NULL, true);
	        		$cnt=count($params['area']);
		            for($i=0;$i<=$cnt-1;$i++)
		            {
		                $insert_area[]= array('product_cat_id' => $ins_id, 'area_id' => $params['area'][$i],'created_on'=> date('Y-m-d H:i:s'));
		            }
            		$this->general->add_category_area($insert_area);
	        		redirect('/general/category', 'refresh');	
	        	}
	        	
	        }
		}
	}

	public function subcategory($type='subcategory' ,$cat_id = null){
		$data['title'] = 'Sub-Category Management';
		$data['page'] = 'subcategory'; 
		if($cat_id != null && $type == 'subcategory'){
			$data['cat_info'] = $this->general->cat_info($cat_id);	
			$data['subcategories'] = $this->general->subcategories_list();
		}else{
			$data['subcategories'] = $this->general->subcategories_list($cat_id);
		}
		
		$data['categories'] = $this->general->categories_list();    
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();       
		$data['extra_datatable_data'] .= $this->external->validation_extra_js_css();       
		$data['extra_datatable_data'] .= '<script>
											function change_status(that){
												var number = $(that).attr("data-number");
												var status = $(that).val();
												$.ajax({
													url: "'.base_url('general/change_status').'",
													data: { 
														"number": number, 
														"status": status
													},
													cache: false,
													type: "POST",
													success: function(response) {
														location.reload();
													},
													error: function(xhr) {
														console.log(xhr);
													}
												});
											}

										</script>';       
		$this->load->view('template',$data);
	}

	public function add_subcategory()
	{
		try{
			$this->form_validation->set_rules('subcat_category', 'Subcategory', 'trim|required');
			$this->form_validation->set_rules('cat_name', 'Subcategory Name', 'trim|required');
			$this->form_validation->set_rules('cat_description', 'Description', 'trim|required');
			$this->form_validation->set_rules('cat_status', 'Status', 'trim|required');
			if(!$this->form_validation->run()) {
				throw new Exception(validation_errors(), 1);				
			}
			$post_data = $this->input->post(null,true);
			$result = $this->general->add_subcategory($post_data);
			if(!$result){
				throw new Exception("Not added.", 1);				
			}
			$this->session->set_flashdata('success',"Added successfully.");
			redirect('general/subcategory');
		}catch(Exception $e){
			$this->session->set_flashdata('error', $e->getMessage());
			redirect('general/subcategory','refresh');
		}
	}

	public function assignment(){
		/*if(!empty($attr_id) && $title == 'attributes'){
			$data['attr_info'] = $this->general->attr_info($attr_id);	
			$data['attributes'] = $this->general->attributes_list();
		}else{
			$data['attributes'] = $this->general->attributes_list();
		}*/
		$data['attributes'] = $this->general->attributes_list();
		$data['tags'] = $this->general->tag_list();
		$data['units'] = $this->general->unit_list();
		$data['title'] = 'Attribute Management';
		$data['page'] = 'assignment';   
		$data['categories'] = $this->general->categories_list();
		$data['subcategories'] = $this->general->subcategories_list();
		$data['assignments'] = $this->general->assignment_lists();
		//echo "<pre>";print_r($data['assignments']);exit();
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();       
		$data['extra_datatable_data'] .= $this->external->validation_extra_js_css();       
		$data['extra_datatable_data'] .= '<script>
											function change_status(that){
												var number = $(that).attr("data-number");
												var status = $(that).val();
												$.ajax({
													url: "'.base_url('general/change_status_attr').'",
													data: { 
														"number": number, 
														"status": status
													},
													cache: false,
													type: "POST",
													success: function(response) {
														location.reload();
													},
													error: function(xhr) {
														console.log(xhr);
													}
												});
											}

										</script>';       
		$this->load->view('template',$data);
	}

	public function edit_assignment($id){
		$attributes= $this->general->attributes_list();
		$data['tags'] = $this->general->tag_list();
		$data['units'] = $this->general->unit_list();
		$data['stored'] = $this->general->get_assignment_list($id);
		$stored=$data['stored'];

		$data['tags_opt']=$this->data_process_edit_assignment($stored['val_tags'],$data['tags']);
		//$data['units_opt']=$this->data_process_edit_assignment($stored['val_units'],$data['units']);
		$data['att_opt']=$this->data_process_edit_assignment($stored['val_attribute'],$attributes);
		
		$data['title'] = 'Attribute Management';
		$data['page'] = 'assignment_edit';   
		$data['categories'] = $this->general->categories_list();
		$data['subcategories'] = $this->general->subcategories_list();
		$data['assignments'] = $this->general->assignment_lists();
		//echo "<pre>";print_r($data['assignments']);exit();
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();       
		$data['extra_datatable_data'] .= $this->external->validation_extra_js_css();  

	

		$this->load->view('template',$data);
	}

	public function data_process_edit_assignment($stored, $dt){
		 $cnt=count($dt);
	      $cnt_att=count($stored);
	      if($cnt_att>=1)
	      {
	        for ($i=0;$i<=$cnt-1;$i++){
	            $txt="" ;
	          for ($j=0;$j<=$cnt_att-1;$j++){
	                if($dt[$i]['id']==$stored[$j]['id'])
	                {
	                    $txt="selected";
	                }
	               $dt[$i]['option']='<option value="'.$dt[$i]['id'].'"'.$txt.'>'.$dt[$i]['name'].'</option>';
	             }
	          }
	        	          
	      }else{
	       		
	       		for ($i=0;$i<=$cnt-1;$i++){
	       		 	$dt[$i]['option']='<option value="'.$dt[$i]['id'].'">'.$dt[$i]['name'].'</option>';
	       			}
			}
			$dt_opt='';
		  	for($i=0;$i<=$cnt-1;$i++)
          	{
              $dt_opt.=$dt[$i]['option'];
          	}
        return $dt_opt;

	}

	public function update_assignment(){
		try {
			$this->form_validation->set_rules('category','category','required');
			$this->form_validation->set_rules('subcat_category','subcat_category','required');

			if ($this->form_validation->run() == FALSE){
				throw new Exception("Error Processing Request", 1);   	
			}else{

				$data=$this->input->post(NULL, TRUE);
				
				if($this->general->update_assignment($data))
				{
					$this->session->set_flashdata('success', 'Assignment is updated successfully');
            		redirect(site_url('general/assignment'));
				}

				$this->session->set_flashdata('error', 'Something Went Worng');
            	redirect(site_url('general/assignment'));

			}
		} catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(site_url('general/assignment'));

        }

	}

	public function banks(){
		$data['title'] = 'Banks Management';
		$data['page'] = 'banks';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();       
		$this->load->view('template',$data);
	}

	public function countries(){
		return $this->general->get_all_country();
	}

	public function states_ajax(){
		if($this->input->post('country'))
			$data = $this->general->states($this->input->post('country'));
		else
			$data = $this->general->states();
		$a ='<option value="">Please select state</option>';
		foreach ($data as $key => $value) {
			$a .= '<option value="'.$value['id'].'">'.$value['name'].'</option>';
		}
		echo $a;
	}

	public function cities_ajax(){
		if($this->input->post('state'))
			$data = $this->general->cities($this->input->post('state'));
		else
			$data = $this->general->cities();
		$a ='<option value="">Please select city</option>';
		foreach ($data as $key => $value) {
			$a .= '<option value="'.$value['id'].'">'.$value['name'].'</option>';
		}
		echo $a;
	}

	public function change_status(){
		return $this->general->change_status($this->input->post('status'), $this->input->post('number'));
	}

	public function change_status_attr(){
		return $this->general->change_status_align($this->input->post('status'), $this->input->post('number'), 'attribute_relation_category');
	}


	public function seo_product(){
		$data['title'] = 'SEO of products';
		$data['page'] = 'seo_product';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();       
		$data['extra_datatable_data'] .= '
			<script type="text/javascript">
				$(document).ready(function (){
				    $("#seo_product").DataTable({
				        "processing": true,
				        "serverSide": true,
				        "ajax":{
				            "url": "'.base_url('general/seo_product_list').'",
				            "dataType": "json",
				            "type": "POST",
				            "data":{
				              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
				            }
				        },
				        "columns": [
				          { "data": "id" },
				          { "data": "sku" },
				          { "data": "product" },
				          { "data": "author" },
				          { "data": "title" },
				          { "data": "keywords" },
				          { "data": "description" },
				          { "data": "action" },
				        ]
				    });
				});
			</script>';
		$data['seo'] = $this->general->get_all('seo_product');
		$this->load->view('template',$data);
	}

	public function seo_product_list(){
		$columns = array(
			0=> 'id',
			1=> 'sku',
			2=> 'product',
			3=> 'author',
			4=> 'title',
			5=> 'keywords',
			6=> 'description',
			7=> 'action',
		);

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
        
        $totalData = $this->general->get_count('seo_product');
        

        $totalFiltered = $totalData; 
        if(empty($this->input->post('search')['value'])){
        	$posts = $this->general->all_seo_item($limit,$start,$order,$dir);
        }else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->general->item_search($limit,$start,$search,$order,$dir);

            // $totalFiltered = $this->general->item_count_search($search,  'admins');
        }
  
  		$data = array();
		if(!empty($posts)){
			foreach ($posts as $post){
				$nestedData['id'] = '';
				$nestedData['sku'] = $post->sku;
				$nestedData['product'] = $post->display_name;
				$nestedData['author'] = $post->author;
				$nestedData['title'] = $post->title;
				$nestedData['keywords'] = $post->keyword;
				$nestedData['description'] = $post->description;
				$nestedData['action'] = '
					<a href="'.base_url('general/seo_product_edit/'.$post->id).'" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
					';
				$data[] = $nestedData;
			}
		}

		$json_data = array(
		"draw"            => intval($this->input->post('draw')),  
		"recordsTotal"    => intval($totalData),  
		"recordsFiltered" => intval($totalFiltered), 
		"data"            => $data   
		);

		echo json_encode($json_data);
	}

	public function seo(){
		$data['title'] = 'Search enginer optimization SEO';
		$data['page'] = 'seo';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();       
		$data['seo'] = $this->general->get_all('seo');
		$this->load->view('template',$data);
	}

	public function seo_edit($seo_id=  null){
		$this->form_validation->set_rules('author','author','required');
		$this->form_validation->set_rules('title','title','required');
		$this->form_validation->set_rules('description','description','required');
		$this->form_validation->set_rules('keywords','keywords','required');
		$this->form_validation->set_rules('seo_id',' ','required');

		if ($this->form_validation->run() == FALSE){
			if($seo_id == null){
				echo '404 not found';
				exit();
			}
			echo validation_errors();			
			$data['title'] = 'Search enginer optimization SEO';
			$data['page'] = 'seo_edit';       
			$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();       
			$data['seo'] = $this->general->get_one('seo', $seo_id);
			$this->load->view('template',$data);
		}else{
			$arrayName = array(
				'author' => $this->input->post('author'), 
				'title' => $this->input->post('title'), 
				'description' => $this->input->post('description'), 
				'keywords' => $this->input->post('keywords'), 
			);
			$rs = $this->general->update('seo',$arrayName, $this->input->post('seo_id'));
			if($rs){
				redirect('/general/seo_edit/'.$this->input->post('seo_id'), 'refresh');
			}
			else{
				echo "error";
			}

		}
	}

	public function seo_product_edit($seo_id=  null){
		$this->form_validation->set_rules('author','author','required');
		$this->form_validation->set_rules('title','title','required');
		$this->form_validation->set_rules('description','description','required');
		$this->form_validation->set_rules('keywords','keywords','required');
		$this->form_validation->set_rules('seo_id',' ','required');

		if ($this->form_validation->run() == FALSE){
			if($seo_id == null){
				echo '404 not found';
				exit();
			}
			echo validation_errors();			
			$data['title'] = 'Search enginer optimization SEO';
			$data['page'] = 'seo_product_edit';       
			$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();       
			$data['seo'] = $this->general->get_product_info( $seo_id);
			$this->load->view('template',$data);
		}else{
			$arrayName = array(
				'author' => $this->input->post('author'), 
				'title' => $this->input->post('title'), 
				'description' => $this->input->post('description'), 
				'keyword' => $this->input->post('keywords'), 
			);
			$rs = $this->general->update('seo_product',$arrayName, $this->input->post('seo_id'));
			if($rs){
				redirect('/general/seo_product_edit/'.$this->input->post('seo_id'), 'refresh');
			}
			else{
				echo "error";
			}

		}
	}
	
}
