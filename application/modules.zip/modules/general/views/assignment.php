<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Category Management</h3>
      </div>
    </div>
  </div>
    <div class="clearfix"></div>
    <!-- Add category form -->
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Tag and Attribute Assignment </h2>
            <ul class="nav navbar-right panel_toolbox">
              <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
              
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <div class="row">
                <?php
                if ($this->session->flashdata('success')) { ?>
                <div class="alert alert-success my_alert" role="alert">
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } if ($this->session->flashdata('fail')) { ?>
                <div class="alert alert-danger my_alert" role="alert">
                    <?php echo $this->session->flashdata('fail'); ?>
                </div>
                <?php } ?>
            </div>
            <form class="form-horizontal form-label-left" method="post" action="<?=base_url('general/add_assignment'); ?>" data-toggle="validator">
            
              <span class="section">Assignment</span>
                <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="subcat_category">Category <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select id="category" name="category" class="form-control col-md-7 col-xs-12" required="required">
                    <?php
                    foreach ($categories as $key => $value) {
                      if(isset($attr_info['category_id']) &&  $attr_info['category_id']==$value['id'])
                        echo '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
                      else
                        echo '<option value="'.$value['id'].'">'.$value['name'].'</option>';
                    }
                    ?>
                  </select>
                </div>
              </div>

              <div class="item form-group subcategory_blk">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="subcat_category">Sub-Category <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select id="subcat_category" name="subcat_category" class="form-control col-md-7 col-xs-12" required="required">
                  
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Attributes<span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select name="attributes[]" class="form-control select2" multiple="" required="" id="attribute" style="width:100%;">
                    <?php $cnt=count($attributes);
                    for ($i=0;$i<=$cnt-1;$i++){?>
                        <option value="<?php echo $attributes[$i]['id'];?>"><?php echo $attributes[$i]['name'];?></option>
                    <?php } ?>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Tags<span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select name="tags[]" class="form-control select2" multiple="" required="" id="tags" style="width:100%;">
                    <?php $cnt=count($tags);
                    for ($i=0;$i<=$cnt-1;$i++){?>
                        <option value="<?php echo $tags[$i]['id'];?>"><?php echo $tags[$i]['name'];?></option>
                    <?php } ?>
                  </select>
                </div>
              </div>
            <!--   <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Units<span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select name="units[]" class="form-control select2" multiple="" required="" id="units" style="width:100%;">
                    <?php $cnt=count($units);
                    for ($i=0;$i<=$cnt-1;$i++){?>
                        <option value="<?php echo $units[$i]['id'];?>"><?php echo $units[$i]['name'];?></option>
                    <?php } ?>
                  </select>
                </div>
              </div> -->
              <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="attributes_status">Status <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select id="attributes_status" name="attributes_status" class="form-control col-md-7 col-xs-12">
                    <option value="1" <?=(isset($attr_info['status']) &&  $attr_info['status']==1)?'selected':'';?> >Activate</option>
                    <option value="2" <?=(isset($attr_info['status']) &&  $attr_info['status']==2)?'selected':'';?>>Deactivate</option>
                  </select>
                </div>
            </div>

       <!--        <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Upload icon <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="file" name="attributes_icon" id="attributes_icon" class="form-control col-md-7 col-xs-12" >
                </div>
              </div>
 -->              <div class="ln_solid"></div>
              <div class="form-group">
                <div class="col-md-6 col-md-offset-3">
                  <!-- <button type="submit" class="btn btn-primary">Cancel</button> -->
                  <button id="send" type="submit" class="btn btn-success">Save</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- category list -->
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Assignment list</h2>
              <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                
              </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <p class="text-muted font-13 m-b-30"><!-- If you want to write somting you can write here --></p>
            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Category</th>
                  <th>Sub-Category</th>
                  <th>Attributes</th>
                  <th>Product Tags</th>
                  <!-- <th>Units</th> -->
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $cnt=count($assignments);
                for($i=0;$i<=$cnt-1;$i++){
                  $att='';
                  $tag='';
                  $unit='';
                  foreach ($assignments[$i] as $key => $value) {
                    if($value['attribute_name']!=''){
                        $att.= '<span class="label label-primary">'.$value['attribute_name'].'</span> ';
                      }
                      if($value['tag_name']!=''){
                        $tag.= '<span class="label label-primary">'.$value['tag_name'].'</span> ';
                      }
                      if($value['unit_name']!=''){
                        $unit.= '<span class="label label-primary">'.$value['unit_name'].'</span> ';
                      }

                      } ?>
                    <tr>
                      <td></td>
                      <td><?=$value['catgory_name']; ?></td>
                      <td><?=$value['subcategory_name']; ?></td>
                      <td><?php echo $att; ?></td>
                      <td><?php echo $tag; ?></td>
                      <!-- <td><?php echo $unit; ?></td> -->
                      <td><?php echo ($value['status']==1)?"Active":"In-Active"; ?></td>
                      <td>
                        <select class="btn btn-primary" data-number="<?=$value['category_id'].'_'.$value['subcategory_id']?>" onchange="return change_status(this)">>
                          <option value="1" <?=($value['status']==1)?"selected":'';?>> Active</option>
                              <option value="2" <?=($value['status']==2)?"selected":'';?>> In-Active</option>
                        </select>
                        <a href="<?=base_url('general/edit_assignment/').$value['category_id'].'_'.$value['subcategory_id']; ?>" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
                      </td>
                    </tr>

                <?php } ?>

              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
 

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
      
<script type="text/javascript">
      $("#attribute").select2({
          placeholder: "Select Attribute",
          width: "resolve" 
       
      });
      $("#tags").select2({
          placeholder: "Select Tags",
          width: "resolve" 
       
      });
     /* $("#units").select2({
          placeholder: "Select Units",
          width: "resolve" 
       
      });*/
   $('.subcategory_blk').hide();
   $("#category").on('change',function(){
          var id=$(this).val();
         $.ajax({
            type:"POST",
            url:"<?php echo site_url();?>product_vendor/get_sub_category",
            data:{'id':id},
            dataType:'json',
       success: function(response)
       { 
        var ln=response.length;
        if(ln>=1)
        {
           var cnt;
            for(var i=0;i<=ln-1;i++)
            {
              cnt+='<option value="'+response[i]['id']+'">'+response[i]['name']+'</option>';
             
            }

            $('.subcategory_blk').show();
            $('#subcat_category').html('');
            $('#subcat_category').html(cnt);
           
        }
        else
        {
          $('.subcategory_blk').hide();
        }

        }
      });
   });
    var id=$('#category').val();
     $.ajax({
            type:"POST",
            url:"<?php echo site_url();?>product_vendor/get_sub_category",
            data:{'id':id},
            dataType:'json',
       success: function(response)
       { 
        var ln=response.length;
        if(ln>=1)
        {
           var cnt;
            for(var i=0;i<=ln-1;i++)
            {
              cnt+='<option value="'+response[i]['id']+'">'+response[i]['name']+'</option>';
             
            }

            $('.subcategory_blk').show();
            $('#subcat_category').html('');
            $('#subcat_category').html(cnt);
           
        }
        else
        {
          $('.subcategory_blk').hide();
        }

        }
      });
</script>
