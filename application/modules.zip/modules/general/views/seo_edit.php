<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>SEO Management</h3>
      </div>
    </div>
  </div>
    <div class="clearfix"></div>
    
    <!-- category list -->
    <div class="row">
      <?php $seo = $seo[0]; ?>
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Edit SEO Info</h2>
            <ul class="nav navbar-right panel_toolbox">
              <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
              
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <form class="form-horizontal form-label-left" method="post" novalidate enctype="multipart/form-data" action="<?=base_url('general/seo_edit');?>">
              
              <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="author">Author <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input id="author" class="form-control col-md-7 col-xs-12" name="author" placeholder="Please enter author for meta tag" required="required" type="text" value="<?=(isset($seo['author']))?$seo['author']:'' ?>">
                </div>
              </div>

              <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="title">Title <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input id="title" class="form-control col-md-7 col-xs-12" name="title" placeholder="Please enter author for meta tag" required="required" type="text" value="<?=(isset($seo['title']))?$seo['title']:'' ?>">
                </div>
              </div>

              <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="description">Description <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <textarea id="description" name="description" class="form-control col-md-7 col-xs-12" placeholder="Please enter description for meta tag" required="required" ><?=(isset($seo['description']))?$seo['description']:'' ?></textarea>
                </div>
              </div>

              <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="keywords">Keywords <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <textarea id="keywords" name="keywords" class="form-control col-md-7 col-xs-12" placeholder="Please enter keywords for meta tag (comma separated) " required="required" ><?=(isset($seo['keywords']))?$seo['keywords']:'' ?></textarea>
                </div>
              </div>

              <?php 
              if(isset($seo['id'])){
                echo "<input type='hidden' value='".$seo['id']."' name='seo_id' id='seo_id'>";
              }
              ?>
              <div class="ln_solid"></div>
              <div class="form-group">
                <div class="col-md-6 col-md-offset-3">
                  <button id="send" type="submit" class="btn btn-success">Update</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

