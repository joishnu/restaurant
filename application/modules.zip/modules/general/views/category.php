<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Category Management</h3>
      </div>
    </div>
  </div>
    <div class="clearfix"></div>
    <!-- Add category form -->
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Add Category <small>Add new category</small></h2>
            <ul class="nav navbar-right panel_toolbox">
              <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
              
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <form class="form-horizontal form-label-left" method="post" novalidate enctype="multipart/form-data" action="<?=base_url('general/addcategory');?>" data-toggle="validator">
              <span class="section">Add New category</span>
              <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="cat_name">Name <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input id="cat_name" class="form-control col-md-7 col-xs-12" name="cat_name" placeholder="Please enter category name" required="required" type="text" value="<?=(isset($cat_info['name']))?$cat_info['name']:'' ?>">
                </div>
              </div>

              <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="cat_description">Description <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <textarea id="cat_description" name="cat_description" class="form-control col-md-7 col-xs-12" placeholder="Please enter category description" required="required" ><?=(isset($cat_info['description']))?$cat_info['description']:'' ?></textarea>
                </div>
              </div>

              <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="cat_icon">Upload icon <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="file" name="cat_icon[]" id="cat_icon" class="form-control col-md-7 col-xs-12" required="">
                </div>
              </div>
              <?php 
              if(isset($cat_info['id'])){
                echo "<input type='hidden' value='".$cat_info['id']."' name='cat_id' id='cat_id'>";
              }
              if(isset($cat_info['icon']) && (!empty($cat_info['icon']))){
                echo '<div class="item form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="cat_status">Current Icon <span class="required">*</span></label>
              <div class="col-md-6 col-sm-6 col-xs-12">
              <img src="'.base_url('assets/uploads/icons/'.$cat_info['icon']).'" style="max-width: 100%"></div>
            </div>';
              }

              //(isset($cat_info['icon']) && ($cat_info['icon']))?"<img src='".base_url('aseets/uploads/icons/').$cat_info['icon']"'>":''; ?>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Area Name<span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select name="area[]" class="form-control select2" multiple="" required="" id="area" style="width:100%;">
                    <?php $cnt=count($area);
                    for ($i=0;$i<=$cnt-1;$i++){?>
                        <option value="<?php echo $area[$i]['id'];?>"><?php echo $area[$i]['name'];?></option>
                    <?php } ?>
                  </select>
                </div>
              </div>
            <div class="item form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="cat_status">Status <span class="required">*</span></label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <select id="cat_status" name="cat_status" class="form-control col-md-7 col-xs-12" required="">
                  <option value="">Please select status</option>
                  <option value="1" <?=(isset($cat_info['status']) && ($cat_info['status'] == 1))?"selected":''; ?>>Activate</option>
                  <option value="2" <?=(isset($cat_info['status']) && ($cat_info['status'] == 2))?"selected":''; ?>>Deactivate</option>
                </select>
              </div>
            </div>


              <div class="ln_solid"></div>
              <div class="form-group">
                <div class="col-md-6 col-md-offset-3">
                  <button id="send" type="submit" class="btn btn-success">Save</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

    <!-- category list -->
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Category list</h2>
              <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                
              </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <p class="text-muted font-13 m-b-30"><!-- If you want to write somting you can write here --></p>
            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>registered By</th>
                  <th>Description</th>
                  <th>Registered Date</th>
                  <th>Icon</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($categories as $key => $value) { ?>
                    <tr>
                      <td></td>
                      <td><a href="<?=base_url('general/subcategory/category/').$value['id'];?>"><?php echo $value['name']; ?></a></td>
                      <td><?php echo $value['first_name'].' '.$value['last_name']; ?></td>
                      <td><?php echo wordwrap($value['description'], 150, "<br>\n"); ?></td>
                      <td><?php echo date("d M, Y", strtotime($value['added_on'])); ?></td>
                      <td><img src="<?php echo base_url('assets/uploads/icons/'.$value['icon']); ?>" style="max-width: 50%"></td>
                      <td><?php echo ($value['status']==1)?"Active":"In-Active"; ?></td>
                      <td>
                        <select class="btn btn-primary" data-number="<?=$value['id']?>" onchange="return change_status(this)">
                          <option value="1" <?=($value['status']==1)?"selected":'';?>> Active</option>
                          <option value="2" <?=($value['status']==2)?"selected":'';?>> In-Active</option>
                        </select>
                        <a href="<?=base_url('general/category/').$value['id']; ?>" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
                        <a href="<?=base_url('general/subcategory/category/').$value['id'];?>" class="btn btn-primary"><i class="fa fa-eye"></i> View Subcategories</a>
                      </td>
                    </tr>
                <?php } ?>

              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

