<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Edit Category Management</h3>
      </div>
    </div>
  </div>
    <div class="clearfix"></div>
    <!-- Add category form -->
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Edit Tag and Attribute Assignment </h2>
            <ul class="nav navbar-right panel_toolbox">
              <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
              
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <div class="row">
                <?php
                if ($this->session->flashdata('success')) { ?>
                <div class="alert alert-success my_alert" role="alert">
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } if ($this->session->flashdata('fail')) { ?>
                <div class="alert alert-danger my_alert" role="alert">
                    <?php echo $this->session->flashdata('fail'); ?>
                </div>
                <?php } ?>
            </div>
            <form class="form-horizontal form-label-left" novalidate method="post" action="<?=base_url('general/update_assignment'); ?>"  data-toggle="validator">
              <span class="section">Edit Assignment</span>
                <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="subcat_category">Category <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select id="category" name="category" class="form-control col-md-7 col-xs-12" required="required">
                    <?php
                    foreach ($categories as $key => $value) {
                      if(isset($stored['category_id']) &&  $stored['category_id']==$value['id'])
                        echo '<option value="'.$value['id'].'" selected>'.$value['name'].'</option>';
                      else
                        echo '<option value="'.$value['id'].'">'.$value['name'].'</option>';
                    }
                    ?>
                  </select>
                  <input type="hidden" name="category_id_hid" value="<?php echo $stored['category_id'];?>">
                  <input type="hidden" name="subcategory_id_hid" value="<?php echo $stored['subcategory_id'];?>">
                </div>
              </div>

              <div class="item form-group subcategory_blk">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="subcat_category">Sub-Category <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select id="subcat_category" name="subcat_category" class="form-control col-md-7 col-xs-12" required="required">
                  
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Attributes<span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select name="attributes[]" class="form-control select2" multiple="" required="" id="attribute" style="width:100%;">
                    <?php 
                        echo $att_opt;
                        ?>
                  </select>
                </div>
              </div>
              
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Tags<span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select name="tags[]" class="form-control select2" multiple="" required="" id="tags" style="width:100%;">
                    <?php echo $tags_opt; ?>
                  </select>
                </div>
              </div>
            <!--   <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Units<span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select name="units[]" class="form-control select2" multiple="" required="" id="units" style="width:100%;">
                    <?php echo $units_opt; ?>
                  </select>
                </div>
              </div> -->
              <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="attributes_status">Status <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select id="attributes_status" name="attributes_status" class="form-control col-md-7 col-xs-12">
                    <option value="1" <?=(isset($attr_info['status']) &&  $attr_info['status']==1)?'selected':'';?> >Activate</option>
                    <option value="2" <?=(isset($attr_info['status']) &&  $attr_info['status']==2)?'selected':'';?>>Deactivate</option>
                  </select>
                </div>
            </div>

       <!--        <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Upload icon <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="file" name="attributes_icon" id="attributes_icon" class="form-control col-md-7 col-xs-12" >
                </div>
              </div>
 -->              <div class="ln_solid"></div>
              <div class="form-group">
                <div class="col-md-6 col-md-offset-3">
                  <!-- <button type="submit" class="btn btn-primary">Cancel</button> -->
                  <button id="send" type="submit" class="btn btn-success">Update</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
      
<script type="text/javascript">
      $("#attribute").select2({
          placeholder: "Select Attribute",
          width: "resolve" 
       
      });
      $("#tags").select2({
          placeholder: "Select Tags",
          width: "resolve" 
       
      });
      /*$("#units").select2({
          placeholder: "Select Units",
          width: "resolve" 
       
      });*/
   $('.subcategory_blk').hide();
   $("#category").on('change',function(){
          var id=$(this).val();
         $.ajax({
            type:"POST",
            url:"<?php echo site_url();?>product_vendor/get_sub_category",
            data:{'id':id},
            dataType:'json',
       success: function(response)
       { 
        var ln=response.length;
        if(ln>=1)
        {
           var cnt;
            for(var i=0;i<=ln-1;i++)
            {
              cnt+='<option value="'+response[i]['id']+'">'+response[i]['name']+'</option>';
             
            }

            $('.subcategory_blk').show();
            $('#subcat_category').html('');
            $('#subcat_category').html(cnt);
           
        }
        else
        {
          $('.subcategory_blk').hide();
        }

        }
      });
   });
    var sub_cat_id= '<?php echo $stored['subcategory_id'];?>';
    var id=$('#category').val();
     $.ajax({
            type:"POST",
            url:"<?php echo site_url();?>product_vendor/get_sub_category",
            data:{'id':id},
            dataType:'json',
       success: function(response)
       { 
        var ln=response.length;
        if(ln>=1)
        {
           var cnt;
            for(var i=0;i<=ln-1;i++)
            {
              if(response[i]['id']==sub_cat_id)
              {
                cnt+='<option value="'+response[i]['id']+'" selected >'+response[i]['name']+'</option>';  
              }
              else
              {
                 cnt+='<option value="'+response[i]['id']+'">'+response[i]['name']+'</option>';  
              }
            }

            $('.subcategory_blk').show();
            $('#subcat_category').html('');
            $('#subcat_category').html(cnt);
           
        }
        else
        {
          $('.subcategory_blk').hide();
        }

        }
      });
</script>