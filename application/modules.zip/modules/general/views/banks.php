<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Bank Management</h3>
      </div>
    </div>
  </div>
    <div class="clearfix"></div>
    
    <!-- category list -->
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Banks List</h2>
              <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                <li><a class="close-link"><i class="fa fa-close"></i></a></li>
              </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <p class="text-muted font-13 m-b-30"><!-- If you want to write somting you can write here --></p>
            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>IFAC Code</th>
                  <th>Address</th>
                  <th>Current Balance</th>
                  <th>registered date</th>
                  <th>About Bank</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td></td>
                  <td>World Bank Inc</td>
                  <td>WBI989898</td>
                  <td>1/2 Quad road, USA</td>
                  <td>SAR 56,967.00</td>
                  <td>01 Jan, 2019</td>
                  <td><?php echo wordwrap("Electronics comprises the physics, engineering, technology and applications that deal with the emission, flow and control of electrons in vacuum and matter.[1] The identification of the electron in 1897, along with the invention of the vacuum tube, which could amplify and rectify small electrical signals, inaugurated the field of electronics and the electron age.",150,"<br>\n");
                  ?></td>
                  <td>Active</td>
                  <td>
                    <select class="btn btn-primary">
                      <option><i class="fa fa-check"></i> Active</option>
                      <option><i class="fa fa-times"></i> In-Active</option>
                    </select>
                    <a href="#" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
                  </td>
                </tr>

                <tr>
                  <td></td>
                  <td>Swis Bank Inc</td>
                  <td>SBI989898</td>
                  <td>45 Snapdrag road, Australa</td>
                  <td>SAR 907,055.00</td>
                  <td>01 Jan, 2019</td>
                  <td><?php echo wordwrap("Electronics comprises the physics, engineering, technology and applications that deal with the emission, flow and control of electrons in vacuum and matter.[1] The identification of the electron in 1897, along with the invention of the vacuum tube, which could amplify and rectify small electrical signals, inaugurated the field of electronics and the electron age.",150,"<br>\n");
                  ?></td>
                  <td>Active</td>
                  <td>
                    <select class="btn btn-primary">
                      <option><i class="fa fa-check"></i> Active</option>
                      <option><i class="fa fa-times"></i> In-Active</option>
                    </select>
                    <a href="#" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
                  </td>
                </tr>



              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

