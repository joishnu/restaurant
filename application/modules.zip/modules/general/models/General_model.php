<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class General_model extends CI_Model {
  
    public function get_all_country(){
        $this->db->select('id,name,phonecode');
        return $this->db->get('countries')->result_array();
    }

    public function states($country_id=null){
    	if($country_id != null)
    		$this->db->where('country_id',$country_id);
    	$data = $this->db->get('states')->result_array();
    	return $data;
    }
    public function get_area_type_info() {
        $this->db->select('*');
        return $this->db->get_where('area_type', array('status' => '1'))->result_array();
    }
    public function cities($state_id=null){
    	if($state_id != null)
    		$this->db->where('state_id',$state_id);
    	$data = $this->db->get('cities')->result_array();
    	return $data;
    }

    public function add_assignment($data)
    {
        try {
            $this->db->trans_begin();
                $cnt_tag=count($data['tags']);
                $cnt_att=count($data['attributes']);
                //$cnt_unit=count($data['units']);

                if($cnt_tag>=$cnt_att && $cnt_tag>=$cnt_unit)
                {
                    $cnt=$cnt_tag;
                }
                /*else if($cnt_unit>=$cnt_att && $cnt_unit>=$cnt_tag )
                {
                    $cnt=$cnt_unit; 
                }*/
              /*  else if($cnt_att>=$cnt_unit && $cnt_att>=$cnt_unit)
                {
                    $cnt=$cnt_att;
                }*/
                //print_r($cnt);exit();
                for($i=0;$i<=$cnt-1;$i++)
                {

                    if(isset($data['attributes'][$i]))
                    {
                        $insert_dt[$i]['attribute_id']=$data['attributes'][$i];
                    }
                    else
                    {
                        $insert_dt[$i]['attribute_id']=0; 
                    }

                    if(isset($data['tags'][$i]))
                    {
                        $insert_dt[$i]['product_tags_id']=$data['tags'][$i];
                    }
                    else
                    {
                        $insert_dt[$i]['product_tags_id']=0;   
                    }

                   /* if(isset($data['units'][$i]))
                    {
                        $insert_dt[$i]['product_units_id']=$data['units'][$i];
                    }
                    else
                    {
                        $insert_dt[$i]['product_units_id']=0;
                    }*/
                    $insert_dt[$i]['category_id']=$data['category'];
                    $insert_dt[$i]['subcategory_id']=$data['subcat_category'];
                }
                if(!$this->db->insert_batch('attribute_relation_category', $insert_dt))
                {
                    throw new Exception("Error Processing Request", 1);
                }
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }
    public function add_cat($data){
         try {
            $this->db->trans_begin();
            if(!$this->db->insert('categories', $data))
            {
                throw new Exception("Error Processing Request", 1);
            }
            $insert_id = $this->db->insert_id();
            $this->db->trans_commit();
            return $insert_id;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function add_category_area($data){
        return $this->db->insert_batch('area_product_cat_relation', $data);
    }
    
    public function categories(){
        $this->db->select('*');
        $this->db->where('`parent_id` IS NULL', NULL, false);
        return $this->db->get('categories')->result_array();
    }

    public function categories_list(){
        $this->db->select('categories.id, categories.name, categories.description, categories.status, categories.icon, users.first_name, users.last_name, roles.name as role, categories.added_on');
        $this->db->join('users', 'users.id = categories.added_by',"left");
        $this->db->join('roles', 'roles.id = users.role',"left");
        $this->db->where('`parent_id` IS NULL', NULL, false);
        return $this->db->get('categories')->result_array();
    }

    public function subcategories_list($cat = null){
        $this->db->select('categories.id, categories.name, categories.description, categories.status, categories.icon, users.first_name, users.last_name, roles.name as role, categories.added_on, cc.name as cat_name');
        $this->db->join('users', 'users.id = categories.added_by',"left");
        $this->db->join('roles', 'roles.id = users.role',"left");
        $this->db->join('categories as cc', 'cc.id = categories.parent_id');
        if($cat != null){
            $this->db->where('categories.parent_id', $cat );
        }
        $this->db->order_by('id', 'desc');
        return $this->db->get('categories')->result_array();
    }

    
    public function get_assignment_list($id){
        $id=explode("_", $id);
        $category_id=$id[0];
        $subcategory_id=$id[1];
        
        $rs['val_attribute']=$this->db->select('name as attribute_name, attribute_id as id')->join('attributes', 'attribute_relation_category.attribute_id=attributes.id')->where('attribute_relation_category.category_id', $category_id)->where('attribute_relation_category.subcategory_id', $subcategory_id)->get('attribute_relation_category')->result_array();

     /*   $rs['val_units']=$this->db->select('name as unit_name, product_units_id as id')->join('units', 'attribute_relation_category.product_units_id=units.id')->where('attribute_relation_category.category_id', $category_id)->where('attribute_relation_category.subcategory_id', $subcategory_id)->get('attribute_relation_category')->result_array();*/

        $rs['val_tags']=$this->db->select('name as unit_name, product_tags_id as id')->join('product_tags', 'attribute_relation_category.product_tags_id=product_tags.id')->where('attribute_relation_category.category_id', $category_id)->where('attribute_relation_category.subcategory_id', $subcategory_id)->get('attribute_relation_category')->result_array();

        $rs['category_id']=$category_id;
        $rs['subcategory_id']=$subcategory_id;

        return $rs;
    }

    
    public function update_assignment($params) {
        try {

            $this->db->trans_begin();
           
           
            $this->db->where('category_id', $params['category_id_hid'])->where('subcategory_id', $params['subcategory_id_hid'])->where('attribute_id', 0)->where('product_tags_id', 0)->delete('attribute_relation_category');
      
            // Getting particular category and subcategory info

            $dt=$this->db->select('id, product_tags_id, product_units_id ,attribute_id')->where('attribute_relation_category.category_id', $params['category_id_hid'])->where('attribute_relation_category.subcategory_id', $params['subcategory_id_hid'])->get('attribute_relation_category')->result_array();

            $cnt_orgn=count($dt);

            for($i=0;$i<=$cnt_orgn-1;$i++)
            {
                $tag[$i]= $dt[$i]['product_tags_id'];
                //$unit[$i]= $dt[$i]['product_units_id'];
                $attribut[$i]= $dt[$i]['attribute_id'];
            }
            
            // Tag update and insert

                $a1=$tag;
                $a2=$params['tags'];

                $tag_updt=array_diff($a1,$a2);
                if($tag_updt)
                {
                    $this->db->where_in('product_tags_id', $tag_updt);
                    $this->db->where('category_id', $params['category_id_hid']);
                    $this->db->where('subcategory_id', $params['subcategory_id_hid']);
                    $this->db->update('attribute_relation_category', array('product_tags_id' => 0));
                }

                $tag_insert=array_diff($a2,$a1);

                if($tag_insert)
                {
                    $cnt=count($tag_insert);
                    $tag_insert=array_values($tag_insert);
                    for($i=0;$i<=$cnt-1;$i++)
                    {
                        $formt_tag_insert[]=array('category_id'=>$params['category_id_hid'],
                                                  'subcategory_id' =>$params['subcategory_id_hid'],
                                                  'product_tags_id' =>$tag_insert[$i]
                                                  );
                    }
                    if(!$this->db->insert_batch('attribute_relation_category', $formt_tag_insert))
                    {
                        throw new Exception("Error Processing Request", 1);
                    }
                }

                // Unit update and insert

/*                $a1=$unit;
                $a2=$params['units'];

                $unit_updt=array_diff($a1,$a2);
                if($unit_updt)
                {
                    $this->db->where_in('product_units_id', $unit_updt);
                    $this->db->where('category_id', $params['category_id_hid']);
                    $this->db->where('subcategory_id', $params['subcategory_id_hid']);
                    $this->db->update('attribute_relation_category', array(' product_units_id ' => 0));
                }
                $unit_insert=array_diff($a2,$a1);

                if($unit_insert)
                {
                    $cnt=count($unit_insert);
                    $unit_insert=array_values($unit_insert);
                    for($i=0;$i<=$cnt-1;$i++)
                    {
                        $formt_unit_insert[]=array('category_id'=>$params['category_id_hid'],
                                                  'subcategory_id' =>$params['subcategory_id_hid'],
                                                  'product_units_id' =>$unit_insert[$i]
                                                  );
                    }
                    if(!$this->db->insert_batch('attribute_relation_category', $formt_unit_insert))
                    {
                        throw new Exception("Error Processing Request", 1);
                    }
                }*/

            // Attribute insert and update
                $a1=$attribut;
                $a2=$params['attributes'];

                $attr_updt=array_values(array_diff($a1,$a2));
                $attr_insert=array_values(array_diff($a2,$a1));

                if($attr_updt)
                {
                    $this->db->where_in('attribute_id', $attr_updt);
                    $this->db->where('category_id', $params['category_id_hid']);
                    $this->db->where('subcategory_id', $params['subcategory_id_hid']);
                    $this->db->update('attribute_relation_category', array('attribute_id' => '0'));
                }


                
                if($attr_insert)
                {
                    $cnt=count($attr_insert);
                    $attr_insert=array_values($attr_insert);
                    for($i=0;$i<=$cnt-1;$i++)
                    {
                        $formt_att_insert[]=array('category_id'=>$params['category_id_hid'],
                                                  'subcategory_id' =>$params['subcategory_id_hid'],
                                                  'attribute_id' =>$attr_insert[$i]
                                                  );
                    }
                    if(!$this->db->insert_batch('attribute_relation_category', $formt_att_insert))
                    {
                        throw new Exception("Error Processing Request", 1);
                    }
                }

                $this->db->where('category_id', $params['category_id_hid']);
                $this->db->where('subcategory_id', $params['subcategory_id_hid']);
                $this->db->update('attribute_relation_category', array('category_id' => $params['category'], 'subcategory_id' => $params['subcat_category'] ));
                

            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function change_status($status, $id_value, $table='categories', $id_field = 'id' ){
        switch ($status) {
            case 1:
                $status_array = array('status'=>1);     
                break;

            case 2:
                $status_array = array('status'=>2);     
                break;

            case 3:
                $status_array = array('status'=>3);     
                break;

            case 4:
                $status_array = array('status'=>4);     
                break;
            
            default:
                $status_array = array('status'=>0);     
                break;
        }
        
        $this->db->where($id_field, $id_value);
        $this->db->update($table, $status_array);
        return true;
    }

    public function change_status_align($status, $number) {
        try {
            $this->db->trans_begin();
            $num=explode('_', $number);
            $where= array('category_id' => $num[0], 'subcategory_id' => $num[1] );
            $update_data = array(
                'status' =>$status,
                'updated_on'=>date('Y-m-d H:i:s')
            );

            if(!$this->db->update('attribute_relation_category', $update_data, $where))
            {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function assignment_lists(){
        $this->db->select('attributes.name as attribute_name, categories.name as catgory_name, product_tags.name as tag_name, units.name as unit_name, attribute_relation_category.id,attribute_relation_category.subcategory_id, parent.name as subcategory_name, attribute_relation_category.status, attribute_relation_category.category_id');
        $this->db->join('attributes','attributes.id=attribute_relation_category.attribute_id','left');
        $this->db->join('categories','categories.id=attribute_relation_category.category_id','left');
        $this->db->join('categories as parent','parent.id=attribute_relation_category.subcategory_id');
        $this->db->join('product_tags','product_tags.id=attribute_relation_category.product_tags_id','left');
        $this->db->join('units','units.id=attribute_relation_category.product_units_id','left');
        $this->db->where('attribute_relation_category.status<>', '3');
        $rs=$this->db->get('attribute_relation_category')->result_array();

        $resArr=[];
        foreach ($rs as $key => $value) {
            if(!isset($resArr[$value['subcategory_id']])){
                $resArr[$value['subcategory_id']]=[];
            }
            array_push($resArr[$value['subcategory_id']], $value);
            
        }
       
       return array_values($resArr);

        //echo "<pre>";print_r($main_dt);exit();


    }

    public function cat_info($cat_id){
        $this->db->select('*');
        $this->db->where('id', $cat_id);
        return $this->db->get('categories')->row_array();
    }

    public function update_cat($data, $cat_id){
        $this->db->where('id',$cat_id);
        return $this->db->update('categories',$data);             
    }

    public function insert($table,$data ){
        return $this->db->insert($table,$data);
    }

    public function update($table,$data, $id_value, $id_field = 'id' ){
        $this->db->where($id_field, $id_value);
        return $this->db->update($table,$data);
    }

    public function attributes_list(){
        $this->db->select('a.name as name, a.id as id , a.description as description, a.status , a.created_on');
        return $this->db->get('attributes as a')->result_array();
    }

    public function tag_list(){
        $this->db->select('a.name as name, a.id as id , a.description as description, a.status , a.created_on');
        return $this->db->get('product_tags as a')->result_array();
    }

    public function unit_list(){
        $this->db->select('a.name as name, a.id as id , a.description as description, a.status , a.created_on');
        return $this->db->get('units as a')->result_array();
    }

    public function attr_info($attr_id){
        $this->db->select('*');
        $this->db->where('id', $attr_id);
        return $this->db->get('attributes')->row_array();
    }

    public function get_all($table, $select='*'){
        $this->db->select($select);
        return $this->db->get($table)->result_array();
    }

    public function get_one($table, $id_value,  $select='*', $id_field = 'id'){
        $this->db->select($select);
        $this->db->where($id_field, $id_value);
        return $this->db->get($table)->result_array();
    }

    public function get_product_info($id_value){
        $this->db->select('s.id, s.author, s.title, s.keyword, s.description, v.display_name, v.sku');
        $this->db->join('variations as v', 'v.id = s.variation_id');
        $this->db->where('s.id', $id_value);
        return $this->db->get('seo_product as s')->result_array();
    }

    public function get_count($table){
        $query = $this->db->get($table);
        return $query->num_rows();
    }

    public function all_seo_item($limit,$start,$order,$dir){
        $this->db->select('s.id, s.author, s.title, s.keyword, s.description, v.display_name, v.sku');
        $this->db->join('variations as v', 'v.id = s.variation_id');
        $query = $this->db
                ->limit($limit,$start)
                ->order_by($order,$dir)
                ->get('seo_product as s');

        if($query->num_rows()>0)
            return $query->result(); 
        else
            return null;
    }

    function item_search($limit,$start,$search,$col,$dir)
    {
        $this->db->select('s.id, s.author, s.title, s.keyword, s.description, v.display_name, v.sku');
        $this->db->join('variations as v', 'v.id = s.variation_id');
        $query = $this->db
            ->like('id',$search)
            ->or_like('author',$search)
            ->or_like('title',$search)
            ->or_like('keyword',$search)
            ->or_like('description',$search)
            ->or_like('display_name',$search)
            ->or_like('sku',$search)
            ->limit($limit,$start)->order_by($table.'.'.$col,$dir)->get($table);
        
       
        if($query->num_rows()>0)
            return $query->result();  
        else
            return null;
    }
   

    public function add_subcategory($data)
    {
        $insert_data = array(
            'parent_id' => $data['subcat_category'],
            'name' => $data['cat_name'],
            'description' => $data['cat_description'],
            'status' => $data['cat_status'],
            'added_on' => date('Y-m-d H:i:s'),
            'added_by'=>1,
            'updated_on' => date('Y-m-d H:i:s'),
            'updated_by'=>1
        );
        $this->db->insert('categories', $insert_data);
        return $this->db->affected_rows();
    }
}
