<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Datatable_model extends CI_Model {

	public function table_items_count($table){
		$query = $this->db->get($table);
		return $query->num_rows();
	}

	public function all_items($limit,$start,$col,$dir, $table, $select = '*'){
		$this->db->select($select);
		$this->db->join('users', 'users.id = '.$table.'.user_id');
		$query = $this->db
				->limit($limit,$start)
				//->order_by($col,$dir)
				->get($table);

		if($query->num_rows()>0)
            return $query->result(); 
        else
            return null;
        
	}

	function item_search($limit,$start,$search,$col,$dir, $table, $select)
    {
    	$this->db->select($select);
		$this->db->join('users', 'users.id = '.$table.'.user_id');
        $query = $this->db
        	->like($table.'.id',$search)
        	->or_like('address',$search)
        	->limit($limit,$start)->order_by($table.'.'.$col,$dir)->get($table);
        
       
        if($query->num_rows()>0)
            return $query->result();  
        else
            return null;
    }

    function item_count_search($search, $table)
    {

        $query = $this->db
                ->like('id',$search)
        		->or_like('address',$search)
                ->get($table);
        return $query->num_rows();
    }
} 
?>