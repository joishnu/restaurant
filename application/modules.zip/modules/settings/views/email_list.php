<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Settings <small>Email Templates</small></h3>
      </div>
    </div>
    <div class="title_right">
      <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search" style="text-align: right">
        <a href="<?=base_url('settings/edit');?>" class="btn btn-primary"> <i class="fa fa-plus"></i> Add Template</a>
      </div>
    </div>
  </div>
    <div class="clearfix"></div>
    <!-- category list -->
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Templates List</h2>
              <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                
              </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <p class="text-muted font-13 m-b-30"><!-- If you want to write somting you can write here --></p>
            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Subject</th>
                  <th>Status</th>
                  <th>Attachment</th>
                  <th>Description</th>
                  <th>Extra Info</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($emails as $key => $value) { ?>
                  <tr>
                    <td></td>
                    <td><?php echo $value['subject']; ?></td>
                    <td><?php echo ($value['status']==1)?"Active" : "In-Active" ; ?></td>
                    <td><?php echo ($value['attachment'])?'<a target="_BLANK" href="'.base_url('assets/uploads/extras/').$value['attachment'].'">Download</a>':'N/A'; ?></td>
                    <td><?php echo $value['description']; ?></td>
                    <td><?php echo $value['extra_details']; ?></td>
                    <td><a href="<?php echo base_url('/settings/edit/'.$value['id']) ?>">
                      <button class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</button>
                    </a>
                    </td>
                  </tr>
                  
                <?php } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

