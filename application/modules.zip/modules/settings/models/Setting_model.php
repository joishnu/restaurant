<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Setting_model extends CI_Model {

    public function emails(){
    	return $this->db->get('email_templates')->result_array();
    }

     public function add($data){
        return $this->db->insert('email_templates',$data);
    }

    public function update($data, $id){
        $this->db->where('id', $id);
        return $this->db->update('email_templates', $data);
    }

    public function info($id){
        $this->db->where('id', $id);
        return $this->db->get('email_templates')->row_array();
    }
} 
?>