<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * 
 */
class settings extends CI_Controller{
	
	function __construct(){
		parent::__construct();
		$this->load->library('external');
		$this->load->model('setting_model', 'setting');
	}

	public function emails(){
		$data['title'] = 'Settings';
		$data['page'] = 'email_list';
		$data['emails'] = $this->setting->emails();
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();       
		$this->load->view('template',$data);       
	}

	public function edit($mail_id=null){
		$this->form_validation->set_rules('subject','subject','required');
		$this->form_validation->set_rules('descr','descr','required');
		if ($this->form_validation->run() == FALSE){
			echo validation_errors();			
			$data['title'] = 'Email Management';
			$data['page'] = 'email_edit';

			if($mail_id != null){

				$data['info'] = $this->setting->info($mail_id);
			}
			$data['extra_datatable_data'] = $this->external->textarea();       
			$data['extra_datatable_data'] .= '<script type="text/javascript">
												  function uploadValueToText() {
												    var val = $("#editor-one").html();
												    $("#descr").val(val);
												  }
												</script>';       
			$this->load->view('template',$data); 
		}else{
			$array = array(
				'subject'=>$this->input->post('subject'),
				'description'=>$this->input->post('descr'),
				'extra_details'=>$this->input->post('extra'),
				'updated_on'=>date("Y-m-d h:i:s")
			);


			if(isset($_FILES['attachment'])){
	            foreach ($_FILES['attachment']['name'] as $key => $value) {
	                $_FILES['images[]']['name']= $_FILES['attachment']['name'][$key];
	                $_FILES['images[]']['type']= $_FILES['attachment']['type'][$key];
	                $_FILES['images[]']['tmp_name']= $_FILES['attachment']['tmp_name'][$key];
	                $_FILES['images[]']['error']= $_FILES['attachment']['error'][$key];
	                $_FILES['images[]']['size']= $_FILES['attachment']['size'][$key];
					unset( $config);
	                $config['upload_path']          = './assets/uploads/extras/';
	                $config['allowed_types']        = 'gif|jpg|png|jpeg|doc|docx|pdf|csv';
	                $config['max_size']             = '*';
	                $config['max_width']            = '*';
	                $config['max_height']           = '*';
	                $config['file_name']            = date('ymdHis').mt_rand(1000,99999) ;
	                $images = array();
	                $this->load->library('upload', $config);

	                if ( ! $this->upload->do_upload('images[]')){
	                    $error = array('error' => $this->upload->display_errors());
	                    print_r($error);
	                    break;
	                }else{
	                    $data = array('upload_data' => $this->upload->data());
	                    $arr[]=  $data['upload_data']['raw_name'].$data['upload_data']['file_ext'];
	                }
	            }
	            if(isset($arr)){
	                $array['attachment'] = implode(',', $arr);
	                unset($arr);
	            }
	        }


			if($this->input->post('mail_id')){
				$this->setting->update($array,$this->input->post('mail_id'));
			}
			else{
				$this->setting->add($array);
			}

			redirect('/settings/emails', 'refresh');
		}
	}


}
?>