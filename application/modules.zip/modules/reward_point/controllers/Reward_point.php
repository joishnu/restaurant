<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Reward_point extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->library('external');
		$this->load->model('reward_point_model','reward');
	}

	public function index()
	{
		$data['title'] = 'Reward point';
		$data['reward'] = $this->reward->reward_detail();
		$data['page'] = 'index';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();
		$this->load->view('template',$data);
	}

	public function do_update_reward()
	{
		try{
			$this->form_validation->set_rules('id', 'ID', 'trim|required');
			$this->form_validation->set_rules('reward_amount', 'fieldlabel', 'trim|required');
			if(!$this->form_validation->run()) {
				throw new Exception(validaton_errors(), 1);
			}
			$post_data = $this->input->post();
			$result = $this->reward->update_reward($post_data);
			if(!$result){
				throw new Exception("Not updated successfully.", 1);
			}
			$this->session->set_flashdata('success', "Updated successfully.");
		}catch(Exception $e){
			$this->session->set_flashdata('error', $e->getMessage());
		}
		redirect(site_url('reward_point'));
	}
}