<?php

if (!defined('BASEPATH'))exit('No direct script access allowed');

class Reward_point_model extends CI_Model {

	public function reward_detail()
	{
		$this->db->select('');
		$this->db->where('id', 1);
		$result = $this->db->get('reward_point')->row_array();
		return $result;
	}

	public function update_reward($data)
	{	
		
		$update_data = array(
			'amount' => $data['reward_amount'],
		);
		$this->db->where('id', $data['id']);
		$this->db->update('reward_point', $update_data);
		return $this->db->affected_rows();
	}
}