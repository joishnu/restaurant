<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3><?php echo $title;?></h3>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <?php $this->load->view('includes/show_flashdata'); ?>   
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2><?php echo $title;?></h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="x_content">
                        <form class="form-horizontal form-label-left" enctype="multipart/form-data" novalidate id="admin_update_form" method="post" action="<?=base_url('reward_point/do_update_reward')?>" data-toggle="validator" data-disable="false">
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Reward Amount(in %)<span class="required">*</span></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input class="form-control col-md-7 col-xs-12"  name="reward_amount" placeholder="Please enter amount" required="required" type="text" value="<?php echo $reward['amount'];?>">
                                    <input class="form-control col-md-7 col-xs-12"  name="id" placeholder="Please enter name" required="required" type="hidden" value="<?php echo $reward['id'];?>">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-3">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>