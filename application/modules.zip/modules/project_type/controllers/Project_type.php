<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Project_type extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('project_type_model','product');
		$this->load->library('external');
	}

	public function index(){
		$data['title'] = 'Project Type Management';
		$data['page'] = 'project_type';       
		$project=$this->product->get_type_details();
		$data['area']=$project;
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();     
		$data['extra_datatable_data'] .= $this->external->validation_extra_js_css();     
		$data['extra_datatable_data'] .= $this->external->dropdown_search(); 
		$data['extra_datatable_data'] .= 
						'<script type="text/javascript">
							$(document).ready(function (){
							    $("#product").DataTable({
							        "processing": true,
							        "serverSide": true,
							        "ajax":{
							            "url": "'.base_url('project_type/project_list').'",
							            "dataType": "json",
							            "type": "POST",
							            "data":{
							              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
							            }
							        },
							        "columns": [
							          { "data": "id" },
							          { "data": "name" },
							          { "data": "description" },
							          { "data": "image" },
							          { "data": "status" },
							          { "data": "created_on" },
							          { "data": "action" },
							        ]
							    });
							});
							function edit_func(id){
								$.ajax({
									url: "'.base_url('project_type/project_name').'",
									data: { 
										"number": id, 
									},
									cache: false,
									type: "POST",
									success: function(response) {
										$("#id_design_hid").val(id);
										var vl=JSON.parse(response);
										$("#area_edit").append(vl.option);
										$("#name").val(vl.project.name);
										$("#description").val(vl.project.description);
										$("#form-img").attr("src",vl.project.image);
										
									},
									error: function(xhr) {
										console.log(xhr);
									}
								});
								$("#edit-item").modal("show");
								
							}

							function change_status(that){
								var number = $(that).attr("data-number");
								var status = $(that).val();
								$.ajax({
									url: "'.base_url('project_type/change_status').'",
									data: { 
										"number": number, 
										"status": status
									},
									cache: false,
									type: "POST",
									success: function(response) {
										$("#product").DataTable().ajax.reload();
									},
									error: function(xhr) {
										console.log(xhr);
									}
								});
							}
							 $(".form-image").on("click", function(){
						            $(this).parents(".form-group").find("input[type=file]").trigger("click");
						        });
						        $("input[name=image]").on("change", function(event) {
						            if ($(this).val() !== "") {
						                read_image(event, ".user-image-trigger");
						            } else {
						                $(".user-image-trigger").attr({"src":base_url("assets/img/choose-an-image.jpg"),"width":"150px","height":"150px"});
						            }
						        });

							    $("#area").select2({
							        placeholder: "Select Area",
							        width: "resolve" 
							     
							    });
							    $("#area_edit").select2({
							        placeholder: "Select Area",
							        width: "resolve" 
							     
							    });

							    
							</script>

											';
											//print_r($data['extra_datatable_data']);exit();
		$this->load->view('template',$data);
	}

	public function project_name(){
		$info=$this->input->post(NULL,true);
		$project=$this->product->get_project_name($info);
		$area=$this->product->get_type_details();
		$cnt=count($area);
		$selected=$this->product->area_project_type_relation($info['number']);
		$cnt=count($area);
		$htm="";
	    for ($i=0;$i<=$cnt-1;$i++){
	      if(in_array($area[$i]['id'], array_column($selected, 'area_id')))
	      	{$a="selected";}
	      else
	      {
	      	$a="";
	      }

	        $htm.='<option value="'.$area[$i]['id'].'" '.$a.'>'.$area[$i]['name'].'</option>';
	    }
	    $final['project']=$project;
	    $final['option']=$htm;
			echo json_encode($final);
		}

	// Product List ajax call for product list datatable
	public function project_list(){
		$columns = array(
			0 => "id",
			1 => "name",
			2 => "description",
			3 => "image",
			4 => "status",
			5 => "created_on",
			6 => "action"
		);

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
        $totalData = $this->product->table_items_count('project_types');

        $totalFiltered = $totalData; 
        if(empty($this->input->post('search')['value'])){
        	$posts = $this->product->all_items($limit,$start,$order,$dir, 'project_types', "status,name, id, created_on,image,description");
        }else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->product->item_search($limit,$start,$search,$order,$dir, 'project_types', "status,name, id, created_on,image,description");
            $totalFiltered = $this->product->item_count_search($search,  'Project_types');
        }
  		$data = array();
		if(!empty($posts)){
			$j=0;
			foreach ($posts as $post){
				$j++;
			
				$nestedData['id'] = $j;
				$nestedData['name'] = $post->name;
				$nestedData['description'] = $post->description;
				$extr_img=explode(',', $post->image);
				$img="";
				$img1="";
				$cnt=count($extr_img)-1;
				if($cnt>0){
					for($j=0;$j<=$cnt-1;$j++)
					{
						$img.= '<img src="'.IMGS_URL."uploads/project_types/".$extr_img[$j].'" width="50%">';
					}
				}
				else{
					$img1.= '<img src="'.IMGS_URL."uploads/project_types/".$post->image.'" width="50%">';
				}

				$nestedData['image']=$img.$img1;
				$nestedData['status'] = '<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
					<option value="0" '.(($post->status == 0)? 'selected="selected"' :" ").' >Deactivate </option>
					<option value="1" '.(($post->status == 1)? 'selected="selected"' :" ").'>Activate</option>
				</select>';
				$nestedData['created_on'] = $post->created_on;
				$nestedData['action'] = '
				<button class="btn btn-primary edit" onclick="edit_func('.$post->id.')"><i class="fa fa-pencil" ></i> Edit</button><a href="'.base_url('/project_type/delete').'/'.$post->id.'"><button class="btn btn-danger"><i class="fa fa-remove" ></i> Delete</button></a><!--<a data-toggle="modal" data-target=".bs-example-modal-lg"><button class="btn btn-primary"><i class="fa fa-pencil"></i> View</button></a>-->
				';
					$data[] = $nestedData;
			}
		}

		$json_data = array(
		"draw"            => intval($this->input->post('draw')),  
		"recordsTotal"    => intval($totalData),  
		"recordsFiltered" => intval($totalFiltered), 
		"data"            => $data   
		);
		echo json_encode($json_data); 
	}


	public function delete($id = 0)
    {
        try {
            if(!$id) {
                throw new Exception('Choose a project', 1);
            }
            $rs = $this->product->do_delete($id);

            if(!$rs){
                throw new Exception("Error Processing Request", 1);   
            }

            $this->session->set_flashdata('success', 'Project is deleted successfully');
            redirect(site_url('project_type'));

        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(site_url('project_type'));

        }
    }

	public function do_add_project_type() {
		  try {
            $this->form_validation->set_rules('name', 'Project Type Name', 'trim|required');
            $this->form_validation->set_rules('description', 'Description', 'trim|required');
           if(!$this->form_validation->run()){
                throw new Exception(validation_errors());
            }
            $info = $this->input->post(NULL, TRUE);
            //$this->product->validate_name($info['name']);
            if(empty($_FILES) || !isset($_FILES['image']) || $_FILES['image']['error']){
                throw new Exception("Please upload image");   
            }
            $image=upload_file('image','project_types');
            if(!$image){
                throw new Exception("Error in uploading image");
            }
            $info['image']=$image;

            $rs = $this->product->do_add_project_type($info);
            if(!$rs) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->session->set_flashdata('success', "Project Type is added successfully!");
            redirect(site_url('project_type'));
        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(site_url('project_type'));
        }
	}

	public function do_update_project() {
		try{
	        $this->form_validation->set_rules('name', 'Project Type Name', 'trim|required');
            $this->form_validation->set_rules('description', 'Description', 'trim|required');
	        $info = $this->input->post(NULL, TRUE);

	        if (!$this->form_validation->run()) {
	            throw new Exception(validation_errors());
	        }

	        $details=$this->product->get_type_details($info['id']);
	        
	        $image=upload_file('image','project_types');
	        if($image!=false){
	            $info['image']=$image;
	        }
	        
	        $this->product->do_update_project($info);
	        if(!is_bool($image) && $image!=false){
	            unlink(IMGS_RMV.'/uploads/project_types/'.$details['image']); 
	        }
	        $this->session->set_flashdata('success', 'project is updated successfully');
	        redirect(site_url('project_type'));
	    }catch(Exception $e){
	        $this->session->set_flashdata('error', $e->getMessage());
	        redirect(site_url('project_type'));
	    }
	}

	public function change_status() {
		$info = $this->input->post(NULL,true);
		$this->form_validation->set_rules('number','number','trim|required');
	    echo json_encode($this->product->change_status($info));
	}

}
