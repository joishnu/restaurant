<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Model for Design Management
 */
class Project_type_model extends CI_Model
{
	
	// for datatable
    public function table_items_count($table){
        $query = $this->db->get($table);
        return $query->num_rows();
    }

    public function all_items($limit,$start,$col,$dir, $table, $select = '*'){
        $this->db->select($select);
        $query = $this->db
                ->limit($limit,$start)
                ->where('status<>','3')
                //->order('products.id','desc')
                ->get($table);


        if($query->num_rows()>0)
            return $query->result(); 
        else
            return null;
    }

    function item_search($limit,$start,$search,$col,$dir, $table, $select)
    {
        $this->db->select($select);
        $query = $this->db
            ->like($table.'.id',$search)
            ->or_like($table.'.name',$search)
            ->limit($limit,$start)->order_by($table.'.'.$col,$dir)->get($table);
        
        if($query->num_rows()>0)
            return $query->result();  
        else
            return null;
    }

   public function item_count_search($search, $table)
    {

        $query = $this->db
                ->like('id',$search)
                ->or_like('name',$search)
                ->get($table);
        return $query->num_rows();
    } 

    public function get_project_name($id)
    {
         return $this->db->select('name, description, CONCAT("'.IMGS_URL.'uploads/project_types/", image) as image')->where('id', $id['number'])->get('project_types')->row_array();

    }

    public function get_project_type_info() {
        $this->db->select('*');
        return $this->db->get_where('project_types', array('status' => '1'))->result_array();
    }

    public function do_add_project_type($params = []){
        try { 
            $this->db->trans_begin();

            $insert_data = array(
                'name'    => $params['name'],
                'image'    => $params['image'],
                'description'  => $params['description'],
                'status'  => '1',
                'created_on' => date('Y-m-d H:i:s')
            );

            if(!$this->db->insert('project_types', $insert_data))
            {
                throw new Exception("Error Processing Request", 1);
            }

            $project_id=$this->db->insert_id();    

            $cnt=count($params['area']);

            for($i=0;$i<=$cnt-1;$i++)
            {
                $insert_area[]= array('project_type_id' => $project_id, 'area_id' => $params['area'][$i],'created_on'=> date('Y-m-d H:i:s'));
            }

            if(!$this->db->insert_batch('area_project_type_relation', $insert_area))
            {
                throw new Exception("Error Processing Request", 1);
            }

            $this->db->trans_commit();
            return TRUE;
            
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return FALSE;
        }
    }

    public function do_update_project($params) {
        try {
            $this->db->trans_begin();
            $update_data = array(
                'name'    => $params['name'],
                'description'  => $params['description'],
                'updated_on' => date('Y-m-d H:i:s')
            );
            if(isset($params['image']) && !empty($params['image']) && !is_bool($params['image'])){
                $update_data['image']=$params['image'];
            }
            $where = array(
                'id' => $params['id']
            );
            $this->db->update('project_types', $update_data, $where);

            if(!$this->db->affected_rows()) {
                throw new Exception("Error Processing Request", 1);
            }

             $cnt=count($params['area_edit']);
            for($i=0;$i<=$cnt-1;$i++)
            {
                $result=$this->db->select('id,area_id')->where('area_id',$params['area_edit'][$i])->where('project_type_id',$params['id'])->get('area_project_type_relation')->row_array();    
                if($result)
                {
                    $exists[]= array('id' => $result['id']);
                }
                else
                {
                    $not_exists[]= array('project_type_id' => $params['id'], 'area_id' => $params['area_edit'][$i],'created_on'=> date('Y-m-d H:i:s'));
                }
            }

            if($not_exists)
            {

                if(!$this->db->insert_batch('area_project_type_relation', $not_exists))
                {
                    throw new Exception("Error Processing Request", 1);
                }
            }

            $result=$this->db->select('id')->where_not_in('area_id',$params['area_edit'])->where('project_type_id',$params['id'])->get('area_project_type_relation')->result_array();    

            $cnt=count($result);
            for($i=0;$i<=$cnt-1;$i++)
            {
                $rs[]=$result[$i]['id'];
            }

            if($result)    
            {  
                if(!$this->db->where_in('id', $rs)->delete('area_project_type_relation'))
                {
                    throw new Exception("Error Processing Request", 1);
                }
            }

            $this->db->trans_commit();
            return 1;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function get_type_details(){
        return $this->db->select("*")->where('status','1')->get('area_type')->result_array();
    }

    public function area_project_type_relation($id){
        return $this->db->select("*")->where('project_type_id',$id)->get('area_project_type_relation')->result_array();
    }

    public function do_delete($id)
    {
        try {
            $this->db->trans_begin();
            $this->db->set('status',"3");      
            $this->db->set('updated_on',date('Y-m-d H:i:s'));
            $this->db->where('id',$id);
            $this->db->update('project_types');
            if(!$this->db->affected_rows()) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }


    public function change_status($params) {
        try {
            $this->db->trans_begin();
            $where= array('id' => $params['number'] );
            $update_data = array(
                'status' =>$params['status'],
                'updated_on'=>date('Y-m-d H:i:s')
            );

            if(!$this->db->update('project_types', $update_data, $where))
            {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

}


?>