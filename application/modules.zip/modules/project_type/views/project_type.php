<div class="right_col" role="main">
   <div class="">
      <div class="page-title">
         <div class="title_left">
            <h3>
               Project Type Management <small>| Project Type List</small><!-- <a href="javascript:void(0);" class="btn btn-success btn-block pull-right" role="button">Add Product</a> -->
            </h3>
         </div>
      </div>
      <div class="title_right">
         <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search" style="text-align: right">
            <a href="#" class="btn btn-primary pull-right" data-toggle="modal" data-target=".bs-example-modal-lg"> <i class="fa fa-plus"></i> Add Project Type </a><br>
         </div>
      </div>
   </div>
   <div class="clearfix"></div>
   <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
         <div class="x_panel">
            <div class="x_title">
               <h2>Project Area List<small>All Project Type</small> </h2>
               <ul class="nav navbar-right panel_toolbox">
                  <!-- <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li> -->
                  <!-- <li><a class="close-link"><i class="fa fa-close"></i></a></li> -->
               </ul>
               <div class="clearfix"></div>
            </div>
            <div class="x_content">
               <div class="row">
                  <?php $this->load->view('includes/show_flashdata'); ?>
               </div>
               <p class="text-muted font-13 m-b-30">
                  <!-- If you want to write somting you can write here -->
               </p>
               <table id="product" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                  <thead>
                     <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Image</th>
                        <th>Status</th>
                        <th>Created On</th>
                        <th>Action</th>
                     </tr>
                  </thead>
                  <tbody>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
<!-- Add Variation modal -->
<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
            </button>
            <h4 class="modal-title" id="myModalLabel">Add Project Type</h4>
         </div>
         <div class="modal-body">
            <form class="form-horizontal form-label-left"  action="<?php echo base_url('project_type/do_add_project_type');?>" method="post" enctype="multipart/form-data" data-toggle="validator">
               <div class="form-group">
                  <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Project Type Name <span class="required">*</span>
                  </label>
                  <div class="col-md-6 col-sm-6 col-xs-12">
                     <input type="text"  required="required" class="form-control col-md-7 col-xs-12" name="name">
                  </div>
               </div>
               <div class="form-group">
                  <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Area Name<span class="required">*</span>
                  </label>
                  <div class="col-md-6 col-sm-6 col-xs-12">
                     <select name="area[]" class="form-control select2" multiple="" required="" id="area" style="width:100%;">
                        <?php $cnt=count($area);
                           for ($i=0;$i<=$cnt-1;$i++){?>
                        <option value="<?php echo $area[$i]['id'];?>"><?php echo $area[$i]['name'];?></option>
                        <?php } ?>
                     </select>
                  </div>
               </div>
               <div class="form-group">
                  <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Description <span class="required">*</span>
                  </label>
                  <div class="col-md-6 col-sm-6 col-xs-12">
                     <textarea name="description" required="required" class="form-control col-md-7 col-xs-12" placeholder="Design Description" required=""></textarea>
                  </div>
               </div>
               <div class="form-group">
                  <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Project type Image <span class="required">*</span>
                  </label>
                  <div class="col-md-6 col-sm-6 col-xs-12">
                     <img src="<?=base_url('assets/img/choose-an-image.jpg')?>" class="img-responsive img-thumbnail user-image-trigger form-image" width="150px" height="150px">
                     <input type="file" name="image"  accept="image/*" class="hidden form-control"  required="">
                     <span class="help-block with-errors"></span>
                  </div>
               </div>
         </div>
         <div class="modal-footer">
         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
         <button type="submit" class="btn btn-primary">Save</button>
         </div>
         </form>
      </div>
   </div>
</div>
<!-- Edit Variation modal -->
<div class="modal fade" tabindex="-1" role="dialog" aria-hidden="true" id="edit-item">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
            </button>
            <h4 class="modal-title" id="myModalLabel">Edit Project Type</h4>
         </div>
         <div class="modal-body">
            <form class="form-horizontal form-label-left" action="<?php echo base_url('project_type/do_update_project');?>" method="post" enctype="multipart/form-data" data-toggle="validator">
               <div class="form-group">
                  <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Project Type Name <span class="required">*</span>
                  </label>
                  <div class="col-md-6 col-sm-6 col-xs-12">
                     <input type="text" id="name" required="required" class="form-control col-md-7 col-xs-12" name="name">
                     <input type="hidden" placeholder="" name="id" id="id_design_hid" class="form-control">
                  </div>
               </div>
               <div class="form-group">
                  <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Area Name<span class="required">*</span>
                  </label>
                  <div class="col-md-6 col-sm-6 col-xs-12">
                     <select name="area_edit[]" class="form-control select2" multiple="" required="" id="area_edit" style="width:100%;">
                     </select>
                  </div>
               </div>
               <div class="form-group">
                  <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Description <span class="required">*</span>
                  </label>
                  <div class="col-md-6 col-sm-6 col-xs-12">
                     <textarea name="description" required="required" class="form-control col-md-7 col-xs-12" placeholder="Design Description" id="description"></textarea>
                  </div>
               </div>
               <div class="form-group">
                  <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Project type Image <span class="required">*</span>
                  </label>
                  <div class="col-md-6 col-sm-6 col-xs-12">
                     <img src="<?=base_url('assets/img/choose-an-image.jpg')?>" class="img-responsive img-thumbnail user-image-trigger form-image" id="form-img" width="150px" height="150px">
                     <input type="file" name="image"  accept="image/*" class="hidden form-control">
                     <span class="help-block with-errors"></span>
                  </div>
               </div>
         </div>
         <div class="modal-footer">
         <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
         <button type="submit" class="btn btn-primary">Update</button>
         </div>
         </form>
      </div>
   </div>
</div>