<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Model for Design Management
 */
class Checklist_model extends CI_Model
{
	
	// for datatable
    public function table_items_count($table){
        $query = $this->db->where('status<>','2')->get($table);
        return $query->num_rows();
    }

    public function all_items($limit,$start,$col,$dir, $table, $select = '*'){
        $this->db->select($select);
        $query = $this->db
                ->limit($limit,$start)
                ->where('status<>','2')
                //->order('products.id','desc')
                ->get($table);


        if($query->num_rows()>0)
            return $query->result(); 
        else
            return null;
    }

    public function item_search($limit,$start,$search,$col,$dir, $table, $select)
    {
        $this->db->select($select);
        $query = $this->db
            ->like($table.'.id',$search)
            ->or_like($table.'.name',$search)
            ->or_like($table.'.description',$search)
            ->limit($limit,$start)->order_by($table.'.'.$col,$dir)->get($table);
        
        if($query->num_rows()>0)
            return $query->result();  
        else
            return null;
    }

    public function all_category_items(){
        return $this->db->select('id, name')->where('parent_id is NOT NULL', NULL, TRUE)->get('categories')->result_array();
        
    }

    function item_count_search($search, $table)
    {

        $query = $this->db
                ->like('id',$search)
                ->or_like('name',$search)
                ->or_like('description',$search)
                ->get($table);
        return $query->num_rows();
    } 

    public function get_checklist_name($id)
    {
        return $this->db->select('name, description')->where('id', $id['number'])->get('checklist')->row_array();
    }

    public function get_product_list($params)
    {
        return $this->db->select('name, id')->where('category_id', $params['cat_id'])->where('subcategory_id', $params['sub_cat_id'])->get('products')->result_array();
    }

    public function get_checklist_details($id){ 
        return $this->db->select("*")->where('id',$id)->get('checklist')->row_array(); 
    }

    public function do_add_checklist($params) {
        try {
            $this->db->trans_begin();
             
//echo "<pre>";print_r($params);exit();
            $insert_data = array(
                'name' => $params['master_prelst'],
                'status' => '1',
                'created_on'=>date('Y-m-d H:i:s')
            );

            if(!$this->db->insert('checklist', $insert_data))
            {
                throw new Exception("Error Processing Request", 1);
            }

            $insert_id = $this->db->insert_id();
            $insert_item=[];
             $cnt=count($params['sub_prelist']);
              if($cnt>=1)
              {
                for($i=0;$i<=$cnt-1;$i++)
                    {   
                        $cnt_item=0;
                        $t="tmp_".$i;
                        $cnt_item=count($params[$t]);
                        $prduct="";
                        if($cnt_item>=1)
                        {
                            for($j=0;$j<=$cnt_item-1;$j++)
                            {
                                if($j==0)
                                {
                                    $prduct=$params[$t][$j];    
                                }
                                else
                                {
                                    $prduct=','.$params[$t][$j];    

                                }
                                
                            }

                            $insert_item[] = array(
                                'master_checklist_id' => $insert_id,
                                'sub_checklist_name' => $params['sub_prelist'][$i],
                                'product_ids'=>$prduct,
                                'created_on'=>date('Y-m-d H:i:s')
                            );
                        }
                        
                    }    
              }
              else
              {
                    throw new Exception("Error Processing Request", 1);
              }
               
            if(count($insert_item)>=1)
            {  
                if(!$this->db->insert_batch('subchecklist', $insert_item))
                {
                    throw new Exception("Error Processing Request", 1);
                }
            }
            else{
                
                 throw new Exception("Error Processing Request", 1);
            }

            $this->db->trans_commit();
            return $insert_id;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function do_update_checklist($params) {
        try {
            $this->db->trans_begin();
            $this->db->set('name',$params['name']);      
            $this->db->set('description',$params['description']);
            $this->db->set('updated_on',date('Y-m-d H:i:s'));
            $this->db->where('id',$params['id']);
            $this->db->update('checklist');
            if(!$this->db->affected_rows()) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return 1;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function do_delete($id)
    {
        try {
            $this->db->trans_begin();
            $this->db->set('status',"2");      
            $this->db->set('updated_on',date('Y-m-d H:i:s'));
            $this->db->where('id',$id);
            $this->db->update('checklist');
            if(!$this->db->affected_rows()) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }


    public function change_status($params) {
        try {
            $this->db->trans_begin();
            $where= array('id' => $params['number'] );
            $update_data = array(
                'status' =>$params['status'],
                'updated_on'=>date('Y-m-d H:i:s')
            );

            if(!$this->db->update('checklist', $update_data, $where))
            {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

}


?>