<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Checklist Management <small>| Checklist</small><!-- <a href="javascript:void(0);" class="btn btn-success btn-block pull-right" role="button">Add Product</a> --></h3>
            </div>
        </div>
        <div class="title_right">
            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search" style="text-align: right">
                <a href="#" class="btn btn-primary pull-right" data-toggle="modal" data-target=".bs-example-modal-lg"> <i class="fa fa-plus"></i> Add New Checklist</a><br>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Checklist<small>All Checklist</small> </h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <!-- <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li> -->
                        <!-- <li><a class="close-link"><i class="fa fa-close"></i></a></li> -->
                        
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Masterlist Name :</label>
                            <input type="text" class="form-control" name="master_prelst" id="master_prelst" />
                        </div>
                    </div>
                </div>
                <div style="background: gainsboro;padding: 10px;margin-bottom: 20px;" id="sub" class="sub">
                 <button type="button" class="btn btn-success" value="Sublist" id="sublist_clone" style="float: right;">Copy <i class="fa fa-clone"></i></button>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Sublist Name :</label>
                                <input type="text" class="form-control" name="sub_prelist[]" id="sub_prelist" data-sublist="0"/>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <h3>Selected Products</h3>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Products</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody id="selProduct">
                                </tbody>
                                
                            </table>    
                        </div>
                        <div class="col-md-6">
                            <h3>App Products</h3>
                            <div class="form-group">
                                <label>Category :</label>
                                <select name="category_0_0[]" class="category form-control " id="category">
                                  <?php $cnt=count($category);
                                        for($i=0;$i<=$cnt-1;$i++){
                                        ?>
                                        <option value="<?php echo $category[$i]['id'];?>"><?php echo $category[$i]['name'];?></option>
                                 <?php }?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Subcategory :</label>
                                <select id="subcategory" required="" name="subcategory_0_0[]" class="subcategory form-control"></select>
                            </div>
                            <div class="form-group">
                                <label>Product Name :</label>
                                <select name="product_list_0_0[]" id="product_list" class="product_list form-control" multiple >
                                </select> 
                            </div>
                            <div class="form-group">
                                <button onclick="addProductToList(this)" class="btn btn-success" type="button">Add</button>
                            </div>
                        </div>

                    </div>
                </div>
                <div id="sublist_place"></div>

                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
                <br>
                <script type="text/javascript">
                    function addProductToList(obj){
                        var data=$('#product_list').select2('data');
                        var tblhtml='';
                        for(var i=0;i<data.length;i++){
                            tblhtml+='<tr>';
                            tblhtml+='<td>';
                            tblhtml+=data[i].text;
                            tblhtml+='</td>';
                            tblhtml+='<td>';
                            tblhtml+='<i onclick="removeSelectedProduct(this)" class="fa fa-trash" aria-hidden="true"></i>';
                            tblhtml+='</td>';
                            tblhtml+='<input type="hidden" name="tmp[]" class="temp" value="'+data[i].id+'">';
                            tblhtml+='</tr>';
                        }
                        $('#selProduct').append(tblhtml);
                        $('#product_list').select2().empty();
                        $('#subcategory').trigger('change');
                        //alert($('#product_list2').val());

                    }
                    function removeSelectedProduct(obj){
                        $(obj).parent().parent().remove();

                    }

            $('#sublist_clone').click(function () {
                $('.product_list').select2("destroy");
                var noOfDivs = $('.sub').length;
                var clonedDiv = $('.sub').first().clone(true);
                
                var vl=clonedDiv.find('[id="sub_prelist"]').attr('data-sublist');
                var cont=1;
                var final_vl=parseInt(noOfDivs);
                

                clonedDiv.find('[id="sub_prelist"]').attr('data-sublist', final_vl);
                clonedDiv.find('[id="sub_prelist"]').attr('name', 'sub_prelist_' +final_vl+'[]');
                
                clonedDiv.find('[id="category"]').attr('name', 'category_'+final_vl+'[]');
                clonedDiv.find('[id="subcategory"]').attr('name', 'subcategory_'+final_vl+'[]');
                clonedDiv.find('[id="product_list"]').attr('name', 'product_list'+final_vl+'[]');
                


                clonedDiv.insertBefore("#sublist_place");


                //clonedDiv.attr('id', 'tooltest' + noOfDivs);
                

                $('.product_list').select2({ //apply select2 to my element
                    placeholder: "Search Product",
                    allowClear: true
                });
            });
                </script>


                    <form class="form-horizontal form-label-left"  action="<?php echo base_url('checklist/do_add_checklist');?>" method="post" enctype="multipart/form-data">
                        <!--nested clone demo start-->
                            <!-- <div class="nest-clone demo-wrap">
                                <form class="form" method="post"> 
                                    <div class="toclone">
                                        <strong>Master Prelist</strong>
                                        <p class="name"> 
                                            <input type="text" name="master_prelst[]" id="master_prelst" /> 
                                        </p> 
                                        <div class="nest-clone inner-wrap">
                                            <div class="toclone">
                                                <strong>Sub Prelist</strong>
                                                <p class="email"> 
                                                    <input type="text" name="sub_prelist[]" id="sub_prelist" /> 
                                                </p> 
                                            
                                                <div class="nest-clone inner-inner-wrap">
                                                    <div class="toclone">
                                                        <strong>Category</strong>
                                                        <p class="phone"> 
                                                            <select id="category"  required="" name="category" class="category">
                                                              <?php $cnt=count($category);
                                                                    for($i=0;$i<=$cnt-1;$i++){
                                                                    ?>
                                                                    <option value="<?php echo $category[$i]['id'];?>"><?php echo $category[$i]['name'];?></option>
                                                             <?php }?>
                                                            </select>
                                                        </p>
                                                        <strong>Subcategory</strong>
                                                        <p class="phone"> 
                                                            <select id="subcategory" required="" name="subcategory" style="width: 82%;" class="subcategory">
                                                            </select>
                                                        </p>
                                                        <strong>Product Name</strong>
                                                        <p class="phone"> 
                                                            <select class="toollist" name="product_list[]" id="product_list" class="product_list form-control" multiple style="width: 82%;">
                                                            
                                                            </select> 
                                                        </p>  
                                                         <a href="#" class="clone"><button type="button"><i class="fa fa-plus"></i></button></a>
                                                        <a href="#" class="delete"><button type="button"><i class="fa fa-minus"></i></button></a>
                                                    </div>
                                                </div>
                                                <a href="#" class="clone"><button type="button"><i class="fa fa-plus"></i></button></a>
                                                <a href="#" class="delete"><button type="button"><i class="fa fa-minus"></i></button></a>
                                            </div>
                                        </div>
                                        <a href="#" class="clone"><button type="button"><i class="fa fa-plus"></i></button></a>
                                        <a href="#" class="delete"><button type="button"><i class="fa fa-minus"></i></button></a>
                                    </div>

                                </form>
                            </div> -->
                 <!--            Masterlist Name<input type="text" name="master_prelst" id="master_prelst" />  
                            <div id="sub" class="sub">
                            Sublist Name<input type="text" name="sub_prelist_0[]" id="sub_prelist" data-sublist="0"/> 
                            <div id="test">
                                <div id="tooltest0" class="tooltest0">
                                   <br> <label>Category :</label>
                                     <select id="category"  required="" name="category_0_0[]" class="category">
                                      <?php $cnt=count($category);
                                            for($i=0;$i<=$cnt-1;$i++){
                                            ?>
                                            <option value="<?php echo $category[$i]['id'];?>"><?php echo $category[$i]['name'];?></option>
                                     <?php }?>
                                    </select>
                                    <br><label>Subcategory :</label>
                                    <select id="subcategory" required="" name="subcategory_0_0[]" style="width: 82%;" class="subcategory">
                                                            </select>
                                                             
                                    <br><label>Product Name :</label>
                                    <select name="product_list_0_0[]" id="product_list" class="product_list form-control" multiple style="width: 82%;">
                                    </select> 
                                    <hr>
                                </div>
                                
                                <div>
                                    <input type="button" value="Items" id="items_clone"/>
                                </div>
                            </div>
                        </div>
                        <div id="tool-placeholder"></div>
                        <div id="sublist_place"></div>
                        <div>
                            <input type="button" value="Sublist" id="sublist_clone"/>
                        </div> -->
                <!-- clone ends here -->
                <button type="submit" class="btn btn-primary">Save changes</button>
                </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
   

<script type="text/javascript">
$(".category").on('change',function(){
    var id=$(this).val();
    var thisobj=$(this);
    $.ajax({
        type:"POST",
        url:"<?php echo site_url();?>product_vendor/get_sub_category",
        data:{'id':id},
        dataType:'json',
        success: function(response){ 
            var ln=response.length;
            if(ln>=1){
                var cnt;
                for(var i=0;i<=ln-1;i++){
                    cnt+='<option value="'+response[i]['id']+'">'+response[i]['name']+'</option>';
                }
                console.log(thisobj);
                 thisobj.parent().parent().find('.subcategory').html('').html(cnt);
                //thisobj.parent().find('#subcategory2').html('').html(cnt);    
                //$('.subcategory').html(cnt);
            }
        }
    });
});
    var id=$('.category').val();
     $.ajax({
            type:"POST",
            url:"<?php echo site_url();?>product_vendor/get_sub_category",
            data:{'id':id},
            dataType:'json',
       success: function(response)
       { 
        var ln=response.length;
        if(ln>=1)
        {
           var cnt;
            for(var i=0;i<=ln-1;i++)
            {
              cnt+='<option value="'+response[i]['id']+'">'+response[i]['name']+'</option>';
             
            }

            $('.subcategory').html('');
            $('.subcategory').html(cnt);
           
        }
        }
      });


$(".subcategory").on('change',function(){
    var thisobj=$(this);
    var id=$(this).val();
    var cat_id=$('#category').val();
    var thisobj=$(this);
    $.ajax({
        type:"POST",
        url:"<?php echo site_url();?>checklist/get_product_list",
        data:{'sub_cat_id':id, 'cat_id':cat_id },
        dataType:'JSON',
        success: function(response){ 
            //console.log(response);
            var ln=response.length;
            if(ln>=1){
                var cnt="";
                var cnt1=[];
                for(var i=0;i<=ln-1;i++){
                  cnt+='<option value="'+response[i]['id']+'">'+response[i]['name']+'</option>';
                  var b;
                  b={ id :response[i]['id'],text:response[i]['name'] };
                  cnt1.push(b);
                }
                var newOption = new Option(cnt1.text, cnt1.id, false, false);
                
                //thisobj.parent().find('.product_list').html('').html(cnt);    
                thisobj.parent().parent().find('.product_list').select2('destroy').empty();
                thisobj.parent().parent().find('.product_list').select2().select2({'data':cnt1});
                //$('#product_list').select2().select2({'data':cnt1});
                //.append(cnt1).trigger('change');
                /*$('.product_list').html('');
                $('.product_list').html(cnt);*/
            }else{
                thisobj.parent().parent().find('.product_list').select2('destroy').empty();
                thisobj.parent().parent().find('.product_list').select2();
            }
        }
    });
});
    

    $('.product_list').select2({ //apply select2 to my element
        placeholder: "Search your Tool",
        allowClear: true
    }); 


   /* $('#items_clone').click(function () {

        $('.product_list').select2("destroy");
        var noOfDivs = $('.tooltest0').length;

        var clonedDiv = $('.tooltest0').first().clone(true);
        
        
        clonedDiv.attr('id', 'tooltest' +noOfDivs );
      
        var noOfDiv=parseInt(noOfDivs)-1;

        var vl=clonedDiv.parent().parent().find('[id="sub_prelist"]').attr("data-sublist");

        clonedDiv.parent().parent().find('[id="sub_prelist"]').attr('name', 'sub_prelist_' +vl+'[]');
        
       
        clonedDiv.find('[id="category"]').attr('name', 'category_'+vl+'_'+noOfDiv+'_[]');
        clonedDiv.find('[id="subcategory"]').attr('name', 'subcategory_'+vl+'_'+noOfDiv+'_[]');
        clonedDiv.find('[id="product_list"]').attr('name', 'product_list'+vl+'_'+noOfDiv+'_[]');

        //clonedDiv.parent().parent().find('name="sub_prelist_'+vl+'[]"]').insertBefore("#tool-placeholder");
        clonedDiv.insertBefore("#tool-placeholder");
        
        $('.product_list').select2({ //apply select2 to my element
            placeholder: "Search Product",
            allowClear: true
        });
    });


    $('#sublist_clone').click(function () {
        $('.product_list').select2("destroy");
        var noOfDivs = $('.sub').length;
        var clonedDiv = $('.sub').first().clone(true);
        

        var vl=clonedDiv.find('[id="sub_prelist"]').attr('data-sublist');
        var cont=1;
        var final_vl=parseInt(noOfDivs);
        

        clonedDiv.find('[id="sub_prelist"]').attr('data-sublist', final_vl);
        clonedDiv.find('[id="sub_prelist"]').attr('name', 'sub_prelist_' +final_vl+'[]');
        
        clonedDiv.find('[id="category"]').attr('name', 'category_'+final_vl+'_'+noOfDivs+'_[]');
        clonedDiv.find('[id="subcategory"]').attr('name', 'subcategory_'+final_vl+'_'+noOfDivs+'_[]');
        clonedDiv.find('[id="product_list"]').attr('name', 'product_list'+final_vl+'_'+noOfDivs+'_[]');
        


        clonedDiv.insertBefore("#sublist_place");


        //clonedDiv.attr('id', 'tooltest' + noOfDivs);
        

        $('.product_list').select2({ //apply select2 to my element
            placeholder: "Search Product",
            allowClear: true
        });
    });*/
</script>