<?php
/**
 * 
 */
class Order_model extends CI_Model
{
	
	public function table_items_count($table){

        $this->db->join('orders','orders.id=order_details.order_id');
        $this->db->join('transaction', 'transaction.id = orders.txn_id');
        $this->db->where('orders.payment_status', '1');
        if($this->session->userdata('user_type')=='2')
        {
            $this->db->where('order_details.vendor_id', $this->session->userdata('id') );    
        }
		$query = $this->db->get($table);
		return $query->num_rows();
	}

    public function table_items_count_cancel($table){

        $this->db->join('orders','orders.id=order_details.order_id');
        $this->db->join('transaction', 'transaction.id = orders.txn_id');
        $this->db->where('orders.payment_status', '1');
        $this->db->where("order_details.order_status=4 or order_details.order_status=5 or order_details.order_status=7");
        if($this->session->userdata('user_type')=='2')
        {
            $this->db->where('order_details.vendor_id', $this->session->userdata('id') );    
        }
        $query = $this->db->get($table);
        return $query->num_rows();
    }

    public function table_items_count_return($table){

        $this->db->join('orders','orders.id=order_details.order_id');
        $this->db->join('transaction', 'transaction.id = orders.txn_id');
        $this->db->where('orders.payment_status', '1');
        $this->db->where("order_details.order_status=8 or order_details.order_status=9 or order_details.order_status=10");
        if($this->session->userdata('user_type')=='2')
        {
            $this->db->where('order_details.vendor_id', $this->session->userdata('id') );    
        }
        $query = $this->db->get($table);
        return $query->num_rows();
    }


	public function all_items($limit,$start,$col,$dir, $order_status = 1){

		$this->db->select('o.id,o.sub_pub_id, o.price as per_total_price, orders.total_price as whole_total_price,o.quantity as total_quanity,orders.tax as whole_total_tax, o.order_status, p.name, v.vendor_name, u.first_name, u.last_name, o.quantity, orders.public_id,o.custom_value, o.custom_description, o.custom_image, o.store_id, o.delivery_type, o.executive_id as delivery_executive_id, o.order_status, orders.address_id,orders.payment_status, concat(store_name,", ", store_address) as store_address,d.member_id, d.name as executive_name, d.address as executive_address, concat(d.country_code," ",d.phone) as executive_phone, d.email_id as executive_email, concat(u.first_name, 
            " ", last_name) as customer_name, concat(u.country_code, " ", u.phone) as customer_phone, u.email as customer_email,u.account_type, u.status as customer_status, concat(ad.address_line1,", ",ad.address_line2,", ", ad.address_line3,", ", pincode, ", ", ad.city,", ", ad.state, ", ",ad.country) as customer_address,s.store_name, s.store_address,o.cancel_reason,o.return_reason,transaction.payuMoneyId as transcation_id');
        $this->db->join('addresses as ad', 'ad.id = o.address_id',"left");  
        $this->db->join('stores as s', 's.id = o.address_id',"left");  
        $this->db->join('users as u', 'u.id = o.customer_id');  
		$this->db->join('variations as vr', 'vr.id = o.variation_id');
		$this->db->join('products as p', 'p.id = vr.product_id');
		$this->db->join('vendors as v', 'v.user_id = p.vendor_id',"left");
		//if($order_status != 1)
		$this->db->join('delivery_executives d','d.id=o.executive_id',"left");
        $this->db->join('orders','orders.id=o.order_id');
        $this->db->join('transaction', 'transaction.id = orders.txn_id');
        $this->db->where('orders.payment_status', '1');
        if($this->session->userdata('user_type')=='2')
        {
            $this->db->where('o.vendor_id', $this->session->userdata('id') );    
        }
        $this->db->order_by('id', 'desc');
		$query = $this->db
				->limit($limit,$start)
				//->order_by($col,$dir)
				->get('order_details as o');
		if($query->num_rows()>0)
            return $query->result(); 
         
        else
            return null;
        
	}

    public function all_cancel_items($limit,$start,$col,$dir, $order_status = 1){
        $this->db->select('o.id,o.sub_pub_id, o.price as per_total_price, orders.total_price as whole_total_price,o.quantity as total_quanity,orders.tax as whole_total_tax, o.order_status, p.name, v.vendor_name, u.first_name, u.last_name, o.quantity, orders.public_id,o.custom_value, o.custom_description, o.custom_image, o.store_id, o.delivery_type, o.executive_id as delivery_executive_id, o.order_status, orders.address_id,orders.payment_status, concat(store_name,", ", store_address) as store_address,d.member_id, d.name as executive_name, d.address as executive_address, concat(d.country_code," ",d.phone) as executive_phone, d.email_id as executive_email, concat(u.first_name, 
            " ", last_name) as customer_name, concat(u.country_code, " ", u.phone) as customer_phone, u.email as customer_email,u.account_type, u.status as customer_status, concat(ad.address_line1,", ",ad.address_line2,", ", ad.address_line3,", ", pincode, ", ", ad.city,", ", ad.state, ", ",ad.country) as customer_address,s.store_name, s.store_address,o.cancel_reason,o.return_reason,transaction.payuMoneyId as transcation_id');
        $this->db->join('addresses as ad', 'ad.id = o.address_id',"left");  
        $this->db->join('stores as s', 's.id = o.address_id',"left");  
        $this->db->join('users as u', 'u.id = o.customer_id');  
        $this->db->join('variations as vr', 'vr.id = o.variation_id');
        $this->db->join('products as p', 'p.id = vr.product_id');
        $this->db->join('vendors as v', 'v.user_id = p.vendor_id',"left");
        //if($order_status != 1)
        $this->db->join('delivery_executives d','d.id=o.executive_id',"left");
        $this->db->join('orders','orders.id=o.order_id');
        $this->db->join('transaction', 'transaction.id = orders.txn_id');
        $this->db->where('orders.payment_status', '1');
        $this->db->where("o.order_status=4 or o.order_status=5 or o.order_status=7");
        if($this->session->userdata('user_type')=='2')
        {
            $this->db->where('o.vendor_id', $this->session->userdata('id') );    
        }
       $this->db->order_by('id', 'desc');
        $query = $this->db
                ->limit($limit,$start)
                //->order_by($col,$dir)
                ->get('order_details as o');
        if($query->num_rows()>0)
            return $query->result(); 
         
        else
            return null;
        
    }
    public function all_return_items($limit,$start,$col,$dir, $order_status = 1){

        $this->db->select('o.id,o.sub_pub_id, o.price as per_total_price, orders.total_price as whole_total_price,o.quantity as total_quanity,orders.tax as whole_total_tax, o.order_status, p.name, v.vendor_name, u.first_name, u.last_name, o.quantity, orders.public_id,o.custom_value, o.custom_description, o.custom_image, o.store_id, o.delivery_type, o.executive_id as delivery_executive_id, o.order_status, orders.address_id,orders.payment_status, concat(store_name,", ", store_address) as store_address,d.member_id, d.name as executive_name, d.address as executive_address, concat(d.country_code," ",d.phone) as executive_phone, d.email_id as executive_email, concat(u.first_name, 
            " ", last_name) as customer_name, concat(u.country_code, " ", u.phone) as customer_phone, u.email as customer_email,u.account_type, u.status as customer_status, concat(ad.address_line1,", ",ad.address_line2,", ", ad.address_line3,", ", pincode, ", ", ad.city,", ", ad.state, ", ",ad.country) as customer_address,s.store_name, s.store_address,o.cancel_reason,o.return_reason,transaction.payuMoneyId as transcation_id');
        $this->db->join('addresses as ad', 'ad.id = o.address_id',"left");  
        $this->db->join('stores as s', 's.id = o.address_id',"left");  
        $this->db->join('users as u', 'u.id = o.customer_id');  
        $this->db->join('variations as vr', 'vr.id = o.variation_id');
        $this->db->join('products as p', 'p.id = vr.product_id');
        $this->db->join('vendors as v', 'v.user_id = p.vendor_id',"left");
        //if($order_status != 1)
        $this->db->join('delivery_executives d','d.id=o.executive_id',"left");
        $this->db->join('orders','orders.id=o.order_id');
        $this->db->join('transaction', 'transaction.id = orders.txn_id');
        $this->db->where("o.order_status=8 or o.order_status=9 or o.order_status=10");
        $this->db->where('orders.payment_status', '1');
        if($this->session->userdata('user_type')=='2')
        {
            $this->db->where('o.vendor_id', $this->session->userdata('id') );    
        }
       $this->db->order_by('id', 'desc');
        $query = $this->db
                ->limit($limit,$start)
                //->order_by($col,$dir)
                ->get('order_details as o');
        if($query->num_rows()>0)
            return $query->result(); 
         
        else
            return null;
        
    }

	public function item_search($limit,$start,$search,$col,$dir, $order_status = 1){
    	$this->db->select('o.id, o.price as per_total_price, orders.total_price as whole_total_price,o.quantity as total_quanity,orders.tax as whole_total_tax, o.order_status, p.name, v.vendor_name, u.first_name, u.last_name, o.quantity, orders.public_id,o.custom_value, o.custom_description, o.custom_image, o.store_id, o.delivery_type, o.executive_id as delivery_executive_id, o.order_status, orders.address_id, orders.txn_id as transcation_id, orders.payment_status, concat(store_name,", ", store_address) as store_address,d.member_id, d.name as executive_name, d.address as executive_address, concat(d.country_code," ",d.phone) as executive_phone, d.email_id as executive_email, concat(u.first_name, 
            " ", last_name) as customer_name, concat(u.country_code, " ", u.phone) as customer_phone, u.email as customer_email,u.account_type, u.status as customer_status, concat(ad.address_line1,", ",ad.address_line2,", ", ad.address_line3,", ", pincode, ", ", ad.city,", ", ad.state, ", ",ad.country) as customer_address');
        $this->db->join('addresses as ad', 'ad.id = o.address_id',"left");  
        $this->db->join('stores as s', 's.id = o.address_id',"left");  
        $this->db->join('users as u', 'u.id = o.customer_id');  
        $this->db->join('variations as vr', 'vr.id = o.variation_id');
        $this->db->join('products as p', 'p.id = vr.product_id');
        $this->db->join('vendors as v', 'v.user_id = p.vendor_id');
        //if($order_status != 1)
        $this->db->join('delivery_executives d','d.id=o.executive_id',"left");
        $this->db->join('orders','orders.id=o.order_id');
        $this->db->where('orders.payment_status', '1');
        $query = $this->db
        	->like('orders.public_id',$search)
        	->or_like('o.order_status',$search)
        	->or_like('p.name',$search)
        	->or_like('v.vendor_name',$search)
        	->or_like('u.first_name',$search)
        	->or_like('u.last_name',$search)
        	->limit($limit,$start)->get('order_details as o');
        
        if($query->num_rows()>0)
            return $query->result();  
        else
            return null;
    }

    public function change_status($status, $number){
    	$this->db->where('id', $number);
    	$this->db->update('order_details', array('order_status'=>$status));
        if($status==5 || $status==7 || $status==9 || $status==10){
            $this->db->select('customer_id');
            $this->db->where('id', $number);
            $customer_id=$this->db->get('order_details')->row('customer_id');

            $this->db->select('vendor_id');
            $this->db->where('id', $number);
            $vendor_id=$this->db->get('order_details')->row('vendor_id');

            $this->db->select('o.public_id');
            $this->db->join('orders o', 'o.id = od.order_id', 'left');
            $this->db->where('od.id', $number);
            $public_id=$this->db->get('order_details od')->row('public_id');

            if($status==5) {
                $title="Cancellation.";
                $mssg="Cancellation Accepted For Order Id:";
            }
            if($status==7) {
                $title="Cancellation.";
                $mssg="Cancellation Accepted For Order Id:";
            }
            if($status==9) {
                $title="Return Request.";
                $mssg="Return Accepted For Order Id:";
            }
            if($status==10) {
                $title="Return Request.";
                $mssg="Return Accepted For Order Id:";
            }
            $insert_data=array(
                'user_id'=>$customer_id,
                'user_type'=>1,
                'notification_type'=>2,
                'title'=>$title,
                'message'=>$mssg.$public_id,
                'message_read'=>0,
                'status'=>1,
                'added_on'=>date('Y-m-d H:i:s')
            );
            $this->db->insert('notification', $insert_data);

            $insert_data1=array(
                'user_id'=>$vendor_id,
                'user_type'=>2,
                'notification_type'=>2,
                'title'=>$title,
                'message'=>$mssg.$public_id,
                'message_read'=>0,
                'status'=>1,
                'added_on'=>date('Y-m-d H:i:s')
            );
            $this->db->insert('notification', $insert_data1);
        }
        return true;
    	
    }

    public function change_delivery_exective($executive_id, $number){
        $this->db->where('id', $number);
        $this->db->update('order_details', array('executive_id'=>$executive_id));
        return true;
        
    }

    public function change_type($type, $number){
        $this->db->where('id', $number);
        $this->db->update('order_details', array('delivery_type'=>'2'));
        return true;
        
    }

    public function change_pick_store($store_id, $number){
        $this->db->where('id', $number);
        $this->db->update('order_details', array('store_id'=>$store_id));
        return true;
        
    }

    public function get_invoice($id){
    	$this->db->select('u.first_name, u.last_name, u.phone, u.email, o.order_number, o.id , o.discounted_price, o.final_price, o.order_status, o.order_type, o.delivery_address, o.delivery_pincode, o.delivery_mobile, o.delivery_email, o.added_on, t.transition_number, t.transition_status, o.tax, o.shipping, o.base_price');
    	$this->db->join('customers as c',' c.id = o.customer_id');
    	$this->db->join('transitions as t','t.id = o.transition_id');
        $this->db->join('users as u','u.id = c.user_id');
        $this->db->where('o.id', $id);
        $inv_data = $this->db->get('orders_history as o')->row_array();

        $this->db->select('vr.sku, p.name, vn.vendor_name, oi.price, oi.quantity, oi.id');
        $this->db->where('order_id', $inv_data['id']);
        $this->db->join('variations as vr','vr.id = oi.variation_id');
        $this->db->join('products as p','vr.product_id = p.id');
    	$this->db->join('vendors as vn','p.vendor_id = vn.user_id');
        $inv_data['items'] = $this->db->get('order_items as oi')->result_array();
        
        return $inv_data;
    }

    public function get_tax(){
        $this->db->where('status', 1); 
        return $this->db->get('taxes')->result_array(); 
    }
    public function all_stores(){
        $this->db->where('user_id',$this->session->userdata('id'));
        return $this->db->get('stores')->result_array();
    }
    public function all_executives(){
        if($this->session->userdata('user_type')==2)
        {
            $this->db->where('vendor_id',$this->session->userdata('id'));
        }
        else if($this->session->userdata('user_type')==1)
        {
            $this->db->where('type','1');   
        }
        $this->db->where('status', 1); 
        return $this->db->get('delivery_executives')->result_array();
    }

    public function cancel_order_notification($sub_order_id,$msg)
    {   
        $this->db->select('users.device_id,users.id');
        $this->db->join('users', 'users.id = order_details.customer_id', 'left');
        $this->db->where("order_details.id",$sub_order_id);
        $rs=$this->db->get('order_details')->result_array();
        $device_id = array_column($rs,'device_id');
        $insert_data = array(
            'user_id' => $rs['id'],
            'title'   => "Order Cancellation",
            'message' => $msg,
            'message_read'=>0,
            'status'=>1,
            'added_on'=>date('Y-m-d H:i:s'),
            'notification_type'=>2
        );
        $this->db->insert('notification', $insert_data);
        return $device_id;
    }

    public function get_order($data)
    {   
        $this->db->select('o.id,o.sub_pub_id, o.price as per_total_price, orders.total_price as whole_total_price,o.quantity as total_quanity,orders.tax as whole_total_tax, o.order_status, p.name, v.vendor_name, u.first_name, u.last_name, o.quantity, orders.public_id,o.custom_value, o.custom_description, o.custom_image, o.store_id, o.delivery_type, o.executive_id as delivery_executive_id, o.order_status, orders.address_id, orders.txn_id as transcation_id, orders.payment_status, concat(store_name,", ", store_address) as store_address,d.member_id, d.name as executive_name, d.address as executive_address, concat(d.country_code," ",d.phone) as executive_phone, d.email_id as executive_email, concat(u.first_name, 
            " ", last_name) as customer_name, concat(u.country_code, " ", u.phone) as customer_phone, u.email as customer_email,u.account_type, u.status as customer_status, concat(ad.address_line1,", ",ad.address_line2,", ", ad.address_line3,", ", pincode, ", ", ad.city,", ", ad.state, ", ",ad.country) as customer_address,s.store_name, s.store_address,transaction.txnid');
        $this->db->join('addresses as ad', 'ad.id = o.address_id',"left");  
        $this->db->join('stores as s', 's.id = o.address_id',"left");  
        $this->db->join('users as u', 'u.id = o.customer_id');  
        $this->db->join('variations as vr', 'vr.id = o.variation_id');
        $this->db->join('products as p', 'p.id = vr.product_id');
        $this->db->join('vendors as v', 'v.user_id = p.vendor_id',"left");
        $this->db->join('delivery_executives d','d.id=o.executive_id',"left");
        $this->db->join('orders','orders.id=o.order_id','left');
        $this->db->join('transaction','transaction.id=orders.txn_id','left');
        $this->db->where('orders.payment_status', '1');
        $this->db->where('u.id', $data['id'] );    
        $this->db->where('orders.payment_status', 1);
        $result = $this->db->get('order_details as o')->result_array();
        return $result;
    }
}
