<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Order_management extends CI_Controller {
	

	function __construct(){
		parent::__construct();
		$this->load->model('order_model','orders');
		$this->load->library('external');
	}

	public function index(){
		$data['title'] = 'Order Management';
		$data['page'] = 'orders';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();
		$data['extra_datatable_data'] .= '
			<script type="text/javascript">
				$(document).ready(function (){
				    $("#orderlist").DataTable({
				        "processing": true,
				        "serverSide": true,
				        "ajax":{
				            "url": "'.base_url('order_management/order_list').'",
				            "dataType": "json",
				            "type": "POST",
				            "data":{
				              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
				            }
				        },
				        "columns": [
				          { "data": "id" },
				          { "data": "ordernumber" },
				          { "data": "subordernumber" },
				          { "data": "vendor_name" },
				          { "data": "store_address" },
				          { "data": "customer_name" },
				          { "data": "customer_phone" },
				          { "data": "account_type" },
				          { "data": "customer_status" },
				          { "data": "transcation_id" },
				          { "data": "customer_email" },
				          { "data": "customer_address" },
				          { "data": "variation_name" },
				          { "data": "quantity" },
				          { "data": "custom_value" },
				          { "data": "custom_description" },
				          { "data": "custom_image" },
				          { "data": "order_status" },
				          { "data": "cancel_reason" },
				          { "data": "return_reason" },
				          { "data": "per_total_price" },
				          { "data": "payment_status" },
				          { "data": "member_id" },
				          { "data": "executive_name" },
				          { "data": "executive_address" },
				          { "data": "executive_phone" },
				          { "data": "executive_email" },
				          { "data": "store" },
				          { "data": "delivery_change" },
				          { "data": "delivery_type" },
				          { "data": "executive_drp" }
				        ]
				    });

				    $("#cancel_order").DataTable({
				        "processing": true,
				        "serverSide": true,
				        "ajax":{
				            "url": "'.base_url('order_management/cancel_order_list').'",
				            "dataType": "json",
				            "type": "POST",
				            "data":{
				              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
				            }
				        },
				        "columns": [
				          { "data": "id" },
				          { "data": "ordernumber" },
				          { "data": "subordernumber" },
				          { "data": "vendor_name" },
				          { "data": "store_address" },
				          { "data": "customer_name" },
				          { "data": "customer_phone" },
				          { "data": "account_type" },
				          { "data": "customer_status" },
				          { "data": "transcation_id" },
				          { "data": "customer_email" },
				          { "data": "customer_address" },
				          { "data": "variation_name" },
				          { "data": "quantity" },
				          { "data": "custom_value" },
				          { "data": "custom_description" },
				          { "data": "custom_image" },
				          { "data": "order_status" },
				          { "data": "cancel_reason" },
				          { "data": "return_reason" },
				          { "data": "per_total_price" },
				          { "data": "payment_status" },
				          { "data": "member_id" },
				          { "data": "executive_name" },
				          { "data": "executive_address" },
				          { "data": "executive_phone" },
				          { "data": "executive_email" },
				          { "data": "store" },
				          { "data": "delivery_change" },
				          { "data": "delivery_type" },
				          { "data": "executive_drp" }
				        ]
				    });

				    $("#return_order").DataTable({
				        "processing": true,
				        "serverSide": true,
				        "ajax":{
				            "url": "'.base_url('order_management/return_order_list').'",
				            "dataType": "json",
				            "type": "POST",
				            "data":{
				              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
				            }
				        },
				        "columns": [
				          { "data": "id" },
				          { "data": "ordernumber" },
				          { "data": "subordernumber" },
				          { "data": "vendor_name" },
				          { "data": "store_address" },
				          { "data": "customer_name" },
				          { "data": "customer_phone" },
				          { "data": "account_type" },
				          { "data": "customer_status" },
				          { "data": "transcation_id" },
				          { "data": "customer_email" },
				          { "data": "customer_address" },
				          { "data": "variation_name" },
				          { "data": "quantity" },
				          { "data": "custom_value" },
				          { "data": "custom_description" },
				          { "data": "custom_image" },
				          { "data": "order_status" },
				          { "data": "cancel_reason" },
				          { "data": "return_reason" },
				          { "data": "per_total_price" },
				          { "data": "payment_status" },
				          { "data": "member_id" },
				          { "data": "executive_name" },
				          { "data": "executive_address" },
				          { "data": "executive_phone" },
				          { "data": "executive_email" },
				          { "data": "store" },
				          { "data": "delivery_change" },
				          { "data": "delivery_type" },
				          { "data": "executive_drp" }
				        ]
				    });

				});

				function change_status(that){
					var number = $(that).attr("data-number");
					var status = $(that).val();
					$.ajax({
						url: "'.base_url('order_management/change_status').'",
						data: { 
							"number": number, 
							"status": status
						},
						cache: false,
						type: "POST",
						success: function(response) {
							console.log(response);
							$("#orderlist").DataTable().ajax.reload();
						},
						error: function(xhr) {
							console.log(xhr);
						}
					});
				}
				function change_store(that){
					var number = $(that).attr("data-number");
					var store_id = $(that).val();

					$.ajax({
						url: "'.base_url('order_management/change_pick_store').'",
						data: { 
							"number": number, 
							"store_id": store_id
						},
						cache: false,
						type: "POST",
						success: function(response) {
							console.log(response);
							$("#orderlist").DataTable().ajax.reload();
						},
						error: function(xhr) {
							console.log(xhr);
						}
					});
				}
				function change_executive(that){
					var number = $(that).attr("data-number");
					var executive_id = $(that).val();
					$.ajax({
						url: "'.base_url('order_management/change_delivery_exective').'",
						data: { 
							"number": number, 
							"executive_id": executive_id
						},
						cache: false,
						type: "POST",
						success: function(response) {
							console.log(response);
							$("#orderlist").DataTable().ajax.reload();
						},
						error: function(xhr) {
							console.log(xhr);
						}
					});
				}
				function change_type(that){
					var number = $(that).attr("data-number");
					var types = 2;
					$.ajax({
						url: "'.base_url('order_management/change_type').'",
						data: { 
							"number": number, 
							"types": types
						},
						cache: false,
						type: "POST",
						success: function(response) {
							console.log(response);
							$("#orderlist").DataTable().ajax.reload();
						},
						error: function(xhr) {
							console.log(xhr);
						}
					});
				}
			</script>';
		$this->load->view('template',$data);
	}

	
    public function change_delivery_exective(){
      	return $this->orders
				->change_delivery_exective(
					$this->input->post('executive_id'), 
					$this->input->post('number')
				);
        
    }

    public function change_pick_store(){
       	return $this->orders
				->change_pick_store(
					$this->input->post('store_id'), 
					$this->input->post('number')
				);
        
    }

    public function change_type(){
       	return $this->orders
				->change_type(
					$this->input->post('types'), 
					$this->input->post('number')
				);
        
    }


	public function order_list($order_Status='1'){

		$columns = array(
			0=> 'id',
			1=> 'public_id',
			2=> 'sub_pub_id',
			3=> 'vendor_name',
			4=> 'store_address',
			5=> 'customer_name',
			6=> 'customer_phone',
			7=> 'account_type',
			8=> 'customer_status',
			9=> 'transcation_id',
			10=> 'customer_email',
			11=> 'customer_address',
			12=> 'name',
			13=> 'quantity',
			14=> 'custom_value',
			15=> 'custom_description',
			16=> 'custom_image',
			17=> 'order_status',
			18=> 'cancel_reason',
			19=> 'return_reason',
			20=> 'per_total_price',
			21=> 'payment_status',
			22=> 'member_id',
			23=> 'executive_name',
			24=> 'executive_address',
			25=> 'executive_phone',
			26=> 'executive_email',
			27=> 'store',
			28=> 'delivery_change',
			29=> 'delivery_type',
			30=> 'executive_drp',
			
		);

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
        $totalData = $this->orders->table_items_count('order_details');

        $totalFiltered = $totalData; 
        if(empty($this->input->post('search')['value'])){
        	$posts = $this->orders->all_items($limit,$start,$order,$dir, $order_Status);
        }else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->orders->item_search($limit,$start,$search,$order,$dir, $order_Status);

            // $totalFiltered = $this->orders->item_count_search($search,  'admins');
        }
        
		if($this->session->userdata('user_type')==2){
	  		$stores=$this->orders->all_stores();
	  	}
  		$exectives=$this->orders->all_executives();
  		
  		$data = array();
		if(!empty($posts)){
			foreach ($posts as $post){
				$st="";
				if($post->customer_status==1)
				{
					$st="Active";
				}elseif($post->customer_status==2)
				{
					$st="Inactive";
				}
				elseif($post->customer_status==3)
				{
					$st="Blocked";
				}

				$nestedData['id'] = '';
				$nestedData['ordernumber'] = $post->public_id;
				$nestedData['subordernumber'] = $post->sub_pub_id;
				$nestedData['vendor_name'] = $post->vendor_name;
				$nestedData['store_address'] = $post->store_name!=''?$post->store_name.', '.$post->store_address:"Assigned Yet";
				$nestedData['customer_name'] = $post->customer_name;
				$nestedData['customer_phone'] = $post->customer_phone;
				$nestedData['account_type'] = $post->account_type=='1'?"Professional":"Personal";
				$nestedData['customer_status'] = $st;
				$nestedData['transcation_id'] = $post->transcation_id;
				$nestedData['customer_email'] = $post->customer_email;
				$nestedData['customer_address'] = $post->customer_address;
				$nestedData['variation_name'] = $post->name;
				$nestedData['quantity'] = $post->quantity;
				$nestedData['custom_value'] = $post->custom_value==1?"Yes":"No";
				$nestedData['custom_description'] = $post->custom_description;
				$nestedData['custom_image'] = $post->custom_image!=""?"<img src=".URL."/custom_image/".$post->custom_image.">":'';

				$nestedData['order_status'] = '
				<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
					<option value="0" '.(($post->order_status == 0)? 'selected="selected"' :" ").'>Placed</option>
					<option value="1" '.(($post->order_status == 1)? 'selected="selected"' :" ").'>Confirmed</option>
					<option value="2" '.(($post->order_status == 2)? 'selected="selected"' :" ").'>Shipped</option>
					<option value="3" '.(($post->order_status == 3)? 'selected="selected"' :" ").'>Delivered</option>
				</select>
				
				<!--<a href="'.base_url('order_management/view').'/'.$post->id.'" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>-->';
				if($post->order_status == 6){
					$nestedData['order_status'] = '<select class="btn btn-primary" data-number="'.$post->id.'">
					<option value="6" '.(($post->order_status == 6)? 'selected="selected"' :" ").'>Declined By Delivery Person</option>
				</select>';
				}
				if($post->order_status == 4){
					$nestedData['order_status'] = '
					<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
					<option value="4" '.(($post->order_status == 4)? 'selected="selected"' :" ").'>Cancelled</option>
					<option value="5" '.(($post->order_status == 5)? 'selected="selected"' :" ").'>Accept cancellation</option>
					<option value="7" '.(($post->order_status == 7)? 'selected="selected"' :" ").'>Declined cancellation</option>
				</select>';
				}
				if($post->order_status == 5){
					$nestedData['order_status'] = '<select class="btn btn-primary" data-number="'.$post->id.'">
					<option value="5" '.(($post->order_status == 5)? 'selected="selected"' :" ").'>Accept cancellation</option>
				</select>';
				}
				if($post->order_status == 7){
					$nestedData['order_status'] = '<select class="btn btn-primary" data-number="'.$post->id.'">
					<option value="7" '.(($post->order_status == 7)? 'selected="selected"' :" ").'>Declined cancellation</option>
				</select>';
				}
				if($post->order_status == 8){
					$nestedData['order_status'] = '
					<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
					<option value="8" '.(($post->order_status == 8)? 'selected="selected"' :" ").'>Returned</option>
					<option value="9" '.(($post->order_status == 9)? 'selected="selected"' :" ").'>Accept Return</option>
					<option value="10" '.(($post->order_status == 10)? 'selected="selected"' :" ").'>Declined return</option>
				</select>';
				}
				if($post->order_status == 9){
					$nestedData['order_status'] = '<select class="btn btn-primary" data-number="'.$post->id.'">
					<option value="9" '.(($post->order_status == 9)? 'selected="selected"' :" ").'>Return Accepted</option>
				</select>';
				}
				if($post->order_status == 10){
					$nestedData['order_status'] = '<select class="btn btn-primary" data-number="'.$post->id.'">
					<option value="10" '.(($post->order_status == 10)? 'selected="selected"' :" ").'>Return Declined</option>
				</select>';
				}
				$nestedData['cancel_reason'] = $post->cancel_reason;
				$nestedData['return_reason'] = $post->return_reason;
				/*$nestedData['per_total_tax'] = $post->per_total_tax;*/
				$nestedData['per_total_price'] = $post->per_total_price;
				$nestedData['member_id'] = $post->member_id;
				$nestedData['executive_name'] = $post->executive_name;
				$nestedData['executive_address'] = $post->executive_address;
				$nestedData['executive_phone'] = $post->executive_phone;
				$nestedData['executive_email'] = $post->executive_email;
				$nestedData['payment_status'] =  $post->payment_status==1?"Success":"Pending";
				if($this->session->userdata('user_type')==2){
					$store='';
					$store='<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_store(this)"><option value="">Select Store</option>';
					
					foreach ($stores as $key => $value) {
						$store.='<option value="'.$value['id'].'" '.(($post->store_id == $value['id'])? 'selected="selected"' :" ").'>'.$value['store_name'].'</option>';
						}
						$store.='</select>';
						$nestedData['store'] =$store;
						if($post->delivery_type=='1' || $post->delivery_type=='0'){
						$nestedData['delivery_change'] ='<button class="btn btn-primary"  data-number="'.$post->id.'" onclick="return change_type(this)"><i class="fa fa-user-o"></i>Request for Delivery</button>';
						}
						else
						{
							$nestedData['delivery_change'] ="";
						}
					}
				else
				{
					$nestedData['store'] =  $post->store_name!=''?$post->store_name.', '.$post->store_address:"Assigned Yet";
					$nestedData['delivery_change'] ="";
				}

				if($post->delivery_type=='1')
				{
					$nestedData['delivery_type']= "Self Delivery";
				}else if($post->delivery_type=='0')
				{
					$nestedData['delivery_type']= "Not Yet Decided";
				}
				else if($post->delivery_type=='2')
				{
					$nestedData['delivery_type']= "Request for Delivery";
				}
				else if($post->delivery_type=='3')
				{
					$nestedData['delivery_type']= "Cargo Delivery";
				}
				
				$executive='';
				$executive='<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_executive(this)"><option value="">Select Executive </option>';
					foreach ($exectives as $key => $value) {
						$executive.='<option value="'.$value['id'].'" '.(($post->store_id == $value['id'])? 'selected="selected"' :" ").'>'.$value['name'].'</option>';
						}
					
				$executive.='</select>';
				$nestedData['executive_drp'] =$executive;
				$data[] = $nestedData;

			}
		}

		

		$json_data = array(
		"draw"            => intval($this->input->post('draw')),  
		"recordsTotal"    => intval($totalData),  
		"recordsFiltered" => intval($totalFiltered), 
		"data"            => $data   
		);

		echo json_encode($json_data); 
	}

	public function cancel_order_list($order_Status='4'){

		$columns = array(
			0=> 'id',
			1=> 'public_id',
			2=> 'sub_pub_id',
			3=> 'vendor_name',
			4=> 'store_address',
			5=> 'customer_name',
			6=> 'customer_phone',
			7=> 'account_type',
			8=> 'customer_status',
			9=> 'transcation_id',
			10=> 'customer_email',
			11=> 'customer_address',
			12=> 'name',
			13=> 'quantity',
			14=> 'custom_value',
			15=> 'custom_description',
			16=> 'custom_image',
			17=> 'order_status',
			18=> 'cancel_reason',
			19=> 'return_reason',
			20=> 'per_total_price',
			21=> 'payment_status',
			22=> 'member_id',
			23=> 'executive_name',
			24=> 'executive_address',
			25=> 'executive_phone',
			26=> 'executive_email',
			27=> 'store',
			28=> 'delivery_change',
			29=> 'delivery_type',
			30=> 'executive_drp',
			
		);

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
        $totalData = $this->orders->table_items_count_cancel('order_details');

        $totalFiltered = $totalData; 
        if(empty($this->input->post('search')['value'])){
        	$posts = $this->orders->all_cancel_items($limit,$start,$order,$dir, $order_Status);
        }else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->orders->item_search($limit,$start,$search,$order,$dir, $order_Status);

            // $totalFiltered = $this->orders->item_count_search($search,  'admins');
        }
        
		if($this->session->userdata('user_type')==2){
	  		$stores=$this->orders->all_stores();
	  	}
  		$exectives=$this->orders->all_executives();
  		
  		$data = array();
		if(!empty($posts)){
			foreach ($posts as $post){
				$st="";
				if($post->customer_status==1)
				{
					$st="Active";
				}elseif($post->customer_status==2)
				{
					$st="Inactive";
				}
				elseif($post->customer_status==3)
				{
					$st="Blocked";
				}

				$nestedData['id'] = '';
				$nestedData['ordernumber'] = $post->public_id;
				$nestedData['subordernumber'] = $post->sub_pub_id;
				$nestedData['vendor_name'] = $post->vendor_name;
				$nestedData['store_address'] = $post->store_name!=''?$post->store_name.', '.$post->store_address:"Assigned Yet";
				$nestedData['customer_name'] = $post->customer_name;
				$nestedData['customer_phone'] = $post->customer_phone;
				$nestedData['account_type'] = $post->account_type=='1'?"Professional":"Personal";
				$nestedData['customer_status'] = $st;
				$nestedData['transcation_id'] = $post->transcation_id;
				$nestedData['customer_email'] = $post->customer_email;
				$nestedData['customer_address'] = $post->customer_address;
				$nestedData['variation_name'] = $post->name;
				$nestedData['quantity'] = $post->quantity;
				$nestedData['custom_value'] = $post->custom_value==1?"Yes":"No";
				$nestedData['custom_description'] = $post->custom_description;
				$nestedData['custom_image'] = $post->custom_image!=""?"<img src=".URL."/custom_image/".$post->custom_image.">":'';

				$nestedData['order_status'] = '
				<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
					<option value="0" '.(($post->order_status == 0)? 'selected="selected"' :" ").'>Placed</option>
					<option value="1" '.(($post->order_status == 1)? 'selected="selected"' :" ").'>Confirmed</option>
					<option value="2" '.(($post->order_status == 2)? 'selected="selected"' :" ").'>Shipped</option>
					<option value="3" '.(($post->order_status == 3)? 'selected="selected"' :" ").'>Delivered</option>
				</select>
				
				<!--<a href="'.base_url('order_management/view').'/'.$post->id.'" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>-->';
				if($post->order_status == 6){
					$nestedData['order_status'] = '<select class="btn btn-primary" data-number="'.$post->id.'">
					<option value="6" '.(($post->order_status == 6)? 'selected="selected"' :" ").'>Declined By Delivery Person</option>
				</select>';
				}
				if($post->order_status == 4){
					$nestedData['order_status'] = '
					<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
					<option value="4" '.(($post->order_status == 4)? 'selected="selected"' :" ").'>Cancelled</option>
					<option value="5" '.(($post->order_status == 5)? 'selected="selected"' :" ").'>Accept cancellation</option>
					<option value="7" '.(($post->order_status == 7)? 'selected="selected"' :" ").'>Declined cancellation</option>
				</select>';
				}
				if($post->order_status == 5){
					$nestedData['order_status'] = '<select class="btn btn-primary" data-number="'.$post->id.'">
					<option value="5" '.(($post->order_status == 5)? 'selected="selected"' :" ").'>Accept cancellation</option>
				</select>';
				}
				if($post->order_status == 7){
					$nestedData['order_status'] = '<select class="btn btn-primary" data-number="'.$post->id.'">
					<option value="7" '.(($post->order_status == 7)? 'selected="selected"' :" ").'>Declined cancellation</option>
				</select>';
				}
				if($post->order_status == 8){
					$nestedData['order_status'] = '
					<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
					<option value="8" '.(($post->order_status == 8)? 'selected="selected"' :" ").'>Returned</option>
					<option value="9" '.(($post->order_status == 9)? 'selected="selected"' :" ").'>Accept Return</option>
					<option value="10" '.(($post->order_status == 10)? 'selected="selected"' :" ").'>Declined return</option>
				</select>';
				}
				if($post->order_status == 9){
					$nestedData['order_status'] = '<select class="btn btn-primary" data-number="'.$post->id.'">
					<option value="9" '.(($post->order_status == 9)? 'selected="selected"' :" ").'>Return Accepted</option>
				</select>';
				}
				if($post->order_status == 10){
					$nestedData['order_status'] = '<select class="btn btn-primary" data-number="'.$post->id.'">
					<option value="10" '.(($post->order_status == 10)? 'selected="selected"' :" ").'>Return Declined</option>
				</select>';
				}
				$nestedData['cancel_reason'] = $post->cancel_reason;
				$nestedData['return_reason'] = $post->return_reason;
				/*$nestedData['per_total_tax'] = $post->per_total_tax;*/
				$nestedData['per_total_price'] = $post->per_total_price;
				$nestedData['member_id'] = $post->member_id;
				$nestedData['executive_name'] = $post->executive_name;
				$nestedData['executive_address'] = $post->executive_address;
				$nestedData['executive_phone'] = $post->executive_phone;
				$nestedData['executive_email'] = $post->executive_email;
				$nestedData['payment_status'] =  $post->payment_status==1?"Success":"Pending";
				if($this->session->userdata('user_type')==2){
					$store='';
					$store='<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_store(this)"><option value="">Select Store</option>';
					
					foreach ($stores as $key => $value) {
						$store.='<option value="'.$value['id'].'" '.(($post->store_id == $value['id'])? 'selected="selected"' :" ").'>'.$value['store_name'].'</option>';
						}
						$store.='</select>';
						$nestedData['store'] =$store;
						if($post->delivery_type=='1' || $post->delivery_type=='0'){
						$nestedData['delivery_change'] ='<button class="btn btn-primary"  data-number="'.$post->id.'" onclick="return change_type(this)"><i class="fa fa-user-o"></i>Request for Delivery</button>';
						}
						else
						{
							$nestedData['delivery_change'] ="";
						}
					}
				else
				{
					$nestedData['store'] =  $post->store_name!=''?$post->store_name.', '.$post->store_address:"Assigned Yet";
					$nestedData['delivery_change'] ="";
				}

				if($post->delivery_type=='1')
				{
					$nestedData['delivery_type']= "Self Delivery";
				}else if($post->delivery_type=='0')
				{
					$nestedData['delivery_type']= "Not Yet Decided";
				}
				else if($post->delivery_type=='2')
				{
					$nestedData['delivery_type']= "Request for Delivery";
				}
				else if($post->delivery_type=='3')
				{
					$nestedData['delivery_type']= "Cargo Delivery";
				}
				
				$executive='';
				$executive='<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_executive(this)"><option value="">Select Executive </option>';
					foreach ($exectives as $key => $value) {
						$executive.='<option value="'.$value['id'].'" '.(($post->store_id == $value['id'])? 'selected="selected"' :" ").'>'.$value['name'].'</option>';
						}
					
				$executive.='</select>';
				$nestedData['executive_drp'] =$executive;
				$data[] = $nestedData;

			}
		}

		

		$json_data = array(
		"draw"            => intval($this->input->post('draw')),  
		"recordsTotal"    => intval($totalData),  
		"recordsFiltered" => intval($totalFiltered), 
		"data"            => $data   
		);

		echo json_encode($json_data); 
	}
	public function return_order_list($order_Status='1'){

		$columns = array(
			0=> 'id',
			1=> 'public_id',
			2=> 'sub_pub_id',
			3=> 'vendor_name',
			4=> 'store_address',
			5=> 'customer_name',
			6=> 'customer_phone',
			7=> 'account_type',
			8=> 'customer_status',
			9=> 'transcation_id',
			10=> 'customer_email',
			11=> 'customer_address',
			12=> 'name',
			13=> 'quantity',
			14=> 'custom_value',
			15=> 'custom_description',
			16=> 'custom_image',
			17=> 'order_status',
			18=> 'cancel_reason',
			19=> 'return_reason',
			20=> 'per_total_price',
			21=> 'payment_status',
			22=> 'member_id',
			23=> 'executive_name',
			24=> 'executive_address',
			25=> 'executive_phone',
			26=> 'executive_email',
			27=> 'store',
			28=> 'delivery_change',
			29=> 'delivery_type',
			30=> 'executive_drp',
			
		);

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
        $totalData = $this->orders->table_items_count_return('order_details');

        $totalFiltered = $totalData; 
        if(empty($this->input->post('search')['value'])){
        	$posts = $this->orders->all_return_items($limit,$start,$order,$dir, $order_Status);
        }else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->orders->item_search($limit,$start,$search,$order,$dir, $order_Status);

            // $totalFiltered = $this->orders->item_count_search($search,  'admins');
        }
        
		if($this->session->userdata('user_type')==2){
	  		$stores=$this->orders->all_stores();
	  	}
  		$exectives=$this->orders->all_executives();
  		
  		$data = array();
		if(!empty($posts)){
			foreach ($posts as $post){
				$st="";
				if($post->customer_status==1)
				{
					$st="Active";
				}elseif($post->customer_status==2)
				{
					$st="Inactive";
				}
				elseif($post->customer_status==3)
				{
					$st="Blocked";
				}

				$nestedData['id'] = '';
				$nestedData['ordernumber'] = $post->public_id;
				$nestedData['subordernumber'] = $post->sub_pub_id;
				$nestedData['vendor_name'] = $post->vendor_name;
				$nestedData['store_address'] = $post->store_name!=''?$post->store_name.', '.$post->store_address:"Assigned Yet";
				$nestedData['customer_name'] = $post->customer_name;
				$nestedData['customer_phone'] = $post->customer_phone;
				$nestedData['account_type'] = $post->account_type=='1'?"Professional":"Personal";
				$nestedData['customer_status'] = $st;
				$nestedData['transcation_id'] = $post->transcation_id;
				$nestedData['customer_email'] = $post->customer_email;
				$nestedData['customer_address'] = $post->customer_address;
				$nestedData['variation_name'] = $post->name;
				$nestedData['quantity'] = $post->quantity;
				$nestedData['custom_value'] = $post->custom_value==1?"Yes":"No";
				$nestedData['custom_description'] = $post->custom_description;
				$nestedData['custom_image'] = $post->custom_image!=""?"<img src=".URL."/custom_image/".$post->custom_image.">":'';

				$nestedData['order_status'] = '
				<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
					<option value="0" '.(($post->order_status == 0)? 'selected="selected"' :" ").'>Placed</option>
					<option value="1" '.(($post->order_status == 1)? 'selected="selected"' :" ").'>Confirmed</option>
					<option value="2" '.(($post->order_status == 2)? 'selected="selected"' :" ").'>Shipped</option>
					<option value="3" '.(($post->order_status == 3)? 'selected="selected"' :" ").'>Delivered</option>
				</select>
				
				<!--<a href="'.base_url('order_management/view').'/'.$post->id.'" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>-->';
				if($post->order_status == 6){
					$nestedData['order_status'] = '<select class="btn btn-primary" data-number="'.$post->id.'">
					<option value="6" '.(($post->order_status == 6)? 'selected="selected"' :" ").'>Declined By Delivery Person</option>
				</select>';
				}
				if($post->order_status == 4){
					$nestedData['order_status'] = '
					<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
					<option value="4" '.(($post->order_status == 4)? 'selected="selected"' :" ").'>Cancelled</option>
					<option value="5" '.(($post->order_status == 5)? 'selected="selected"' :" ").'>Accept cancellation</option>
					<option value="7" '.(($post->order_status == 7)? 'selected="selected"' :" ").'>Declined cancellation</option>
				</select>';
				}
				if($post->order_status == 5){
					$nestedData['order_status'] = '<select class="btn btn-primary" data-number="'.$post->id.'">
					<option value="5" '.(($post->order_status == 5)? 'selected="selected"' :" ").'>Accept cancellation</option>
				</select>';
				}
				if($post->order_status == 7){
					$nestedData['order_status'] = '<select class="btn btn-primary" data-number="'.$post->id.'">
					<option value="7" '.(($post->order_status == 7)? 'selected="selected"' :" ").'>Declined cancellation</option>
				</select>';
				}
				if($post->order_status == 8){
					$nestedData['order_status'] = '
					<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
					<option value="8" '.(($post->order_status == 8)? 'selected="selected"' :" ").'>Returned</option>
					<option value="9" '.(($post->order_status == 9)? 'selected="selected"' :" ").'>Accept Return</option>
					<option value="10" '.(($post->order_status == 10)? 'selected="selected"' :" ").'>Declined return</option>
				</select>';
				}
				if($post->order_status == 9){
					$nestedData['order_status'] = '<select class="btn btn-primary" data-number="'.$post->id.'">
					<option value="9" '.(($post->order_status == 9)? 'selected="selected"' :" ").'>Return Accepted</option>
				</select>';
				}
				if($post->order_status == 10){
					$nestedData['order_status'] = '<select class="btn btn-primary" data-number="'.$post->id.'">
					<option value="10" '.(($post->order_status == 10)? 'selected="selected"' :" ").'>Return Declined</option>
				</select>';
				}
				$nestedData['cancel_reason'] = $post->cancel_reason;
				$nestedData['return_reason'] = $post->return_reason;
				/*$nestedData['per_total_tax'] = $post->per_total_tax;*/
				$nestedData['per_total_price'] = $post->per_total_price;
				$nestedData['member_id'] = $post->member_id;
				$nestedData['executive_name'] = $post->executive_name;
				$nestedData['executive_address'] = $post->executive_address;
				$nestedData['executive_phone'] = $post->executive_phone;
				$nestedData['executive_email'] = $post->executive_email;
				$nestedData['payment_status'] =  $post->payment_status==1?"Success":"Pending";
				if($this->session->userdata('user_type')==2){
					$store='';
					$store='<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_store(this)"><option value="">Select Store</option>';
					
					foreach ($stores as $key => $value) {
						$store.='<option value="'.$value['id'].'" '.(($post->store_id == $value['id'])? 'selected="selected"' :" ").'>'.$value['store_name'].'</option>';
						}
						$store.='</select>';
						$nestedData['store'] =$store;
						if($post->delivery_type=='1' || $post->delivery_type=='0'){
						$nestedData['delivery_change'] ='<button class="btn btn-primary"  data-number="'.$post->id.'" onclick="return change_type(this)"><i class="fa fa-user-o"></i>Request for Delivery</button>';
						}
						else
						{
							$nestedData['delivery_change'] ="";
						}
					}
				else
				{
					$nestedData['store'] =  $post->store_name!=''?$post->store_name.', '.$post->store_address:"Assigned Yet";
					$nestedData['delivery_change'] ="";
				}

				if($post->delivery_type=='1')
				{
					$nestedData['delivery_type']= "Self Delivery";
				}else if($post->delivery_type=='0')
				{
					$nestedData['delivery_type']= "Not Yet Decided";
				}
				else if($post->delivery_type=='2')
				{
					$nestedData['delivery_type']= "Request for Delivery";
				}
				else if($post->delivery_type=='3')
				{
					$nestedData['delivery_type']= "Cargo Delivery";
				}
				
				$executive='';
				$executive='<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_executive(this)"><option value="">Select Executive </option>';
					foreach ($exectives as $key => $value) {
						$executive.='<option value="'.$value['id'].'" '.(($post->store_id == $value['id'])? 'selected="selected"' :" ").'>'.$value['name'].'</option>';
						}
					
				$executive.='</select>';
				$nestedData['executive_drp'] =$executive;
				$data[] = $nestedData;

			}
		}

		

		$json_data = array(
		"draw"            => intval($this->input->post('draw')),  
		"recordsTotal"    => intval($totalData),  
		"recordsFiltered" => intval($totalFiltered), 
		"data"            => $data   
		);

		echo json_encode($json_data); 
	}

	public function orders(){
		self::index();
	}

	public function refund(){
		$data['title'] = 'Order Management';
		$data['page'] = 'orders';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();
		$data['extra_datatable_data'] .= '
			<script type="text/javascript">
				$(document).ready(function (){
				    $("#orderlist").DataTable({
				        "processing": true,
				        "serverSide": true,
				        "ajax":{
				            "url": "'.base_url('order_management/order_list/6').'",
				            "dataType": "json",
				            "type": "POST",
				            "data":{
				              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
				            }
				        },
				        "columns": [
				          { "data": "id" },
				          { "data": "ordernumber" },
				          { "data": "vendor" },
				          { "data": "user" },
				          { "data": "quantity" },
				          { "data": "price" },
				          { "data": "payment" },
				          { "data": "status" },
				          { "data": "action" },
				        ]
				    });
				});

				function change_status(that){
					var number = $(that).attr("data-number");
					var status = $(that).val();
					$.ajax({
						url: "'.base_url('order_management/change_status').'",
						data: { 
							"number": number, 
							"status": status
						},
						cache: false,
						type: "POST",
						success: function(response) {
							console.log(response);
							$("#orderlist").DataTable().ajax.reload();
						},
						error: function(xhr) {
							console.log(xhr);
						}
					});
				}
			</script>';
		$this->load->view('template',$data);
	}

	public function replace(){
		$data['title'] = 'Order Management';
		$data['page'] = 'orders';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();
		$data['extra_datatable_data'] .= '
			<script type="text/javascript">
				$(document).ready(function (){
				    $("#orderlist").DataTable({
				        "processing": true,
				        "serverSide": true,
				        "ajax":{
				            "url": "'.base_url('order_management/order_list/7').'",
				            "dataType": "json",
				            "type": "POST",
				            "data":{
				              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
				            }
				        },
				        "columns": [
				          { "data": "id" },
				          { "data": "ordernumber" },
				          { "data": "vendor" },
				          { "data": "user" },
				          { "data": "quantity" },
				          { "data": "price" },
				          { "data": "payment" },
				          { "data": "status" },
				          { "data": "action" },
				        ]
				    });
				});

				function change_status(that){
					var number = $(that).attr("data-number");
					var status = $(that).val();
					$.ajax({
						url: "'.base_url('order_management/change_status').'",
						data: { 
							"number": number, 
							"status": status
						},
						cache: false,
						type: "POST",
						success: function(response) {
							console.log(response);
							$("#orderlist").DataTable().ajax.reload();
						},
						error: function(xhr) {
							console.log(xhr);
						}
					});
				}
			</script>';
		$this->load->view('template',$data);
	}

	public function change_status(){
		$status = $this->input->post('status');
		$msg="";
		$result= $this->orders->change_status($status,$this->input->post('number'));
		if($status==5 || $status==7){
			if($status==5){
				$mssg= "Your order cancellation Accepted.";
			}else{
				$mssg= "Your order cancellation Declined.";
			}
			$rs = $this->orders->cancel_order_notification($this->input->post('number'),$msg);
			$this->load->library('fcm');
            $this->fcm->set_title("Mahwum:Order Cancellation");
            $this->fcm->set_image(base_url('/assets/img/logo.png'));
            $this->fcm->set_message("");
            $this->fcm->add_multiple_recipients($rs);
            $res1 = $this->fcm->send();
		}
		return $result;
	}

	public function view($value=null){
		if($value == null ){
			echo "please check your order id is not there";
			exit();
		}

		$data['title'] = 'Invoice';
		$data['page'] = 'invoice'; 
		$data['invoice'] = $this->orders->get_invoice($value);
		$this->load->view('template',$data);	

	}

	public function customer_order($id)
	{
		$data['title'] = 'Delivery Management';
		$post_data['id'] = $id;
		$data['extra_datatable_data']= $this->external->wizard(); 
		$data['extra_datatable_data'] .= $this->external->datatable_extra_js_css();     
		$data['extra_datatable_data'] .= $this->external->validation_extra_js_css();
		$data['orders'] = $this->orders->get_order($post_data);
		//$data['executive'] = $this->orders->get_cusomer_details($post_data);
		$data['page'] = 'customer_order'; 
		$this->load->view('template',$data);
	}
}
