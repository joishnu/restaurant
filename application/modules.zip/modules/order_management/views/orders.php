
<style type="text/css">
   /* Style the tab */
   .tab {
       overflow: hidden;
       border: 1px solid #ccc;
       background-color: #f1f1f1;
    }
   /* Style the buttons that are used to open the tab content */
    .tab button {
       background-color: inherit;
       float: left;
       border: none;
       outline: none;
       cursor: pointer;
       padding: 14px 16px;
       transition: 0.3s;
    }
   /* Change background color of buttons on hover */
    .tab button:hover {
        background-color: #ddd;
    }
   /* Create an active/current tablink class */
    .tab button.active {
        background-color: #ccc;
    }
   /* Style the tab content */
    .tabcontent {
       display: none;
       padding: 6px 12px;
       border: 1px solid #ccc;
       border-top: none;
    } 
</style>

<div class="right_col" role="main">
   <div class="">
      <div class="page-title">
         <div class="title_left">
            <h3>Order Management <small>| Orders List</small></h3>
         </div>
      </div>
      <div class="title_right">
         <!-- <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search" style="text-align: right">
            <a href="#" class="btn btn-primary"> <i class="fa fa-plus"></i> Add new product</a>
            </div> -->
      </div>
   </div>
   <div class="clearfix"></div>
   <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
         <div class="x_panel">
            <div class="x_title">
               <h2>Order List<small>All Order list</small></h2>
               <ul class="nav navbar-right panel_toolbox">
                  <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                  <li><a class="close-link"><i class="fa fa-close"></i></a></li>
               </ul>
               <div class="clearfix"></div>
            </div>
            <div class="x_content">
               <!-- Tab links -->
               <div class="tab">
                  <button class="tablinks active" onclick="openCity(event, 'all')">All Order</button>
                  <button class="tablinks" onclick="openCity(event, 'cancel')">Cancelled Orders</button>
                  <button class="tablinks" onclick="openCity(event, 'return')">Returned Orders</button>
               </div>
               <!-- Tab content -->
               <div id="all" class="tabcontent active" style="display: block;">
                  <table id="orderlist" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                     <thead>
                        <tr>
                           <th>#</th>
                           <th>Order Id</th>
                           <th>Sub Order Id</th>
                           <th>Vendor Name</th>
                           <th>Store Address</th>
                           <th>Customer Name</th>
                           <th>Customer Phone</th>
                           <th>Account Type</th>
                           <th>Customer Status</th>
                           <th>Transaction Id</th>
                           <th>Customer Email</th>
                           <th>Customer Address</th>
                           <th>Product Name</th>
                           <th>Quantity</th>
                           <th>Custom Value</th>
                           <th>Custom Description</th>
                           <th>Custom Image</th>
                           <th>Order Status</th>
                           <th>Cancel Reason</th>
                           <th>Return Reason</th>
                           <th>Total Amount</th>
                           <th>Payment Status</th>
                           <th>Executive Membership Id</th>
                           <th>Executive Name</th>
                           <th>Executive Address</th>
                           <th>Executive Phone</th>
                           <th>Executive Email</th>
                           <th>Store Name</th>
                           <th>Change Delivery</th>
                           <th>Delivery Type</th>
                           <th>Change Executive</th>
                        </tr>
                     </thead>
                     <tbody>
                     </tbody>
                  </table>
               </div>
               <div id="cancel" class="tabcontent" style="display: none;">
                  <table id="cancel_order" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                     <thead>
                        <tr>
                           <th>#</th>
                           <th>Order Id</th>
                           <th>Sub Order Id</th>
                           <th>Vendor Name</th>
                           <th>Store Address</th>
                           <th>Customer Name</th>
                           <th>Customer Phone</th>
                           <th>Account Type</th>
                           <th>Customer Status</th>
                           <th>Transaction Id</th>
                           <th>Customer Email</th>
                           <th>Customer Address</th>
                           <th>Product Name</th>
                           <th>Quantity</th>
                           <th>Custom Value</th>
                           <th>Custom Description</th>
                           <th>Custom Image</th>
                           <th>Order Status</th>
                           <th>Cancel Reason</th>
                           <th>Return Reason</th>
                           <th>Total Amount</th>
                           <th>Payment Status</th>
                           <th>Executive Membership Id</th>
                           <th>Executive Name</th>
                           <th>Executive Address</th>
                           <th>Executive Phone</th>
                           <th>Executive Email</th>
                           <th>Store Name</th>
                           <th>Change Delivery</th>
                           <th>Delivery Type</th>
                           <th>Change Executive</th>
                        </tr>
                     </thead>
                     <tbody>
                     </tbody>
                  </table>
               </div>
               <div id="return" class="tabcontent" style="display: none;">
                  <table id="return_order" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                     <thead>
                        <tr>
                           <th>#</th>
                           <th>Order Id</th>
                           <th>Sub Order Id</th>
                           <th>Vendor Name</th>
                           <th>Store Address</th>
                           <th>Customer Name</th>
                           <th>Customer Phone</th>
                           <th>Account Type</th>
                           <th>Customer Status</th>
                           <th>Transaction Id</th>
                           <th>Customer Email</th>
                           <th>Customer Address</th>
                           <th>Product Name</th>
                           <th>Quantity</th>
                           <th>Custom Value</th>
                           <th>Custom Description</th>
                           <th>Custom Image</th>
                           <th>Order Status</th>
                           <th>Cancel Reason</th>
                           <th>Return Reason</th>
                           <th>Total Amount</th>
                           <th>Payment Status</th>
                           <th>Executive Membership Id</th>
                           <th>Executive Name</th>
                           <th>Executive Address</th>
                           <th>Executive Phone</th>
                           <th>Executive Email</th>
                           <th>Store Name</th>
                           <th>Change Delivery</th>
                           <th>Delivery Type</th>
                           <th>Change Executive</th>
                        </tr>
                     </thead>
                     <tbody>
                     </tbody>
                  </table>
               </div>
               <p class="text-muted font-13 m-b-30">
                  <!-- If you want to write somting you can write here -->
               </p>
            </div>
         </div>
      </div>
   </div>
</div>
</div>

<script type="text/javascript">
   function openCity(evt, cityName) {
   // Declare all variables
   var i, tabcontent, tablinks;
   
   // Get all elements with class="tabcontent" and hide them
   tabcontent = document.getElementsByClassName("tabcontent");
   for (i = 0; i < tabcontent.length; i++) {
     tabcontent[i].style.display = "none";
   }
   
   // Get all elements with class="tablinks" and remove the class "active"
   tablinks = document.getElementsByClassName("tablinks");
   for (i = 0; i < tablinks.length; i++) {
     tablinks[i].className = tablinks[i].className.replace(" active", "");
   }
   
   // Show the current tab, and add an "active" class to the button that opened the tab
   document.getElementById(cityName).style.display = "block";
   evt.currentTarget.className += " active";
   }
</script>