<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * 
 */
class Commissions extends CI_Controller{
	
	function __construct(){
		parent::__construct();
		$this->load->library('external');
		$this->load->model('Commission_model', 'comm');
	}

	public function index(){
		$data['title'] = 'Commissions Management';
		$data['page'] = 'commission_list';
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();       
		$data['extra_datatable_data'] .= '
			<script type="text/javascript">
				$(document).ready(function (){
				    $("#datatable-responsive").DataTable({
				        "processing": true,
				        "serverSide": true,
				        "ajax":{
			            "url": "'.base_url('commissions/commissions_list').'",
			            "dataType": "json",
			            "type": "POST",
			            "data":{"'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" }
			        	},
				        "columns": [
				          { "data": "id" },
				          { "data": "vendor" },
				          { "data": "user" },
				          { "data": "phone" },
				          { "data": "email" },
				          { "data": "commission" },	
				          { "data": "action" },
				        ]
			    	});
				});
			</script>';
		$this->load->view('template',$data);       
	}

	public function commissions_list(){
		$columns = array(
			0 => "id",
			1 => "vendor",
			2 => "user",
			3 => "phone",
			4 => "email",
			5 => "commission",
			6 => "action",
		);

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
        $totalData = $this->comm->table_items_count('commissions');

        $totalFiltered = $totalData; 
        if(empty($this->input->post('search')['value'])){
        	$posts = $this->comm->all_items($limit,$start,$order,$dir);
        }else {
            $search = $this->input->post('search')['value']; 
            $posts =  $this->comm->item_search($limit,$start,$search,$order,$dir);
        }
  
  		$data = array();
		if(!empty($posts)){
			foreach ($posts as $post){
				$nestedData['id'] = '';
				$nestedData['vendor'] = (($post->vendor_name)? '<img style="max-width:30px; " src="'.ADMIN_PROFILE.$post->profile.'">' : '<img style="max-width:30px; " src="'.ADMIN_PROFILE.'default.jpg">').(' '.$post->vendor_name);
				$nestedData['user'] = $post->first_name.' '.$post->last_name;
				$nestedData['phone'] = $post->phone;
				$nestedData['email'] = $post->email;
				$nestedData['commission'] = '<b>'.$post->amount.' % </b>';
				$nestedData['action'] = '<a href="'.base_url('/commissions/edit').'/'.$post->comm_id.'"><button class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</button></a>';
				$data[] = $nestedData;
			}
		}

		$json_data = array(
		"draw"            => intval($this->input->post('draw')),  
		"recordsTotal"    => intval($totalData),  
		"recordsFiltered" => intval($totalFiltered), 
		"data"            => $data   
		);

		echo json_encode($json_data);
	}

	public function edit($comm_id=null){
		$this->form_validation->set_rules('comm_vendor','Vendor','required');
		$this->form_validation->set_rules('comm_amount','Commission in percent','required');
		if ($this->form_validation->run() == FALSE){
			echo validation_errors();			
			$data['title'] = 'Commissions Management';
			$data['page'] = 'commission_edit';

			if($comm_id != null){

				$data['info'] = $this->comm->info($comm_id);
				$data['vendors'] = $this->comm->vendors();
			}

			$this->load->view('template',$data); 
		}else{
			$array = array(
				'vendor_id'=>$this->input->post('comm_vendor'),
				'amount'=>$this->input->post('comm_amount'),
				'added_by'=>1, // need admin id session
				'updated_on'=>date("Y-m-d h:i:s")
			);

			if($this->input->post('comm_id')){
				unset($array['added_by']);
				$this->comm->update($array,$this->input->post('comm_id'));
			}
			else{
				$this->comm->add($array);
			}

			redirect('/commissions/index', 'refresh');
		}
	}
}
?>