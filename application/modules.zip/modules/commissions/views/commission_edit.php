<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Commissions Management <small>Update Commissions</small></h3>
      </div>
    </div>
  </div>
    <div class="clearfix"></div>
    <!-- Add category form -->
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <!-- <h2>Update Commissions </h2> -->
            <ul class="nav navbar-right panel_toolbox">
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <form class="form-horizontal form-label-left" method="post" novalidate action="<?=base_url('commissions/edit');?>">
              <span class="section">Update Commissions</span>
              
              <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="comm_vendor">Vendors <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12" >
                	<select id="comm_vendor" name="comm_vendor" class="form-control col-md-7 col-xs-12" >
                		<option value="">Please select vendor</option>
                		<?php 
                			foreach ($vendors as $key => $value) {
                				if((isset($info['vendor_id'])) && ($value['id'] == $info['vendor_id']))
                					echo '<option value="'.$value['id'].'" selected>'.$value['vendor_name'].'</option>';
                				else
                					echo '<option value="'.$value['id'].'">'.$value['vendor_name'].'</option>';
                			}
                		?>
                	</select>
                </div>
              </div>

              <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="comm_amount">Commission (%)<span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input id="comm_amount" class="form-control col-md-7 col-xs-12" name="comm_amount" placeholder="Please enter Commission in precent(%)" required="required" type="text" value="<?=(isset($info['amount']))?$info['amount']:'' ?>">
                </div>
              </div>
              
              <?php 
              if(isset($info['id'])){
                echo "<input type='hidden' value='".$info['id']."' name='comm_id' id='comm_id'>";
              }
              ?>

              <div class="ln_solid"></div>
              <div class="form-group">
                <div class="col-md-6 col-md-offset-3">
                  <button type="submit" class="btn btn-primary">Cancel</button>
                  <button id="send" type="submit" class="btn btn-success">Submit</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>

  </div>
</div>

