<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Commission_model extends CI_Model {

	public function table_items_count($table){
		$query = $this->db->get($table);
		return $query->num_rows();
	}

	public function all_items($limit,$start,$col,$dir){
		$this->db->select('*, commissions.id as comm_id');
		$this->db->join('vendors', 'vendors.id = commissions.vendor_id');
		$this->db->join('users', 'vendors.user_id = users.id');
		$query = $this->db
				->limit($limit,$start)
				//->order_by($col,$dir)
				->get('commissions');

		if($query->num_rows()>0)
            return $query->result(); 
        else
            return null;
        
	}

	function item_search($limit,$start,$search,$col,$dir)
    {
    	$this->db->select('*,commissions.id as comm_id');
		$this->db->join('vendors', 'vendors.id = commissions.vendor_id');
		$this->db->join('users', 'vendors.user_id = users.id');
        $query = $this->db
        	
        	->like('users.first_name',$search)
        	->or_like('users.last_name',$search)
        	->or_like('users.phone',$search)
        	->or_like('users.email',$search)
        	->or_like('vendors.vendor_name',$search)
        	->limit($limit,$start)->get('commissions');
        
       
        if($query->num_rows()>0)
            return $query->result();  
        else
            return null;
    }

    function item_count_search($search, $table)
    {

        $query = $this->db
                ->like('id',$search)
        		->or_like('address',$search)
                ->get($table);
        return $query->num_rows();
    }

    public function add($data){
    	return $this->db->insert('commissions',$data);
    }

    public function update($data, $id){
    	$this->db->where('id', $id);
    	return $this->db->update('commissions', $data);
    }

    public function info($id){
    	$this->db->where('id', $id);
    	return $this->db->get('commissions')->row_array();
    }

    public function vendors(){
    	return $this->db->get('vendors')->result_array();
    }
} 
?>