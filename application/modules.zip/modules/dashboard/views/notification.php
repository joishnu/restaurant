<a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
    <?php $notification = getNotifications();?>
    <i class="fa fa-envelope-o"></i>
    <span class="badge bg-green"><?php echo count($notification);?></span>
</a>
<ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
    <li>
        <?php foreach($notification as $key=>$value){?>
            <a onclick="read_notification('<?php echo $value['id'];?>')">
                <!-- <span class="image"><img src="<?=base_url('assets/admin/profile');?>/admin-profile.png" alt="Profile Image" /></span>
                <span>
                    <span>John Smith</span>
                    <span class="time">3 mins ago</span>
                </span>
                <span class="message">
                    Film festivals used to be do-or-die moments for movie makers. They were where...
                </span> -->

                <span>
                    <span><?php echo $value['title'];?></span>
                </span>
                <span class="message"><?php echo $value['message'];?></span>
                <hr>
            </a>
        <?php }?>
    </li>
    
</ul>
<script type="text/javascript">
	function read_notification(id) {
		var url = "<?php echo base_url(); ?>dashboard/read_notification/"+id;
		//alert(url);
        $.ajax({
            type  :   'POST',
            url   :   "<?php echo base_url(); ?>dashboard/read_notification/"+id,
            success: function(result)
            {
                //console.log(result);
            }
        });
    }
</script>