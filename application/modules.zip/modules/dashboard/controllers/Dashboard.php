<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('dashboard_model','dashboard');
	}
	
	public function index(){
		$data['title'] = 'dashboard';
		$data['page'] = 'index';       
		$this->load->view('template',$data);
	}

	public function notification_count()
    {   
        //echo "working";
        $data['result'] = $this->dashboard->getNotifications();
        $this->load->view('dashboard/notification',$data);
    }

    public function read_notification($id)
    {
        $result = $this->dashboard->read_notification($id);
        //show($result);
    }
	
}
