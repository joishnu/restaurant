<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Dashboard_model extends CI_Model {

    /*public function total_vendor()  {
        return $this->db->count_all_results('nsr_vendors');
    }
    public function total_cusomer()  {
       $this->db->where("user_type",3);
       return  $this->db->count_all_results('nsr_users');
    }
    public function total_category()  {
       return  $this->db->count_all_results('nsr_categories');
    }
    public function total_cms()  {
       return  $this->db->count_all_results('nsr_cms');
    }
    public function total_etemplate()  {
       return  $this->db->count_all_results('nsr_email_template');
    }*/
    
    
    public function getNotifications()
    {   
        //show($this->session->userdata);
        if($this->session->userdata('user_type')==1){
            $this->db->where('notification.user_type', 4);
        }
        if($this->session->userdata('user_type')==2){
            $this->db->where('notification.user_type', 2);
            $this->db->where('notification.user_id', $this->session->userdata('id'));   
        }
        $this->db->select('notification.*');
        $this->db->where('message_read',0);
        $this->db->order_by('id', 'desc');
        $result = $this->db->get('notification')->result_array();
        return $result;
    }

    public function read_notification($id)
    {
        $this->db->set('message_read',1);
        $this->db->where('id', $id);
        $this->db->update('notification');
        return $this->db->affected_rows();
    }
}
