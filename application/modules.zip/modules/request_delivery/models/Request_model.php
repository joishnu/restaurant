<?php
/**
 * 
 */
class Request_model extends CI_Model
{
	
	public function table_items_count($table){
        $this->db->join('delivery_executives d','d.id=order_details.executive_id',"left");
        $this->db->join('orders','orders.id=order_details.order_id');
        $this->db->where('orders.payment_status', '1');
        $this->db->where('order_details.delivery_type', '2');
        if($this->session->userdata('user_type')=='2')
        {
            $this->db->where('order_details.vendor_id', $this->session->userdata('id') );    
        }
		$query = $this->db->get($table);
		return $query->num_rows();
	}

	public function all_items($limit,$start,$col,$dir, $order_status = 1){

		$this->db->select('o.id, o.price as per_total_price, orders.total_price as whole_total_price,o.quantity as total_quanity,orders.tax as whole_total_tax, o.order_status, p.name, v.vendor_name,v.vendor_id as vendor_generated_id, v.office_number, u.first_name, u.last_name, o.quantity, orders.public_id,o.custom_value, o.custom_description, o.custom_image, o.store_id, o.delivery_type, o.executive_id as delivery_executive_id, o.order_status, orders.address_id, orders.txn_id as transcation_id, orders.payment_status, concat(store_name,", ", store_address) as store_address,d.member_id, d.name as executive_name, d.address as executive_address, concat(d.country_code," ",d.phone) as executive_phone, d.email_id as executive_email, concat(u.first_name, 
            " ", last_name) as customer_name, concat(u.country_code, " ", u.phone) as customer_phone, u.email as customer_email,u.account_type, u.status as customer_status, concat(ad.address_line1,", ",ad.address_line2,", ", ad.address_line3,", ", pincode, ", ", ad.city,", ", ad.state, ", ",ad.country) as customer_address,s.store_name, s.store_address');
        $this->db->join('addresses as ad', 'ad.id = o.address_id',"left");  
        $this->db->join('stores as s', 's.id = o.address_id',"left");  
        $this->db->join('users as u', 'u.id = o.customer_id');  
		$this->db->join('variations as vr', 'vr.id = o.variation_id');
		$this->db->join('products as p', 'p.id = vr.product_id');
		$this->db->join('vendors as v', 'v.id = p.vendor_id');
		//if($order_status != 1)
		$this->db->join('delivery_executives d','d.id=o.executive_id',"left");
        $this->db->join('orders','orders.id=o.order_id');
        $this->db->where('orders.payment_status', '1');
        $this->db->where('o.delivery_type', '2');
        if($this->session->userdata('user_type')=='2')
        {
            $this->db->where('o.vendor_id', $this->session->userdata('id') );    
        }
        
		$query = $this->db
				->limit($limit,$start)
				//->order_by($col,$dir)
				->get('order_details as o');
		if($query->num_rows()>0)
            return $query->result(); 
         
        else
            return null;
        
	}

	public function item_search($limit,$start,$search,$col,$dir, $order_status = 1){
    $this->db->select('o.id, o.price as per_total_price, orders.total_price as whole_total_price,o.quantity as total_quanity,orders.tax as whole_total_tax, o.order_status, p.name, v.vendor_name,v.vendor_id as vendor_generated_id, v.office_number, u.first_name, u.last_name, o.quantity, orders.public_id,o.custom_value, o.custom_description, o.custom_image, o.store_id, o.delivery_type, o.executive_id as delivery_executive_id, o.order_status, orders.address_id, orders.txn_id as transcation_id, orders.payment_status, concat(store_name,", ", store_address) as store_address,d.member_id, d.name as executive_name, d.address as executive_address, concat(d.country_code," ",d.phone) as executive_phone, d.email_id as executive_email, concat(u.first_name, 
            " ", last_name) as customer_name, concat(u.country_code, " ", u.phone) as customer_phone, u.email as customer_email,u.account_type, u.status as customer_status, concat(ad.address_line1,", ",ad.address_line2,", ", ad.address_line3,", ", pincode, ", ", ad.city,", ", ad.state, ", ",ad.country) as customer_address,s.store_name, s.store_address');
        $this->db->join('addresses as ad', 'ad.id = o.address_id',"left");  
        $this->db->join('stores as s', 's.id = o.address_id',"left");  
        $this->db->join('users as u', 'u.id = o.customer_id');  
        $this->db->join('variations as vr', 'vr.id = o.variation_id');
        $this->db->join('products as p', 'p.id = vr.product_id');
        $this->db->join('vendors as v', 'v.id = p.vendor_id');
        //if($order_status != 1)
        $this->db->join('delivery_executives d','d.id=o.executive_id',"left");
        $this->db->join('orders','orders.id=o.order_id');
        $this->db->where('orders.payment_status', '1');
        $this->db->where('o.delivery_type', '2');
        $query = $this->db
        	->like('orders.public_id',$search)
        	->or_like('o.order_status',$search)
        	->or_like('p.name',$search)
        	->or_like('v.vendor_name',$search)
        	->or_like('u.first_name',$search)
        	->or_like('u.last_name',$search)
        	->limit($limit,$start)->get('order_details as o');
        
        if($query->num_rows()>0)
            return $query->result();  
        else
            return null;
    }

    public function change_status($status, $number){
    	$this->db->where('id', $number);
    	$this->db->update('order_details', array('order_status'=>$status));
        return true;
    	
    }

    public function change_delivery_exective($executive_id, $number){
        $this->db->where('id', $number);
        $this->db->update('order_details', array('executive_id'=>$executive_id));
        return true;
        
    }

    public function change_type($type, $number){
        $this->db->where('id', $number);
        $this->db->update('order_details', array('delivery_type'=>'2'));
        return true;
        
    }

    public function change_pick_store($store_id, $number){
        $this->db->where('id', $number);
        $this->db->update('order_details', array('store_id'=>$store_id));
        return true;
        
    }

    public function get_invoice($id){
    	$this->db->select('u.first_name, u.last_name, u.phone, u.email, o.order_number, o.id , o.discounted_price, o.final_price, o.order_status, o.order_type, o.delivery_address, o.delivery_pincode, o.delivery_mobile, o.delivery_email, o.added_on, t.transition_number, t.transition_status, o.tax, o.shipping, o.base_price');
    	$this->db->join('customers as c',' c.id = o.customer_id');
    	$this->db->join('transitions as t','t.id = o.transition_id');
        $this->db->join('users as u','u.id = c.user_id');
        $this->db->where('o.id', $id);
        $inv_data = $this->db->get('orders_history as o')->row_array();

        $this->db->select('vr.sku, p.name, vn.vendor_name, oi.price, oi.quantity, oi.id');
        $this->db->where('order_id', $inv_data['id']);
        $this->db->join('variations as vr','vr.id = oi.variation_id');
        $this->db->join('products as p','vr.product_id = p.id');
    	$this->db->join('vendors as vn','p.vendor_id = vn.id');
        $inv_data['items'] = $this->db->get('order_items as oi')->result_array();
        
        return $inv_data;
    }

    public function get_tax(){
        $this->db->where('status', 1); 
        return $this->db->get('taxes')->result_array(); 
    }
    public function all_stores(){
        $this->db->where('user_id',$this->session->userdata('id'));
        return $this->db->get('stores')->result_array();
    }
    public function all_executives(){
        if($this->session->userdata('user_type')==2)
        {
            $this->db->where('vendor_id',$this->session->userdata('id'));
        }
        else if($this->session->userdata('user_type')==1)
        {
            $this->db->where('type','1');   
        }
        $this->db->where('status', 1); 
        return $this->db->get('delivery_executives')->result_array();
    }
}
