<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Product Management <small>| Product List</small></h3>
      </div>
    </div>
    <div class="title_right">
      <!-- <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search" style="text-align: right">
        <a href="#" class="btn btn-primary"> <i class="fa fa-plus"></i> Add new product</a>
      </div> -->
    </div>
  </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Products List<small>All product list</small></h2>
              <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                <li><a class="close-link"><i class="fa fa-close"></i></a></li>
              </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <p class="text-muted font-13 m-b-30"><!-- If you want to write somting you can write here --></p>
            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Attributes</th>
                  <th>Sub-Category</th>
                  <th>Category</th>
                  <th>MRP</th>
                  <th>Selling price</th>
                  <th>Availability</th>
                  <th>barcode</th>
                  <th>Status</th>
                  <th>images</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td></td>
                  <td>Iphone XS</td>
                  <td>Black</td>
                  <td>Mobiles</td>
                  <td>Elecronics</td>
                  <td>SAR 50,000.00</td>
                  <td>SAR 42,000.00</td>
                  <td>0</td>
                  <td>|||||||||||||||</td>
                  <td>Active</td>
                  <td>
                    <img src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/image/AppleInc/aos/published/images/M/KX/MKXM2/MKXM2?wid=572&hei=572&fmt=jpeg&qlt=95&op_usm=0.5,0.5&.v=0" style="max-height: 150px; border:1px solid lightgrey; border-radius: 20px; text-shadow: 2px 2px 2px black;">
                    <img src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/image/AppleInc/aos/published/images/M/KX/MKXM2/MKXM2_AV1_ROSEGLD?wid=572&hei=572&fmt=jpeg&qlt=95&op_usm=0.5,0.5&.v=0" style="max-height: 150px; border:1px solid lightgrey; border-radius: 20px; text-shadow: 2px 2px 2px black;">
                    <img src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/image/AppleInc/aos/published/images/M/KX/MKXM2/MKXM2?wid=572&hei=572&fmt=jpeg&qlt=95&op_usm=0.5,0.5&.v=0" style="max-height: 150px; border:1px solid lightgrey; border-radius: 20px; text-shadow: 2px 2px 2px black;">
                    <img src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/image/AppleInc/aos/published/images/M/KX/MKXM2/MKXM2_AV1_ROSEGLD?wid=572&hei=572&fmt=jpeg&qlt=95&op_usm=0.5,0.5&.v=0" style="max-height: 150px; border:1px solid lightgrey; border-radius: 20px; text-shadow: 2px 2px 2px black;">
                  </td>
                  <td>
                    <select class="btn btn-primary">
                      <option><i class="fa fa-check"></i> Active</option>
                      <option><i class="fa fa-times"></i> In-Active</option>
                    </select>
                    <a href="#" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
                  </td>
                </tr>

                <tr>
                  <td></td>
                  <td>Samsung Galaxy 8</td>
                  <td>Red Round</td>
                  <td>Mobiles</td>
                  <td>Elecronics</td>
                  <td>SAR 30,000.00</td>
                  <td>SAR 26,499.00</td>
                  <td>0</td>
                  <td>|||||||||||||||</td>
                  <td>Active</td>
                  <td><img src="https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/image/AppleInc/aos/published/images/M/KX/MKXM2/MKXM2_AV1_ROSEGLD?wid=572&hei=572&fmt=jpeg&qlt=95&op_usm=0.5,0.5&.v=0" style="max-height: 150px;"></td>
                  <td>
                    <select class="btn btn-primary">
                      <option><i class="fa fa-check"></i> Active</option>
                      <option><i class="fa fa-times"></i> In-Active</option>
                    </select>
                    <a href="#" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
                  </td>
                </tr>


              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

