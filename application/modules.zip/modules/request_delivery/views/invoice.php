<?php

$txn_status = array(
  1=>'Pending',
  2=>'Successful',
  3=>'Failed'
);
?>
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Order Management <small>| Invoice</small></h3>
      </div>
    </div>
    <div class="title_right">
      <!-- <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search" style="text-align: right">
        <a href="#" class="btn btn-primary"> <i class="fa fa-plus"></i> Add new product</a>
      </div> -->
    </div>
  </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Invoice </h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <section class="content invoice">
                      <!-- title row -->
                      <div class="row">
                        <div class="col-xs-12 invoice-header">
                          <h1>
                                          <i class="fa fa-globe"></i> Deals.
                                          <small class="pull-right">Date: <?=date('d M, Y', strtotime($invoice['added_on'])); ?></small>
                                      </h1>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- info row -->
                      <div class="row invoice-info">
                        <!-- <div class="col-sm-4 invoice-col">
                          From
                          <address>
                                          <strong>Iron Admin, Inc.</strong>
                                          <br>795 Freedom Ave, Suite 600
                                          <br>New York, CA 94107
                                          <br>Phone: 1 (804) 123-9876
                                          <br>Email: ironadmin.com
                                      </address>
                        </div> -->
                        <!-- /.col -->
                        <div class="col-sm-6 invoice-col">
                          To
                          <address>
                                          <strong><?=$invoice['first_name'].' '.$invoice['last_name']; ?></strong>
                                          <br><?=$invoice['delivery_address']; ?>
                                          <br><?=$invoice['delivery_pincode']; ?>
                                          <br>Phone: <?=$invoice['delivery_mobile']; ?>
                                          <br>Email: <?=$invoice['delivery_email']; ?>
                                      </address>
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4 invoice-col">
                          <b>Order ID:</b> <?=$invoice['order_number']; ?>
                          <br><b>Payment :</b> <?=$txn_status[$invoice['transition_status']]; ?>
                          <br><b>Paid on :</b> <?=date('d M, Y', strtotime($invoice['added_on'])); ?>
                          <br>
                          <br>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->

                      <!-- Table row -->
                      <div class="row">
                        <div class="col-xs-12 table">
                          <table class="table table-striped">
                            <thead>
                              <tr>
                                <th>#</th>
                                <th>SKU</th>
                                <th>Product</th>
                                <th>Vendor</th>
                                <th>quantity</th>
                                <th>Subtotal</th>
                              </tr>
                            </thead>
                            <tbody>
                              <?php $i=1; foreach ($invoice['items'] as $key => $value) { ?>
                                  <tr>
                                    <td><?php echo $i; ?></td>
                                    <td><?=$value['sku']?></td>
                                    <td><?=$value['name']?></td>
                                    <td><?=$value['vendor_name']?></td>
                                    <td><?=$value['quantity']?></td>
                                    <td>SAR <?=$value['price']?></td>
                                  </tr>
                              <?php $i++; } ?>
                            </tbody>
                          </table>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->

                      <div class="row">
                        <!-- accepted payments column -->
                        <div class="col-xs-6">
                          <p class="lead">Payment Methods: <?=($invoice['order_type'] == 1)? "Online" : "Offline"; ?></p>
                          <p >Terms and conditions</p>
                          <ul>
                            <li>a</li>
                            <li>b</li>
                            <li>c</li>
                            <li>d</li>
                          </ul>
                          
                        </div>
                        <!-- /.col -->
                        <div class="col-xs-6">
                          <div class="table-responsive">
                            <table class="table">
                              <tbody>
                                <tr>
                                  <th style="width:50%">Subtotal:</th>
                                  <td>SAR <?=$invoice['base_price']; ?></td>
                                </tr>
                                <tr>
                                  <th>Discount:</th>
                                  <td>SAR <?=$invoice['discounted_price']; ?></td>
                                </tr>
                                <tr>
                                  <th>Tax</th>
                                  <td>SAR <?=$invoice['tax']; ?></td>
                                </tr>
                                <tr>
                                  <th>Shipping:</th>
                                  <td>SAR <?=$invoice['shipping']; ?></td>
                                </tr>
                                <tr>
                                  <th>Total:</th>
                                  <td>SAR <?=$invoice['final_price']; ?></td>
                                </tr>
                              </tbody>
                            </table>
                          </div>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->

                      <!-- this row will not appear when printing -->
                      <div class="row no-print">
                        <div class="col-xs-12">
                          <button class="btn btn-default" onclick="window.print();"><i class="fa fa-print"></i> Print</button>
                          <!-- <button class="btn btn-success pull-right"><i class="fa fa-credit-card"></i> Submit Payment</button> -->
                          <button class="btn btn-primary pull-right" style="margin-right: 5px;"><i class="fa fa-download"></i> Generate PDF</button>
                        </div>
                      </div>
                    </section>
                  </div>
                </div>
              </div>
    </div>
  </div>
</div>

