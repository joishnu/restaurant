<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Order Management <small>| Replace Orders List</small></h3>
      </div>
    </div>
    <div class="title_right">
      <!-- <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search" style="text-align: right">
        <a href="#" class="btn btn-primary"> <i class="fa fa-plus"></i> Add new product</a>
      </div> -->
    </div>
  </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Replace Order List<small>All Replace  and replace request Order list</small></h2>
              <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                <li><a class="close-link"><i class="fa fa-close"></i></a></li>
              </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <p class="text-muted font-13 m-b-30"><!-- If you want to write somting you can write here --></p>
            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Order Number</th>
                  <th>Product name</th>
                  <th>Quantity</th>
                  <th>Price</th>
                  <th>Delivered date</th>
                  <th>Request date</th>
                  <th>Barcode</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td></td>
                  <td>DEALS<?= mt_rand('100000','9999999');?>WXD<?= mt_rand('100000','9999999');?></td>
                  <td>Iphone 8 Plus Black 64GB</td>
                  <td>2</td>
                  <td>SAR 42,599.00</td>
                  <td>12 jan, 2015</td>
                  <td>16 jan, 2015</td>
                  <td>|||||||||||||||</td>
                  <td>Replaced</td>
                  <td>
                    <select class="btn btn-primary">
                      <option><i class="fa fa-check"></i> Delivared</option>
                      <option><i class="fa fa-times"></i> Refund Request</option>
                      <option><i class="fa fa-times"></i> Replace Request</option>
                      <option><i class="fa fa-times"></i> Order Dispatch</option>
                    </select>
                    <a href="#" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>
                  </td>
                </tr>

                <tr>
                  <td></td>
                  <td>DEALS<?= mt_rand('100000','9999999');?>WXD<?= mt_rand('100000','9999999');?></td>
                  <td>Denim's Female jeans</td>
                  <td>5</td>
                  <td>SAR 859.00</td>
                  <td>21 feb, 2015</td>
                  <td>3 Feb, 2015</td>
                  <td>|||||||||||||||</td>
                  <td>Request</td>
                  <td>
                    <select class="btn btn-primary">
                      <option><i class="fa fa-check"></i> Delivared</option>
                      <option><i class="fa fa-times"></i> Refund Request</option>
                      <option><i class="fa fa-times"></i> Replace Request</option>
                      <option><i class="fa fa-times"></i> Order Dispatch</option>
                    </select>
                    <a href="#" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>
                  </td>
                </tr>

                <tr>
                  <td></td>
                  <td>DEALS<?= mt_rand('100000','9999999');?>WXD<?= mt_rand('100000','9999999');?></td>
                  <td>Baby MoterCycel</td>
                  <td>1</td>
                  <td>SAR 1259.00</td>
                  <td>12 jan, 2015</td>
                  <td>16 jan, 2015</td>
                  <td>|||||||||||||||</td>
                  <td>Order Delivered</td>
                  <td>
                    <select class="btn btn-primary">
                      <option><i class="fa fa-check"></i> Delivared</option>
                      <option><i class="fa fa-times"></i> Refund Request</option>
                      <option><i class="fa fa-times"></i> Replace Request</option>
                      <option><i class="fa fa-times"></i> Order Dispatch</option>
                    </select>
                    <a href="#" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>
                  </td>
                </tr>

              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

