<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Cms extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('cms_model','cms');

	}

	public function about_us($id=""){
		$data['title'] = 'Cms Management';
		$data['list'] = $this->cms->cms_details($id);      
		//echo"<pre>";print_r($data['list']);die; 
		$data['page'] = 'list';       
		$this->load->view('template',$data);
	}
	public function do_update() {
        $this->form_validation->set_rules('title','title','required');
        $this->form_validation->set_rules('description','description','required');
        if($this->form_validation->run()) {
            $info = $this->input->post(NULL,true);
            //echo"<pre>";print_r($info);die; 
            $rs = $this->cms->do_update_cms($info);

            if($rs) {
                $this->session->set_flashdata('success', 'cms has been updated successfully');
                redirect(site_url('cms/about_us'));
            } 
            else {
                $this->session->set_flashdata('error', 'Some error occurred. Please try again.');
            }
        } 
        else {
            $this->session->set_flashdata('error',validation_errors());
        }
        redirect(site_url('cms/about_us/'.$info['about_id']));
    }
    public function contact_us($id=""){
		$data['title'] = 'Cms Management';
		$data['list'] = $this->cms->contact_details($id);      
		//echo"<pre>";print_r($data['list']);die; 
		$data['page'] = 'contact';       
		$this->load->view('template',$data);
	}
	public function update_contact_us() {
        $this->form_validation->set_rules('title','title','required');
        $this->form_validation->set_rules('description','description','required');
        if($this->form_validation->run()) {
            $info = $this->input->post(NULL,true);
            //echo"<pre>";print_r($info);die; 
            $rs = $this->cms->do_update_contact($info);

            if($rs) {
                $this->session->set_flashdata('success', 'cms has been updated successfully');
                redirect(site_url('cms/contact_us'));
            } 
            else {
                $this->session->set_flashdata('error', 'Some error occurred. Please try again.');
            }
        } 
        else {
            $this->session->set_flashdata('error',validation_errors());
        }
        redirect(site_url('cms/contact_us/'.$info['contact_id']));
    }

	}