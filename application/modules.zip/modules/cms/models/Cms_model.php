<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * @author bimlesh
 *
 */
class Cms_model extends CI_Model {

	public function cms_details($id=""){
        $this->db->select("*");
        $this->db->from("cms");
        $this->db->where("id",1);
        return $this->db->get()->row_array();
  	}
  	public function do_update_cms($params) {
        try { 
            $this->db->trans_begin();
            $where = array(
                'id' => $params['about_id']
            );
                $update_data = array(
                'title' => $params['title'],
                'description' => $params['description']
            );
            if(!$this->db->update('cms', $update_data, $where)) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return TRUE;
            
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return FALSE;
        }
    }
    public function contact_details($id=""){
        $this->db->select("*");
        $this->db->from("cms");
        $this->db->where("id",2);
        return $this->db->get()->row_array();
  	}
  	public function do_update_contact($params) {
        try { 
            $this->db->trans_begin();
            $where = array(
                'id' => $params['contact_id']
            );
                $update_data = array(
                'title' => $params['title'],
                'description' => $params['description']
            );
            if(!$this->db->update('cms', $update_data, $where)) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return TRUE;
            
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return FALSE;
        }
    }


	
}
