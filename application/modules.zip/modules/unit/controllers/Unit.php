<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Unit extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('unit_model','product');
		$this->load->library('external');
	}

	public function index(){
		$data['title'] = 'Unit Management';
		$data['page'] = 'unit';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();     
		$data['extra_datatable_data'] .= $this->external->validation_extra_js_css();     
		$data['extra_datatable_data'] .= '<script type="text/javascript">
											$(document).ready(function (){
											    $("#product").DataTable({
											        "processing": true,
											        "serverSide": true,
											        "ajax":{
											            "url": "'.base_url('unit/unit_list').'",
											            "dataType": "json",
											            "type": "POST",
											            "data":{
											              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
											            }
											        },
											        "columns": [
											          { "data": "id" },
											          { "data": "name" },
											          { "data": "description" },
 											          { "data": "status" },
											          { "data": "created_on" },
											          { "data": "action" },
											        ]
											    });
											});
											function edit_func(id){
												$.ajax({
													url: "'.base_url('unit/unit_name').'",
													data: { 
														"number": id, 
													},
													cache: false,
													type: "POST",
													success: function(response) {
														$("#id_design_hid").val(id);
														var vl=JSON.parse(response);

														$("#name").val(vl.name);
														$("#description").val(vl.description);
														
													},
													error: function(xhr) {
														console.log(xhr);
													}
												});
												$("#edit-item").modal("show");
												
											}

											function change_status(that){
												var number = $(that).attr("data-number");
												var status = $(that).val();
												$.ajax({
													url: "'.base_url('unit/change_status').'",
													data: { 
														"number": number, 
														"status": status
													},
													cache: false,
													type: "POST",
													success: function(response) {
														console.log(response);
														$("#product").DataTable().ajax.reload();
													},
													error: function(xhr) {
														console.log(xhr);
													}
												});
											}
											</script>

											';
											//print_r($data['extra_datatable_data']);exit();
		$this->load->view('template',$data);
	}

	public function unit_name(){
		echo json_encode($this->product->get_unit_name($this->input->post(NULL,true)));
	}

	// Product List ajax call for product list datatable
	public function unit_list(){
		$columns = array(
			0 => "id",
			1 => "name",
			2 => "description",
			3 => "status",
			4 => "created_on",
			5 => "action"
		);

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
        $totalData = $this->product->table_items_count('units');

        $totalFiltered = $totalData; 
        if(empty($this->input->post('search')['value'])){
        	$posts = $this->product->all_items($limit,$start,$order,$dir, 'units', "units.status,units.name,units.id as id,units.created_on, units.description");
        }else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->product->item_search($limit,$start,$search,$order,$dir, 'units', "units.status,units.name,units.id as id,units.created_on, units.description");
            $totalFiltered = $this->product->item_count_search($search,  'units');
        }
  		$data = array();
		if(!empty($posts)){
			$j=0;
			foreach ($posts as $post){
				$j++;
			
				$nestedData['id'] = $j;
				$nestedData['name'] = $post->name;
				$nestedData['description']=$post->description;
				$nestedData['status'] = '<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
					<option value="0" '.(($post->status == 0)? 'selected="selected"' :" ").' >Deactivate </option>
					<option value="1" '.(($post->status == 1)? 'selected="selected"' :" ").'>Activate</option>
				</select>';
				$nestedData['created_on'] = $post->created_on;
				$nestedData['action'] = '
				<button class="btn btn-primary edit" onclick="edit_func('.$post->id.')"><i class="fa fa-pencil" ></i> Edit</button><a href="'.base_url('/area/delete').'/'.$post->id.'"><button class="btn btn-danger"><i class="fa fa-remove" ></i> Delete</button></a><!--<a data-toggle="modal" data-target=".bs-example-modal-lg"><button class="btn btn-primary"><i class="fa fa-pencil"></i> View</button></a>-->
				';
					$data[] = $nestedData;
			}
		}

		$json_data = array(
		"draw"            => intval($this->input->post('draw')),  
		"recordsTotal"    => intval($totalData),  
		"recordsFiltered" => intval($totalFiltered), 
		"data"            => $data   
		);
		echo json_encode($json_data); 
	}


	public function delete($id = 0)
    {
        try {
            if(!$id) {
                throw new Exception('Choose a Units', 1);
            }
            $rs = $this->product->do_delete($id);

            if(!$rs){
                throw new Exception("Error Processing Request", 1);   
            }

            $this->session->set_flashdata('success', 'Unit is deleted successfully');
            redirect(site_url('unit'));

        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(site_url('unit'));

        }
    }

	public function do_add_unit() {
		  try {
            $this->form_validation->set_rules('name', 'Unit Name', 'trim|required');
            $this->form_validation->set_rules('description', 'Description', 'trim|required');
           if(!$this->form_validation->run()){
                throw new Exception(validation_errors());
            }
            $info = $this->input->post(NULL, TRUE);

            $rs = $this->product->do_add_unit($info);
            if(!$rs) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->session->set_flashdata('success', "Unit is added successfully!");
            redirect(site_url('unit'));
        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(site_url('unit'));
        }
	}

	public function do_update_unit() {
		try{
	        $this->form_validation->set_rules('name', 'Name', 'trim|required');
	        $this->form_validation->set_rules('description', 'Description', 'trim|required');
	        $info = $this->input->post(NULL, TRUE);

	        if (!$this->form_validation->run()) {
	            throw new Exception(validation_errors());
	        }
	        //$this->product->validate_name($info['name'],$info['id']);
	      	$rs = $this->product->do_update_unit($info);
            if(!$rs) {
                throw new Exception("Error Processing Request", 1);
            }
	        $this->session->set_flashdata('success', 'Unit is updated successfully');
	        redirect(site_url('unit'));
	    }catch(Exception $ex){
	        $this->session->set_flashdata('error', $e->getMessage());
	        redirect(site_url('unit'));
	    }
	}

	public function change_status() {
		$this->form_validation->set_rules('number','number','trim|required');
	    $info = $this->input->post(NULL,true);
	    echo json_encode($this->product->change_status($info));
	}

}
