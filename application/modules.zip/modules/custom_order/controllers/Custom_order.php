<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Custom_order extends CI_Controller {
	

	function __construct(){
		parent::__construct();
		$this->load->model('custom_model','orders');
		$this->load->library('external');
	}

	public function index(){
		$data['title'] = 'Order Management';
		$data['page'] = 'orders';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();
		$data['extra_datatable_data'] .= '
			<script type="text/javascript">
				$(document).ready(function (){
				    $("#orderlist").DataTable({
				        "processing": true,
				        "serverSide": true,
				        "ajax":{
				            "url": "'.base_url('custom_order/order_list').'",
				            "dataType": "json",
				            "type": "POST",
				            "data":{
				              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
				            }
				        },
				        "columns": [
				          { "data": "id" },
				          { "data": "vendor_name" },
				          { "data": "customer_name" },
				          { "data": "customer_phone" },
				          { "data": "account_type" },
				          { "data": "customer_status" },
				          { "data": "customer_email" },
				          { "data": "customer_address" },
				          { "data": "variation_name" },
				          { "data": "quantity" },
				          { "data": "custom_value" },
				          { "data": "custom_description" },
				          { "data": "custom_image" },
				        ]
				    });
				});

				function change_status(that){
					var number = $(that).attr("data-number");
					var status = $(that).val();
					$.ajax({
						url: "'.base_url('custom_order/change_status').'",
						data: { 
							"number": number, 
							"status": status
						},
						cache: false,
						type: "POST",
						success: function(response) {
							console.log(response);
							$("#orderlist").DataTable().ajax.reload();
						},
						error: function(xhr) {
							console.log(xhr);
						}
					});
				}
				function change_store(that){
					var number = $(that).attr("data-number");
					var store_id = $(that).val();

					$.ajax({
						url: "'.base_url('custom_order/change_pick_store').'",
						data: { 
							"number": number, 
							"store_id": store_id
						},
						cache: false,
						type: "POST",
						success: function(response) {
							console.log(response);
							$("#orderlist").DataTable().ajax.reload();
						},
						error: function(xhr) {
							console.log(xhr);
						}
					});
				}
				function change_executive(that){
					var number = $(that).attr("data-number");
					var executive_id = $(that).val();
					$.ajax({
						url: "'.base_url('custom_order/change_delivery_exective').'",
						data: { 
							"number": number, 
							"executive_id": executive_id
						},
						cache: false,
						type: "POST",
						success: function(response) {
							console.log(response);
							$("#orderlist").DataTable().ajax.reload();
						},
						error: function(xhr) {
							console.log(xhr);
						}
					});
				}
				function change_type(that){
					var number = $(that).attr("data-number");
					var types = 2;
					$.ajax({
						url: "'.base_url('custom_order/change_type').'",
						data: { 
							"number": number, 
							"types": types
						},
						cache: false,
						type: "POST",
						success: function(response) {
							console.log(response);
							$("#orderlist").DataTable().ajax.reload();
						},
						error: function(xhr) {
							console.log(xhr);
						}
					});
				}
			</script>';
		$this->load->view('template',$data);
	}

	
    public function change_delivery_exective(){
      	return $this->orders
				->change_delivery_exective(
					$this->input->post('executive_id'), 
					$this->input->post('number')
				);
        
    }

    public function change_pick_store(){
       	return $this->orders
				->change_pick_store(
					$this->input->post('store_id'), 
					$this->input->post('number')
				);
        
    }

    public function change_type(){
       	return $this->orders
				->change_type(
					$this->input->post('types'), 
					$this->input->post('number')
				);
        
    }


	public function order_list($order_Status='1'){

		$columns = array(
			0=> 'id',
			1=> 'vendor_name',
			2=> 'customer_name',
			3=> 'customer_phone',
			4=> 'account_type',
			5=> 'customer_status',
			6=> 'customer_email',
			7=> 'customer_address',
			8=> 'name',
			9=> 'quantity',
			10=> 'custom_value',
			11=> 'custom_description',
			12=> 'custom_image'
		);

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
        $totalData = $this->orders->table_items_count('cart');

        $totalFiltered = $totalData; 
        if(empty($this->input->post('search')['value'])){
        	$posts = $this->orders->all_items($limit,$start,$order,$dir, $order_Status);
        }else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->orders->item_search($limit,$start,$search,$order,$dir, $order_Status);

            // $totalFiltered = $this->orders->item_count_search($search,  'admins');
        }
        
  		$data = array();
		if(!empty($posts)){
			foreach ($posts as $post){
				$st="";
				if($post->customer_status==1)
				{
					$st="Active";
				}elseif($post->customer_status==2)
				{
					$st="Inactive";
				}
				elseif($post->customer_status==3)
				{
					$st="Blocked";
				}

				$nestedData['id'] = '';
				$nestedData['vendor_name'] = $post->vendor_name;
				$nestedData['customer_name'] = $post->customer_name;
				$nestedData['customer_phone'] = $post->customer_phone;
				$nestedData['account_type'] = $post->account_type=='1'?"Professional":"Personal";
				$nestedData['customer_status'] = $st;
				$nestedData['customer_email'] = $post->customer_email;
				$nestedData['customer_address'] = $post->customer_address;
				$nestedData['variation_name'] = $post->name;
				$nestedData['quantity'] = $post->quantity;
				$nestedData['custom_value'] = $post->custom_value==1?"Yes":"No";
				$nestedData['custom_description'] = $post->custom_description;
				$nestedData['custom_image'] = $post->custom_image!=""?"<img src=".URL."/custom_image/".$post->custom_image.">":'';

				$data[] = $nestedData;

			}
		}

		

		$json_data = array(
		"draw"            => intval($this->input->post('draw')),  
		"recordsTotal"    => intval($totalData),  
		"recordsFiltered" => intval($totalFiltered), 
		"data"            => $data   
		);

		echo json_encode($json_data); 
	}

	public function orders(){
		self::index();
	}

	public function refund(){
		$data['title'] = 'Order Management';
		$data['page'] = 'orders';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();
		$data['extra_datatable_data'] .= '
			<script type="text/javascript">
				$(document).ready(function (){
				    $("#orderlist").DataTable({
				        "processing": true,
				        "serverSide": true,
				        "ajax":{
				            "url": "'.base_url('order_management/order_list/6').'",
				            "dataType": "json",
				            "type": "POST",
				            "data":{
				              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
				            }
				        },
				        "columns": [
				          { "data": "id" },
				          { "data": "ordernumber" },
				          { "data": "vendor" },
				          { "data": "user" },
				          { "data": "quantity" },
				          { "data": "price" },
				          { "data": "payment" },
				          { "data": "status" },
				          { "data": "action" },
				        ]
				    });
				});

				function change_status(that){
					var number = $(that).attr("data-number");
					var status = $(that).val();
					$.ajax({
						url: "'.base_url('order_management/change_status').'",
						data: { 
							"number": number, 
							"status": status
						},
						cache: false,
						type: "POST",
						success: function(response) {
							console.log(response);
							$("#orderlist").DataTable().ajax.reload();
						},
						error: function(xhr) {
							console.log(xhr);
						}
					});
				}
			</script>';
		$this->load->view('template',$data);
	}

	public function replace(){
		$data['title'] = 'Order Management';
		$data['page'] = 'orders';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();
		$data['extra_datatable_data'] .= '
			<script type="text/javascript">
				$(document).ready(function (){
				    $("#orderlist").DataTable({
				        "processing": true,
				        "serverSide": true,
				        "ajax":{
				            "url": "'.base_url('order_management/order_list/7').'",
				            "dataType": "json",
				            "type": "POST",
				            "data":{
				              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
				            }
				        },
				        "columns": [
				          { "data": "id" },
				          { "data": "ordernumber" },
				          { "data": "vendor" },
				          { "data": "user" },
				          { "data": "quantity" },
				          { "data": "price" },
				          { "data": "payment" },
				          { "data": "status" },
				          { "data": "action" },
				        ]
				    });
				});

				function change_status(that){
					var number = $(that).attr("data-number");
					var status = $(that).val();
					$.ajax({
						url: "'.base_url('order_management/change_status').'",
						data: { 
							"number": number, 
							"status": status
						},
						cache: false,
						type: "POST",
						success: function(response) {
							console.log(response);
							$("#orderlist").DataTable().ajax.reload();
						},
						error: function(xhr) {
							console.log(xhr);
						}
					});
				}
			</script>';
		$this->load->view('template',$data);
	}

	public function change_status(){
		return $this->orders
				->change_status(
					$this->input->post('status'), 
					$this->input->post('number')
				);
	}

	public function view($value=null){
		if($value == null ){
			echo "please check your order id is not there";
			exit();
		}

		$data['title'] = 'Invoice';
		$data['page'] = 'invoice'; 
		$data['invoice'] = $this->orders->get_invoice($value);
		$this->load->view('template',$data);	

	}
}
