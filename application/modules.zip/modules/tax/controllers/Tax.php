<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * @author Bimlesh
 *
 */
class Tax extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('tax_model','tax');

	}
	public function tax_details(){
		$data['title'] = 'Tax';
        $data['list']=$this->tax->tax_result();
        //echo"<pre>";print_r($data['list']);die;
		$data['page'] = 'list';       
		$this->load->view('template',$data);
	}
    public function edit($id=""){
        $data['title'] = 'Edit Tax';
        $data['list']=$this->tax->tax_results($id);
      //echo"<pre>";print_r($data['list']);die;
        $data['page'] = 'edit';       
        $this->load->view('template',$data);
    }


	
    public function update(){
        $this->form_validation->set_rules('name','name','trim|required');
        $this->form_validation->set_rules('value','value','trim|required');
        $this->form_validation->set_rules('description','description','trim|required');
        $this->form_validation->set_rules('taxcode','taxcode','trim|required');
        $info = $this->input->post(NULL,true);
        //echo"<pre>";print_r($info);die;

        if($this->form_validation->run()) {
        $rs = $this->tax->do_update($info);
        if($rs) {
        $this->session->set_flashdata('success', 'tax has been updated successfully');
        redirect(site_url('tax/tax_details'));
        } 
        else {
        $this->session->set_flashdata('error', 'Some error occurred. Please try again.');
        }
        } 
        else {
        $this->session->set_flashdata('error',validation_errors());
        }
        redirect(site_url('tax/edit/'.$info['tax_id']));
    }

}