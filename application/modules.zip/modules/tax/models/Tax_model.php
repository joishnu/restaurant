<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * @author bimlesh
 *
 */
class Tax_model extends CI_Model {


    
    public function tax_result(){
        $this->db->select("*");
        $this->db->from("taxes");
        $return=$this->db->get()->result_array();
        return $return ;
    }
    public function tax_results($id=""){
        $this->db->select("*");
        $this->db->from("taxes");
        $return=$this->db->get()->row_array();
        return $return ;
    }
   	public function do_update($params) {
        try { 
            $this->db->trans_begin();
            $where = array(
                'id' => $params['tax_id']
            );
                $update_data = array(
                'name' => $params['name'],
                'description' => $params['description'],
                'value' => $params['value'],
                'taxcode' => $params['taxcode']
            );
            if(!$this->db->update('taxes', $update_data, $where)) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return TRUE;
            
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return FALSE;
        }
    }
}
