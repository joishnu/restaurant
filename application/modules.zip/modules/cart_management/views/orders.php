<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Cart Management <small>| Cart Product List</small></h3>
      </div>
    </div>
    <div class="title_right">
      <!-- <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search" style="text-align: right">
        <a href="#" class="btn btn-primary"> <i class="fa fa-plus"></i> Add new product</a>
      </div> -->
    </div>
  </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Cart Product List</h2>
              <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                <li><a class="close-link"><i class="fa fa-close"></i></a></li>
              </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <p class="text-muted font-13 m-b-30"><!-- If you want to write somting you can write here --></p>
            <table id="orderlist" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>#</th>
                  
                  <th>Customer Name</th>
                  <th>Customer Phone</th>
                  <th>Account Type</th>
                  <th>Customer Status</th>
                  <th>Customer Email</th>
                  <th>Product Name</th>
                  <th>Quantity</th>
                  <th>Custom Value</th>
                  <th>Custom Description</th>
                  <th>Custom Image</th>
                  <th>Vendor Name</th>
                </tr>
              </thead>
              <tbody>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

