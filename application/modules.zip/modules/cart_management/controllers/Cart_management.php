<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Cart_management extends CI_Controller {
	

	function __construct(){
		parent::__construct();
		$this->load->model('cart_model','orders');
		$this->load->library('external');
	}

	public function index(){
		$data['title'] = 'Cart Management';
		$data['page'] = 'orders';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();
		$data['extra_datatable_data'] .= '
			<script type="text/javascript">
				$(document).ready(function (){
				    $("#orderlist").DataTable({
				        "processing": true,
				        "serverSide": true,
				        "ajax":{
				            "url": "'.base_url('cart_management/order_list').'",
				            "dataType": "json",
				            "type": "POST",
				            "data":{
				              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
				            }
				        },
				        "columns": [
				          { "data": "id" },
				          { "data": "customer_name" },
				          { "data": "customer_phone" },
				          { "data": "account_type" },
				          { "data": "customer_status" },
				          { "data": "customer_email" },
				          { "data": "variation_name" },
				          { "data": "quantity" },
				          { "data": "custom_value" },
				          { "data": "custom_description" },
				          { "data": "custom_image" },
				          { "data": "vendor_name" }
				        ]
				    });
				});

			</script>';
		$this->load->view('template',$data);
	}

	
	public function order_list($order_Status='1'){

		$columns = array(
			0=> 'id',
			1=> 'customer_name',
			2=> 'customer_phone',
			3=> 'account_type',
			4=> 'customer_status',
			5=> 'customer_email',
			6=> 'name',
			7=> 'quantity',
			8=> 'custom_value',
			9=> 'custom_description',
			10=> 'custom_image',
			11=>'vendor_name'
		);

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
        $totalData = $this->orders->table_items_count('cart');

        $totalFiltered = $totalData; 
        if(empty($this->input->post('search')['value'])){
        	$posts = $this->orders->all_items($limit,$start,$order,$dir, $order_Status);
        }else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->orders->item_search($limit,$start,$search,$order,$dir, $order_Status);

            // $totalFiltered = $this->orders->item_count_search($search,  'admins');
        }
        
  		$data = array();
		if(!empty($posts)){
			foreach ($posts as $post){
				$st="";
				if($post->customer_status==1)
				{
					$st="Active";
				}elseif($post->customer_status==2)
				{
					$st="Inactive";
				}
				elseif($post->customer_status==3)
				{
					$st="Blocked";
				}

				$nestedData['id'] = '';
				$nestedData['customer_name'] = $post->customer_name;
				$nestedData['customer_phone'] = $post->customer_phone;
				$nestedData['account_type'] = $post->account_type=='1'?"Professional":"Personal";
				$nestedData['customer_status'] = $st;
				$nestedData['customer_email'] = $post->customer_email;
				$nestedData['variation_name'] = $post->name;
				$nestedData['quantity'] = $post->quantity;
				$nestedData['custom_value'] = $post->custom_value==1?"Yes":"No";
				$nestedData['custom_description'] = $post->custom_description;
				if($post->custom_image!="")
				{
					$multi_img=explode(",", $post->custom_image);
					$cnt_img=count($multi_img);
					$img_name="";
					if($cnt_img>=1)
					{	
						for($i=0;$i<=$cnt_img-1;$i++)
						{	
							$img_name.='<img src="'.URL.'/uploads/product_gallery/'.$multi_img[$i].'" width="25%" height="25%">';
						}
						$nestedData['custom_image']=$img_name;
					}
					else{
						$nestedData['custom_image'] = "No Image Found";	
					}
				}
				else
				{
					$nestedData['custom_image'] = "No Image Found";	
				}

				$nestedData['vendor_name'] = $post->vendor_name;
				
				$data[] = $nestedData;

			}
		}


		$json_data = array(
				"draw"            => intval($this->input->post('draw')),  
				"recordsTotal"    => intval($totalData),  
				"recordsFiltered" => intval($totalFiltered), 
				"data"            => $data   
			);

		echo json_encode($json_data); 
	}

	public function orders(){
		self::index();
	}
}