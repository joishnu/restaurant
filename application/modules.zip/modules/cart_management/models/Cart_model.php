<?php

class Cart_model extends CI_Model
{
    
    public function table_items_count($table){
        $query = $this->db->get($table);
        return $query->num_rows();
    }

    public function all_items($limit,$start,$col,$dir, $order_status = 1){

        $this->db->select('o.id,o.quantity,u.first_name, u.last_name, o.type as custom_value, o.custom_description, o.custom_image,v.vendor_name, concat(u.first_name, 
            " ", last_name) as customer_name, concat(u.country_code, " ", u.phone) as customer_phone, u.email as customer_email,u.account_type, u.status as customer_status,vr.name');
        $this->db->join('users as u', 'u.id = o.customer_id');  
        $this->db->join('variations as vr', 'vr.id = o.variation_id');
        $this->db->join('products as p', 'p.id = vr.product_id');
        $this->db->join('vendors as v', 'v.user_id = p.vendor_id',"left");
        //if($order_status != 1)

        $query = $this->db
                ->limit($limit,$start)
                //->order_by($col,$dir)
                ->get('cart as o');
        if($query->num_rows()>0)
            return $query->result(); 
         
        else
            return null;
        
    }

    public function item_search($limit,$start,$search,$col,$dir, $order_status = 1){
        $this->db->select('o.id,o.quantity,u.first_name, u.last_name, o.type as custom_value, o.custom_description, o.custom_image,v.vendor_name, concat(u.first_name, 
            " ", last_name) as customer_name, concat(u.country_code, " ", u.phone) as customer_phone, u.email as customer_email,u.account_type, u.status as customer_status,vr.name');
        $this->db->join('users as u', 'u.id = o.customer_id');  
        $this->db->join('variations as vr', 'vr.id = o.variation_id');
        $this->db->join('products as p', 'p.id = vr.product_id');
        $this->db->join('vendors as v', 'v.user_id = p.vendor_id',"left");
        $query = $this->db
            ->or_like('o.custom_description',$search)
            ->or_like('p.name',$search)
            ->or_like('v.vendor_name',$search)
            ->or_like('u.first_name',$search)
            ->or_like('u.last_name',$search)
            ->limit($limit,$start)->get('cart as o');
        if($query->num_rows()>0)
            return $query->result();  
        else
            return null;
    }
}