<style type="text/css">
   .stepContainer{
   height: 2rem !important;
   }
   .buttonFinish{
   display: none !important;
   }
</style>
<div class="right_col" role="main">
   <div class="">
      <div class="page-title">
         <div class="title_left">
            <h3>
               Delivery Executive Management <small>| Executive List</small><!-- <a href="javascript:void(0);" class="btn btn-success btn-block pull-right" role="button">Add Product</a> -->
            </h3>
         </div>
      </div>
      <div class="title_right">
         <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search" style="text-align: right">
            <a href="#" class="btn btn-primary pull-right" data-toggle="modal" data-target=".bs-example-modal-lg"> <i class="fa fa-plus"></i> Add Executive </a><br>
         </div>
      </div>
   </div>
   <div class="clearfix"></div>
   <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
         <div class="x_panel">
            <div class="x_title">
               <h2>Executive List<small>All Executives</small> </h2>
               <ul class="nav navbar-right panel_toolbox">
                  <!-- <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li> -->
                  <!-- <li><a class="close-link"><i class="fa fa-close"></i></a></li> -->
               </ul>
               <div class="clearfix"></div>
            </div>
            <div class="x_content">
               <div class="row">
                  <?php 
                     if ($this->session->flashdata('success')) { ?>
                  <div class="alert alert-success my_alert" role="alert">
                     <?php echo $this->session->flashdata('success'); ?>
                  </div>
                  <?php } if ($this->session->flashdata('fail')) { ?>
                  <div class="alert alert-danger my_alert" role="alert">
                     <?php echo $this->session->flashdata('fail'); ?>
                  </div>
                  <?php } ?>
               </div>
               <p class="text-muted font-13 m-b-30">
                  <!-- If you want to write somting you can write here -->
               </p>
               <table id="product" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                  <thead>
                     <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Email Id</th>
                        <th>Phone Number</th>
                        <th>Vehicle Number</th>
                        <th>Bank A/C Name</th>
                        <th>Bank Name</th>
                        <th>Account Number</th>
                        <th>IFSC Code</th>
                        <th>Company Name</th>
                        <th>Company Address</th>
                        <th>Company GST No.</th>
                        <th>Company PAN Card</th>
                        <th>Bank Branch Name</th>
                        <th>Created On</th>
                        <th>Orders</th>
                        <th>Status</th>
                        <th>Action</th>
                     </tr>
                  </thead>
                  <tbody>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
</div>
<!-- Add Variation modal -->
<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal">
            <span aria-hidden="true">×</span>
            </button>
            <h4 class="modal-title" id="myModalLabel">Add New Delivery Executive</h4>
         </div>
         <div class="modal-body">
            <div id="wizard" class="form_wizard wizard_horizontal">
               <ul class="wizard_steps">
                  <li>
                     <a href="#step-1">
                     <span class="step_no">1</span>
                     <span class="step_descr"> Step 1<br/><small>Basic Information</small></span>
                     </a>
                  </li>
                  <li>
                     <a href="#step-2">
                     <span class="step_no">2</span>
                     <span class="step_descr">Step 2<br /><small>Bank Information</small></span>
                     </a>
                  </li>
                  <li>
                     <a href="#step-3">
                     <span class="step_no">3</span>
                     <span class="step_descr">Step 3<br/><small>Company Information</small> </span>
                     </a>
                  </li>
               </ul>
               <form class="form-horizontal form-label-left"  action="<?php echo base_url('delivery/do_add_delivery');?>" method="post" enctype="multipart/form-data" data-toggle="validator">
                  <div id="step-1">
                     <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                           <input type="text"  placeholder="Executive Name" required="required" class="form-control col-md-7 col-xs-12" name="name">
                        </div>
                     </div>
                     <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Address <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                           <textarea name="address" required="required" class="form-control col-md-7 col-xs-12" placeholder="Address"></textarea>
                        </div>
                     </div>
                     <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Email Id <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                           <input type="email"  placeholder="Email Id" class="form-control col-md-7 col-xs-12" name="email_id" required="">
                        </div>
                     </div>
                     <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Country Code <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                           <select name="country_code" class="form-control" required="">
                              <?php $cnt=count($country_code);
                                 for ($i=0;$i<=$cnt-1;$i++){?>
                              <option value="<?php echo $country_code[$i]['id'];?>"><?php echo "( +".$country_code[$i]['phonecode']." ) - ". $country_code[$i]['name'] ;?></option>
                              <?php } ?>
                           </select>
                        </div>
                     </div>
                     <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Phone Number <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                           <input type="text"  placeholder="Phone Number" required="required" class="form-control col-md-7 col-xs-12" name="phone">
                        </div>
                     </div>
                     <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Vehicle Number<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                           <input type="text"  placeholder="Vehicle Number" required="required" class="form-control col-md-7 col-xs-12" name="vehicle_number">
                        </div>
                     </div>
                  </div>
                  <div id="step-2">
                     <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Bank Account Name<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                           <input type="text"  placeholder="Bank Account Name" class="form-control col-md-7 col-xs-12" name="bank_account_name" id="bank_account_name" required="">
                        </div>
                     </div>
                     <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Bank Name<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                           <input type="text"  placeholder="Bank Name" class="form-control col-md-7 col-xs-12" name="bank_name" id="bank_name" required="">
                        </div>
                     </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Bank Branch Name<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                           <input type="text"  placeholder="Branch Name" class="form-control col-md-7 col-xs-12" name="branch_name" id="branch_name" required="">
                        </div>
                     </div>
                     <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Bank Account Number<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                           <input type="text"  placeholder="Bank Account Number" class="form-control col-md-7 col-xs-12" name="bank_account_number" id="bank_account_number" required="">
                        </div>
                     </div>
                     <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">IFSC Code<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                           <input type="text"  placeholder="IFSC Code" class="form-control col-md-7 col-xs-12" name="ifsc_code" required="">
                        </div>
                     </div>
                  </div>
                  <div id="step-3">
                     <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Company Name
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                           <input type="text"  placeholder="Company Name" class="form-control col-md-7 col-xs-12" name="company_name" id="company_name">
                        </div>
                     </div>
                     <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Company Address
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                           <textarea name="company_address" class="form-control col-md-7 col-xs-12" placeholder="Company Address" id="company_address"></textarea>
                        </div>
                     </div>
                     <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Company GST No.
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                           <input type="text"  placeholder="Company GST No." class="form-control col-md-7 col-xs-12" name="gst_no" id="gst_no">
                        </div>
                     </div>
                     <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Company PAN Card
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                           <input type="text"  placeholder="Company PAN Card No." class="form-control col-md-7 col-xs-12" name="pan_card_no" id="pan_card_no">
                        </div>
                     </div>
                     <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">  </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                           <button type="submit" class="btn btn-primary">Save</button>
                           <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                           </label>
                        </div>
                     </div>
                  </div>
            </div>
            </form>
         </div>
      </div>
   </div>
</div>
</div>
<!-- Edit Variation modal -->
<div class="modal fade" tabindex="-1" role="dialog" aria-hidden="true" id="edit-item">
   <div class="modal-dialog modal-lg">
      <div class="modal-content">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
            </button>
            <h4 class="modal-title" id="myModalLabel">Edit Delivery Executive</h4>
         </div>
         <div class="modal-body">
         </div>
      </div>
   </div>
</div>

<script type="text/javascript">
    function order_list(that){
        var id = $(that).attr("data-number");
        var type = $(that).val();
        window.location.href = "<?php echo base_url('delivery/order_list/')?>"+id+'/'+type;

        /*$.ajax({
            url: "<?php echo base_url('delivery/order_list')?>",
            data: { 
                "id": id, 
                "type": type
            },
            cache: false,
            type: "POST",
            success: function(response) {
                console.log(response);
                $("#product").DataTable().ajax.reload();
            },
            error: function(xhr) {
                console.log(xhr);
            }
        });*/
    }
</script>