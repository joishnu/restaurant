<div class="right_col" role="main">
	<div class="">
		<div class="page-title">
			<div class="title_left">
				<h3>Order Management <small>| Orders List</small></h3>
			</div>
		</div>
		<div class="title_right">
			<!-- <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search" style="text-align: right">
				<a href="#" class="btn btn-primary"> <i class="fa fa-plus"></i> Add new product</a>
			</div> -->
		</div>
	</div>
	<div class="clearfix"></div>
	<div class="row">
		<div class="col-md-12 col-sm-12 col-xs-12">
			<div class="x_panel">
				<div class="x_title">
					<h2>Order List<small>All Order list</small></h2><br>
					<ul class="nav navbar-right panel_toolbox">
						<li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
						<li><a class="close-link"><i class="fa fa-close"></i></a></li>
					</ul>
					<div class="clearfix"></div>
				</div>
				<b>Executive Name  :<?php echo $executive['name'];?></b><br>
				<b>Executive Name  :<?php echo $executive['email_id'];?></b><br>
				<b>Executive Name  :<?php echo '+'.$executive['country_code'].'-'.$executive['phone'];?></b><hr>
				<a href="<?php echo base_url('delivery/order_list/').$executive['id'].'/1'?>"><b>Confirmed Order  :<?php echo $executive['confirmed_order'];?></b></a><br>
				<a href="<?php echo base_url('delivery/order_list/').$executive['id'].'/2'?>"><b>Cancelled Order :<?php echo $executive['cancelled_order'];?></b></a><br>
				<hr>
				<div class="x_content">
					<p class="text-muted font-13 m-b-30">
						<!-- If you want to write somting you can write here -->
					</p>
					<table id="orderlist" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
						<thead>
							<tr>
								<th>#</th>
								<th>Order Id</th>
								<th>Sub Order Id</th>
								<th>Transaction Id</th>
								<th>Vendor Name</th>
								<th>Store Address</th>
								<th>Customer Name</th>
								<th>Customer Phone</th>
								<th>Customer Email</th>
								<th>Customer Address</th>
								<th>Product Name</th>
								<th>Quantity</th>
								<th>Custom Value</th>
								<th>Custom Description</th>
								<th>Custom Image</th>
								<th>Order Status</th>
								<th>Total Amount</th>
								<th>Store Name</th>
							</tr>
						</thead>
						<tbody>
							<?php if($orders) foreach($orders as $key=>$value){?>
								<tr>
									<td>#</td>
									<td><?php echo $value['public_id'];?></td>
									<td><?php echo $value['sub_pub_id'];?></td>
									<td><?php echo $value['txnid'];?></td>
									<td><?php echo $value['vendor_name'];?></td>
									<td><?php echo $value['store_address'];?></td>
									<td><?php echo $value['first_name']." ".$value['last_name'];?></td>
									<td><?php echo $value['customer_phone'];?></td>
									<td><?php echo $value['customer_email'];?></td>
									<td><?php echo $value['customer_address'];?></td>
									<td><?php echo $value['name'];?></td>
									<td><?php echo $value['quantity'];?></td>
									<td><?php echo $value['custom_value']==1? "Yes":"No"?></td>
									<td><?php echo $value['custom_description'];?></td>
									<td><?php echo $value['custom_image'];?></td>
									<td><?php echo $value['order_status']==3? "Confirmed":"Cancelled"?></td>
									<td><?php echo $value['whole_total_price'];?></td>
									<td><?php echo $value['store_name'];?></td>
								</tr>
							<?php }?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
</div>
<script type="text/javascript">
$(document).ready(function (){
	$("#orderlist").DataTable({});
});
</script>