<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Delivery Executive Management <small>| Executive List</small><!-- <a href="javascript:void(0);" class="btn btn-success btn-block pull-right" role="button">Add Product</a> --></h3>
      </div>
    </div>
    
  </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Executive List<small>All Executives</small> </h2>
              <ul class="nav navbar-right panel_toolbox">
                <!-- <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li> -->
                <!-- <li><a class="close-link"><i class="fa fa-close"></i></a></li> -->
               
              </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
          <div class="row">
            <?php 
            if ($this->session->flashdata('success')) { ?>
              <div class="alert alert-success my_alert" role="alert">
                <?php echo $this->session->flashdata('success'); ?>
              </div>
            <?php } if ($this->session->flashdata('fail')) { ?>
              <div class="alert alert-danger my_alert" role="alert">
                <?php echo $this->session->flashdata('fail'); ?>
              </div>
            <?php } ?>
            </div>
            <p class="text-muted font-13 m-b-30"><!-- If you want to write somting you can write here --></p>
             <div class="modal-body">
                <div id="wizard" class="form_wizard wizard_horizontal">
              <ul class="wizard_steps">
                <li>
                  <a href="#step-1">
                    <span class="step_no">1</span>
                    <span class="step_descr"> Step 1<br/><small>Basic Information</small></span>
                  </a>
                </li>
                <li>
                  <a href="#step-2">
                    <span class="step_no">2</span>
                    <span class="step_descr">Step 2<br /><small>Bank Information</small></span>
                  </a>
                </li>
                <li>
                  <a href="#step-3">
                    <span class="step_no">3</span>
                    <span class="step_descr">Step 3<br/><small>Company Information</small> </span>
                  </a>
                </li>
              </ul>
              <form class="form-horizontal form-label-left"  action="<?php echo base_url('delivery/do_update_delivery');?>" method="post" enctype="multipart/form-data" data-toggle="validator">
                <div id="step-1">
                      <div class="form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Name <span class="required">*</span>
                          </label>
                          <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="text"  placeholder="Executive Name" required="required" class="form-control col-md-7 col-xs-12" name="name" value="<?php echo $info['name'];?>">
                            <input type="hidden" name="id" value="<?php echo $info['id'];?>">
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Address <span class="required">*</span>
                          </label>
                          <div class="col-md-6 col-sm-6 col-xs-12">
                            <textarea name="address" required="required" class="form-control col-md-7 col-xs-12" placeholder="Address"><?php echo $info['address'];?></textarea>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Email Id <span class="required">*</span>
                          </label>
                          <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="email"  placeholder="Email Id" class="form-control col-md-7 col-xs-12" name="email_id" value="<?php echo $info['email_id'];?>" required>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Country Code <span class="required">*</span>
                          </label>
                          <div class="col-md-6 col-sm-6 col-xs-12">
                            <select name="country_code" class="form-control" required="">
                              <?php $cnt=count($country_code);
                              for ($i=0;$i<=$cnt-1;$i++){?>
                                  <option value="<?php echo $country_code[$i]['id'];?>" <?php echo $info['country_code']==$country_code[$i]['id']?'selected':'';?>><?php echo "( +".$country_code[$i]['phonecode']." ) - ". $country_code[$i]['name'] ;?></option>
                              <?php } ?>
                            </select>
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Phone Number <span class="required">*</span>
                          </label>
                          <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="text"  placeholder="Phone Number" required="required" class="form-control col-md-7 col-xs-12" name="phone" value="<?php echo $info['phone'];?>">
                          </div>
                        </div>
                        <div class="form-group">
                          <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Vehicle Number<span class="required">*</span>
                          </label>
                          <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="text"  placeholder="Vehicle Number" required="required" class="form-control col-md-7 col-xs-12" name="vehicle_number" value="<?php echo $info['vehicle_number'];?>">
                          </div>
                        </div>
                </div>
                <div id="step-2">
                    <div class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Bank Account Name<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                      <input type="text"  placeholder="Bank Account Name" class="form-control col-md-7 col-xs-12" name="bank_account_name" id="bank_account_name" value="<?php echo $info['bank_account_name'];?>" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Bank Name<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                      <input type="text"  placeholder="Bank Name" class="form-control col-md-7 col-xs-12" name="bank_name" id="bank_name" value="<?php echo $info['bank_name'];?>" required>
                    </div>
                  </div>
                   <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Bank Branch Name<span class="required">*</span>
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                         <input type="text"  placeholder="Branch Name" class="form-control col-md-7 col-xs-12" name="branch_name" id="branch_name" value="<?php echo $info['branch_name'];?>" required>
                      </div>
                   </div>
                  <div class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Bank Account Number<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                      <input type="text"  placeholder="Bank Account Number" class="form-control col-md-7 col-xs-12" name="bank_account_number" id="bank_account_number" value="<?php echo $info['account_number'];?>" required>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">IFSC Code<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                      <input type="text"  placeholder="IFSC Code" class="form-control col-md-7 col-xs-12" name="ifsc_code" value="<?php echo $info['ifsc_code'];?>" required>
                    </div>
                  </div>
                </div>
                <div id="step-3">
                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Company Name
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <input type="text"  placeholder="Company Name" class="form-control col-md-7 col-xs-12" name="company_name" id="company_name" value="<?php echo $info['company_name'];?>">
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Company Address
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <textarea name="company_address" class="form-control col-md-7 col-xs-12" placeholder="Company Address" id="company_address"><?php echo $info['company_address'];?></textarea>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Company GST No.
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <input type="text"  placeholder="Company GST No." class="form-control col-md-7 col-xs-12" name="gst_no" id="gst_no" value="<?php echo $info['company_gst_no'];?>">
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Company PAN Card
                      </label>
                      <div class="col-md-6 col-sm-6 col-xs-12">
                        <input type="text"  placeholder="Company PAN Card No." class="form-control col-md-7 col-xs-12" name="pan_card_no" id="pan_card_no" value="<?php echo $info['company_pan_card'];?>">
                      </div>
                    </div>
                    <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">  </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <button type="submit" class="btn btn-primary">Save</button>
                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </label>
                        </div>
                    </div>
                  </div>
                </div>
              </form>
            </div>
            
          </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<style type="text/css">
  .stepContainer{
    height: 2rem !important;
  }
  .buttonFinish{
    display: none !important;
  }
</style>