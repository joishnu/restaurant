<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Model for Design Management
 */
class Delivery_model extends CI_Model
{
	
	// for datatable
    public function table_items_count($table){
        $query = $this->db->where('type<>','2')->where($table.'.status<>','3')->get($table);
        return $query->num_rows();
    }

    public function all_items($limit,$start,$col,$dir, $table, $select = '*'){
        $this->db->select($select);
        $query = $this->db
                ->limit($limit,$start)
                ->join('countries','countries.id='.$table.'.country_code','left')
                ->where($table.'.type<>','2')
                ->where($table.'.status<>','3')
                ->order_by('id','desc')
                ->get($table);
        if($query->num_rows()>0)
            return $query->result(); 
        else
            return null;
    }

    function item_search($limit,$start,$search,$col,$dir, $table, $select)
    {
        $this->db->select($select);
        $query = $this->db
            ->like($table.'.id',$search)
            ->or_like($table.'.name',$search)
            ->limit($limit,$start)->order_by($table.'.'.$col,$dir)->get($table);
        
        if($query->num_rows()>0)
            return $query->result();  
        else
            return null;
    }

   public function item_count_search($search, $table)
    {

        $query = $this->db
                ->like('id',$search)
                ->or_like('name',$search)
                ->get($table);
        return $query->num_rows();
    } 

    public function get_delivery_name($id)
    {
        return $this->db->select('*')->where('id', $id['number'])->get('delivery_executives')->row_array();

    }

    public function get_country_code()
    {
        return $this->db->select('*')->get('countries')->result_array();

    }

    public function do_delete($id)
    {
        try {
            $this->db->trans_begin();
            $this->db->set('status',"3");      
            $this->db->set('updated_on',date('Y-m-d H:i:s'));
            $this->db->where('id',$id);
            $this->db->update('delivery_executives');
            if(!$this->db->affected_rows()) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function do_add_delivery($params) {

        try {
            $this->db->trans_begin();
            $insert_data = array(
                'name'=> $params['name'],
                'address'=> $params['address'],
                'country_code'=> $params['country_code'],
                'phone'=> $params['phone'],
                'email_id'=> $params['email_id'],
                'bank_account_name'=> $params['bank_account_name'],
                'vehicle_number'=> $params['vehicle_number'],
                'bank_name'=> $params['bank_name'],
                'account_number'=> $params['bank_account_number'],
                'ifsc_code'=> $params['ifsc_code'],
                'company_name'=> $params['company_name'],
                'company_address'=> $params['company_address'],
                'company_gst_no'=> $params['gst_no'],
                'company_pan_card'=> $params['pan_card_no'],
                'branch_name'=> $params['branch_name'],
                'type'=> 1,
                'status'=> 1,
                'created_on'=>date('Y-m-d H:i:s')
            );

            if(!$this->db->insert('delivery_executives', $insert_data))
            {
                throw new Exception("Error Processing Request", 1);
            }
            
            $insert_id = $this->db->insert_id();

            $this->db->trans_commit();
            return $insert_id;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }
    
    public function do_update_delivery($params) {

        try {
            $this->db->trans_begin();
                $where= array('id' => $params['id'] );
                $update_data = array(
                            'name'=> $params['name'],
                            'address'=> $params['address'],
                            'country_code'=> $params['country_code'],
                            'phone'=> $params['phone'],
                            'email_id'=> $params['email_id'],
                            'bank_account_name'=> $params['bank_account_name'],
                            'vehicle_number'=> $params['vehicle_number'],
                            'bank_name'=> $params['bank_name'],
                            'account_number'=> $params['bank_account_number'],
                            'ifsc_code'=> $params['ifsc_code'],
                            'company_name'=> $params['company_name'],
                            'company_address'=> $params['company_address'],
                            'company_gst_no'=> $params['gst_no'],
                            'company_pan_card'=> $params['pan_card_no'],
                            'branch_name'=> $params['branch_name'],
                            'type'=> 1,
                            'status'=> 1,
                            'updated_on'=>date('Y-m-d H:i:s')
                );

                if(!$this->db->update('delivery_executives', $update_data, $where))
                {
                    throw new Exception("Error Processing Request", 1);
                }
                //print_r($this->db->last_query());exit();
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }


    public function change_status($params) {
        try {
            $this->db->trans_begin();
            $where= array('id' => $params['number'] );
            $update_data = array(
                'status' =>$params['status'],
                'updated_on'=>date('Y-m-d H:i:s')
            );

            if(!$this->db->update('delivery_executives', $update_data, $where))
            {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function get_order($data)
    {   
        $this->db->select('o.id,o.sub_pub_id, o.price as per_total_price, orders.total_price as whole_total_price,o.quantity as total_quanity,orders.tax as whole_total_tax, o.order_status, p.name, v.vendor_name, u.first_name, u.last_name, o.quantity, orders.public_id,o.custom_value, o.custom_description, o.custom_image, o.store_id, o.delivery_type, o.executive_id as delivery_executive_id, o.order_status, orders.address_id, orders.txn_id as transcation_id, orders.payment_status, concat(store_name,", ", store_address) as store_address,d.member_id, d.name as executive_name, d.address as executive_address, concat(d.country_code," ",d.phone) as executive_phone, d.email_id as executive_email, concat(u.first_name, 
            " ", last_name) as customer_name, concat(u.country_code, " ", u.phone) as customer_phone, u.email as customer_email,u.account_type, u.status as customer_status, concat(ad.address_line1,", ",ad.address_line2,", ", ad.address_line3,", ", pincode, ", ", ad.city,", ", ad.state, ", ",ad.country) as customer_address,s.store_name, s.store_address,transaction.txnid');
        $this->db->join('addresses as ad', 'ad.id = o.address_id',"left");  
        $this->db->join('stores as s', 's.id = o.address_id',"left");  
        $this->db->join('users as u', 'u.id = o.customer_id');  
        $this->db->join('variations as vr', 'vr.id = o.variation_id');
        $this->db->join('products as p', 'p.id = vr.product_id');
        $this->db->join('vendors as v', 'v.user_id = p.vendor_id',"left");
        $this->db->join('delivery_executives d','d.id=o.executive_id',"left");
        $this->db->join('orders','orders.id=o.order_id','left');
        $this->db->join('transaction','transaction.id=orders.txn_id','left');
        $this->db->where('orders.payment_status', '1');
        $this->db->where('o.executive_id', $data['id'] );    
        if($data['type']==1){
            $this->db->where('o.order_status', 3);
        }else{
            $this->db->where("o.order_status = 4 or o.order_status = 5");
        }
        $result = $this->db->get('order_details as o')->result_array();
        return $result;
    }

    public function get_executive_details($data)
    {
        $this->db->select('delivery_executives.*');
        $this->db->where('id', $data['id']);
        $this->db->where('status', 1);
        $result = $this->db->get('delivery_executives')->row_array();
        if($result){
            $this->db->select('COUNT(id) as confirmed_order');
            $this->db->where('executive_id', $data['id']);
            $this->db->where('order_status',3);
            $result['confirmed_order']=$this->db->get('order_details')->row('confirmed_order');

            $this->db->select('COUNT(id) as confirmed_order');
            $this->db->where('executive_id', $data['id']);
            $this->db->where("order_status = 4 or order_status = 5");
            $result['cancelled_order']=$this->db->get('order_details')->row('confirmed_order');
        }
        return $result;
    }

}


?>