<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Delivery extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('delivery_model','product');
		$this->load->library('external');
	}

	public function index(){
		$data['title'] = 'Delivery Management';
		$data['page'] = 'delivery';      
		$data['extra_datatable_data']= $this->external->wizard(); 
		$data['country_code'] = $this->product->get_country_code();       
		$data['extra_datatable_data'] .= $this->external->datatable_extra_js_css();     
		$data['extra_datatable_data'] .= $this->external->validation_extra_js_css();     
		$data['extra_datatable_data'] .= '<script type="text/javascript">
											$(document).ready(function (){
											    $("#product").DataTable({
											        "processing": true,
											        "serverSide": true,
											        "ajax":{
											            "url": "'.base_url('delivery/delivery_list').'",
											            "dataType": "json",
											            "type": "POST",
											            "data":{
											              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
											            }
											        },
											        "columns": [
											          { "data": "id" },
											          { "data": "name" },
											          { "data": "address" },
											          { "data": "phone" },
											          { "data": "email_id" },
											          { "data": "vehicle_number" },
											          { "data": "bank_account_name" },
											          { "data": "bank_name" },
											          { "data": "account_number" },
											          { "data": "ifsc_code" },
											          { "data": "company_name" },
											          { "data": "company_address" },
											          { "data": "company_gst_no" },
											          { "data": "company_pan_card" },
											          { "data": "branch_name" },
											          { "data": "created_on" },
											          { "data": "orders" },
											          { "data": "status" },
											          { "data": "action" },
											        ]
											    });
											});
											function edit_func(id){
												$.ajax({
													url: "'.base_url('delivery/delivery_name').'",
													data: { 
														"number": id, 
													},
													cache: false,
													type: "POST",
													success: function(response) {
													$("#id_design_hid").val(id);
														var vl=JSON.parse(response);

														$("#name").val(vl.name);
														$("#address").val(vl.address);
														$("#email_id").val(vl.email_id);
														$("#country_code").val(vl.country_code);
														$("#phone").val(vl.phone);
														$("#vehicle").val(vl.vehicle_number);
														$("#id").val(vl.id);
													},
													error: function(xhr) {
														console.log(xhr);
													}
												});
												$("#edit-item").modal("show");
												
											}

											function change_status(that){
												var number = $(that).attr("data-number");
												var status = $(that).val();
												$.ajax({
													url: "'.base_url('delivery/change_status').'",
													data: { 
														"number": number, 
														"status": status
													},
													cache: false,
													type: "POST",
													success: function(response) {
														console.log(response);
														$("#product").DataTable().ajax.reload();
													},
													error: function(xhr) {
														console.log(xhr);
													}
												});
											}

											
											</script>

											';
											//print_r($data['extra_datatable_data']);exit();
		$this->load->view('template',$data);
	}


	public function edit_delivery($id){
		$id=array('number'=>$id);
		$data['title'] = 'Delivery Management';
		$data['page'] = 'edit_delivery';      
		$data['extra_datatable_data']= $this->external->wizard(); 
		$data['country_code'] = $this->product->get_country_code();   
		$data['info'] = $this->product->get_delivery_name($id);
		
		$data['extra_datatable_data'] .= $this->external->datatable_extra_js_css();     
		$data['extra_datatable_data'] .= $this->external->validation_extra_js_css();     
		$this->load->view('template',$data);
	}

	public function delivery_name(){
		echo json_encode($this->product->get_delivery_name($this->input->post(NULL,true)));
	}

	// Product List ajax call for product list datatable
	public function delivery_list(){
		$columns = array(
			0 => "id",
			1 => "name",
			2 => "address",
			3 => "phone",
			4 => "email_id",
			5 => "vehicle_number",
			6 => "bank_account_name",
			7 => "bank_name",
			8 => "account_number",
			9 => "ifsc_code",
			10 => "company_name",
			11 => "company_address",
			12 => "company_gst_no",
			13 => "company_pan_card",
			14 => "branch_name",
			15 => "orders",
			16 => "status",
			17 => "created_on",
			18 => "action"
			
		);

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
        $totalData = $this->product->table_items_count('delivery_executives');

        $totalFiltered = $totalData; 
        if(empty($this->input->post('search')['value'])){
        	$posts = $this->product->all_items($limit,$start,$order,$dir, 'delivery_executives', "delivery_executives.status, delivery_executives.name, delivery_executives.id, delivery_executives.type, delivery_executives.email_id, delivery_executives.vehicle_number, delivery_executives.created_on, phonecode, phone, address,bank_account_name,bank_name,ifsc_code,company_name,company_address,company_gst_no,company_pan_card,account_number,delivery_executives.branch_name");
        }else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->product->item_search($limit,$start,$search,$order,$dir, 'delivery_executives', "delivery_executives.status, delivery_executives.name, delivery_executives.id, delivery_executives.type, delivery_executives.email_id, delivery_executives.vehicle_number, delivery_executives.created_on, phonecode, phone, address,bank_account_name,bank_name,ifsc_code,company_name,company_address,company_gst_no,company_pan_card,account_number,delivery_executives.branch_name");
            $totalFiltered = $this->product->item_count_search($search,  'delivery_executives');
        }
        
  		$data = array();
		if(!empty($posts)){
			$j=0;
			foreach ($posts as $post){
				$j++;
			
				$nestedData['id'] = $j;
				$nestedData['name'] = $post->name;
				$nestedData['address']=$post->address;
				$nestedData['phone']=$post->phonecode.' '.$post->phone;
				$nestedData['email_id']=$post->email_id;
				$nestedData['vehicle_number']=$post->vehicle_number;
				$nestedData['bank_account_name']=$post->bank_account_name;
				$nestedData['bank_name']=$post->bank_name;
				$nestedData['account_number']=$post->account_number;
				$nestedData['ifsc_code']=$post->ifsc_code;
				$nestedData['company_name']=$post->company_name;
				$nestedData['company_address']=$post->company_address;
				$nestedData['company_gst_no']=$post->company_gst_no;
				$nestedData['company_pan_card']=$post->company_pan_card;
				$nestedData['branch_name']=$post->branch_name;
				$nestedData['orders']='<select class="btn btn-primary" onchange="return order_list(this)" data-number="'.$post->id.'">
										<option value="">Select Order</option>
										<option value="1">Completed Order</option>
										<option value="2">Cancelled Order</option>
									</select>';
				$nestedData['status'] = '<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
					<option value="2" '.(($post->status == 2)? 'selected="selected"' :" ").' >Deactivate </option>
					<option value="1" '.(($post->status == 1)? 'selected="selected"' :" ").'>Activate</option>
				</select>';
				$nestedData['created_on'] = $post->created_on;
				$nestedData['action'] = '<a href="'.base_url('delivery/edit_delivery').'/'.$post->id.'" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit </a>
				<a href="'.base_url('/delivery/delete').'/'.$post->id.'"><button class="btn btn-danger"><i class="fa fa-remove" ></i> Delete</button></a><!--<a data-toggle="modal" data-target=".bs-example-modal-lg"><button class="btn btn-primary"><i class="fa fa-pencil"></i> View</button></a>-->
				';
					$data[] = $nestedData;
			}
		}

		$json_data = array(
		"draw"            => intval($this->input->post('draw')),  
		"recordsTotal"    => intval($totalData),  
		"recordsFiltered" => intval($totalFiltered), 
		"data"            => $data   
		);
		echo json_encode($json_data); 
	}


	public function delete($id = 0)
    {
        try {
            if(!$id) {
                throw new Exception('Choose a Delivery Executive', 1);
            }
            $rs = $this->product->do_delete($id);

            if(!$rs){
                throw new Exception("Error Processing Request", 1);   
            }

            $this->session->set_flashdata('success', 'Delivery Executive Info is deleted successfully');
            redirect(site_url('delivery'));

        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(site_url('delivery'));

        }
    }

	public function do_add_delivery() {
		  try {
            $this->form_validation->set_rules('name', 'Name', 'trim|required');
            $this->form_validation->set_rules('address', 'Address', 'trim|required');
            $this->form_validation->set_rules('country_code', 'Country Code', 'trim|required');
            $this->form_validation->set_rules('phone', 'Phone', 'trim|required');
            $this->form_validation->set_rules('vehicle_number', 'Vehicle Number', 'trim|required');
            $this->form_validation->set_rules('bank_account_name', 'bank_account_name', 'trim|required');
            $this->form_validation->set_rules('branch_name', 'Bank Branch Name', 'trim|required');
            $this->form_validation->set_rules('bank_name', 'bank_name', 'trim|required');
            $this->form_validation->set_rules('bank_account_number', 'bank_account_number', 'trim|required');
            $this->form_validation->set_rules('ifsc_code', 'ifsc_code', 'trim|required');
            
           	if(!$this->form_validation->run()){
                throw new Exception(validation_errors());
            }
            $info = $this->input->post(NULL, TRUE);

            $rs = $this->product->do_add_delivery($info);
            if(!$rs) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->session->set_flashdata('success', "New Delivery Executive is added successfully!");
            redirect(site_url('delivery'));
        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(site_url('delivery'));
        }
	}


	public function do_update_delivery() {
		  try {
            $this->form_validation->set_rules('name', 'Name', 'trim|required');
            $this->form_validation->set_rules('address', 'Address', 'trim|required');
            $this->form_validation->set_rules('country_code', 'Country Code', 'trim|required');
            $this->form_validation->set_rules('phone', 'Phone', 'trim|required');
            $this->form_validation->set_rules('vehicle_number', 'Vehicle Number', 'trim|required');
            $this->form_validation->set_rules('bank_account_name', 'bank_account_name', 'trim|required');
            $this->form_validation->set_rules('branch_name', 'Bank Branch Name', 'trim|required');
            $this->form_validation->set_rules('bank_name', 'bank_name', 'trim|required');
            $this->form_validation->set_rules('bank_account_number', 'bank_account_number', 'trim|required');
            $this->form_validation->set_rules('ifsc_code', 'ifsc_code', 'trim|required');
            
           	if(!$this->form_validation->run()){
                throw new Exception(validation_errors());
            }
            $info = $this->input->post(NULL, TRUE);

            $rs = $this->product->do_update_delivery($info);
            if(!$rs) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->session->set_flashdata('success', "New Delivery Executive is updated successfully!");
            redirect(site_url('delivery'));
        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(site_url('delivery'));
        }
	}


	public function change_status() {
		$this->form_validation->set_rules('number','number','trim|required');
	    $info = $this->input->post(NULL,true);
	    echo json_encode($this->product->change_status($info));
	}

	public function order_list($id,$type)
	{
		$data['title'] = 'Delivery Management';
		$post_data['id'] = $id;
		$post_data['type'] = $type;
		$data['extra_datatable_data']= $this->external->wizard(); 
		$data['extra_datatable_data'] .= $this->external->datatable_extra_js_css();     
		$data['extra_datatable_data'] .= $this->external->validation_extra_js_css();
		$data['orders'] = $this->product->get_order($post_data);
		$data['executive'] = $this->product->get_executive_details($post_data);
		$data['page'] = 'orders'; 
		$this->load->view('template',$data);
	}

}
