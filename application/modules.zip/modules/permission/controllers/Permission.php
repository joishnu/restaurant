<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
 * @author Bimlesh
 *
 */
class Permission extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('permission_model','permission');

	}
	public function add(){
		$data['title'] = 'Permission';
        $data['list']=$this->permission->role_result();
        $data['permission']=$this->permission->permission_result();
        $data['lists']=$this->permission->module_result();
       // echo"<pre>";print_r($data['list']);die;
		$data['page'] = 'add';       
		$this->load->view('template',$data);
	}
    public function edit($id=""){
        $data['title'] = 'Edit Permission';
        $data['role']=$this->permission->role_results($id);
        $data['list']=$this->permission->role_result();
        $data['lists']=$this->permission->module_result();
        $data['module']=$this->permission->module_results($id);
        //echo"<pre>";print_r($data['list']);die;
        $data['page'] = 'edit';       
        $this->load->view('template',$data);
    }
	public function add_permission(){
        $this->form_validation->set_rules('role_id','role_id','trim|required');
        $this->form_validation->set_rules('module_id','module_id','trim|required');
        $info = $this->input->post(NULL,true);

        if($this->form_validation->run()) {
        $rs = $this->permission->do_add_permission($info);
        if($rs) {
        $this->session->set_flashdata('success', 'Permission has been added successfully');
        redirect(site_url('permission/add'));
        } 
        else {
        $this->session->set_flashdata('error', 'Some error occurred. Please try again.');
        }
        } 
        else {
        $this->session->set_flashdata('error',validation_errors());
        }
        redirect(site_url('permission/add'));
    }
    
}