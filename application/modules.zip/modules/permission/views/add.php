<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
      </div>
    </div>
  </div>
    <div class="clearfix"></div>
    <!-- Add category form -->
  
    <!-- category list -->
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Permission List</h2>
              <ul class="nav navbar-right panel_toolbox">
                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#myModalHorizontal">
                Add Permission
                </button>            
                  </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <p class="text-muted font-13 m-b-30"><!-- If you want to write somting you can write here --></p>
            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Role Name</th>
                  <th>Module Name</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                  <?php 
                  $i=1;
                  foreach($permission as $key=>$value){ ?>
                <tr>
                 <td><?=$i;?></td>
                  <td><?php echo $value['role_id'];?></td>
                  <td><?php echo $value['module_id'];?></td>
                  <td><?php 
                    if ($value['status']==1) {
                    echo"Active";                 
                    }
                  ?>
                  </td>
                  <td><a href="<?=site_url('permission/edit/'.$value['id']);?>" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a></td>
                </tr>
                <?php $i++; } ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Button trigger modal -->

<!-- Modal -->
<div class="modal fade" id="myModalHorizontal" tabindex="-1" role="dialog" 
     aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <!-- Modal Header -->
            <div class="modal-header">
                <button type="button" class="close" 
                   data-dismiss="modal">
                       <span aria-hidden="true">&times;</span>
                       <span class="sr-only">Close</span>
                </button>
            </div>
            <!-- Modal Body -->
            <div class="modal-body">
              <form method="post" id="formProfile"  action="<?=site_url('permission/add_permission');?>" class="form-horizontal">
              <span class="section">Add Permission</span>
             <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Role Name <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select id="role_id" name="role_id" class="form-control col-md-7 col-xs-12" required="required">
                    <option value="">Please select role</option>
                    <?php
                     foreach ($list as $key => $value) {?>
                        <option  value="<?php echo $value['id']; ?>"><?php echo $value['name']; ?></option>
                     <?php }?>
                  </select>
                </div>
              </div>
                <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Module Name <span class="required">*</span></label>
                 <div class="col-md-6 col-sm-6 col-xs-12">
                  <select id="module_id" name="module_id" class="form-control col-md-7 col-xs-12" required="required">
                    <option value="">Please select module</option>
                    <?php
                     foreach ($lists as $key => $value) {?>
                        <option  value="<?php echo $value['id']; ?>"><?php echo $value['module_name']; ?></option>
                     <?php }?>
                  </select>
                </div>
              </div>
              <div class="ln_solid"></div>
              <div class="form-group">
                <div class="col-md-6 col-md-offset-3">
                   <button type="button" class="btn btn-primary"
                        data-dismiss="modal">
                            Cancel
                  <button id="send" type="submit" class="btn btn-success">Submit</button>
                </div>
              </div>
            </form>   
            </div>


