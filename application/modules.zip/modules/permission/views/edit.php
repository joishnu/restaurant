<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
      </div>
    </div>
  </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Edit Permission<small></small></h2>
            <ul class="nav navbar-right panel_toolbox">
              <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
              <li><a class="close-link"><i class="fa fa-close"></i></a></li>
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
        <form method="post" id="formProfile"  action="<?=site_url('permission/add_permission');?>" class="form-horizontal">
              <span class="section">Add Permission</span>
             <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Role Name <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select id="role_id" name="role_id" class="form-control col-md-7 col-xs-12" required="required">
                    <option value="">Please select role</option>
                    <?php
                     foreach ($list as $key => $value) {?>
                        <option  value="<?php echo $value['id']; ?>"<?=($value['id']==$role['id'])?'selected':'';?>><?php echo $value['name']; ?></option>
                     <?php }?>
                  </select>
                </div>
              </div>
                <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Module Name <span class="required">*</span></label>
                 <div class="col-md-6 col-sm-6 col-xs-12">
                  <select id="module_id" name="module_id" class="form-control col-md-7 col-xs-12" required="required">
                    <option value="">Please select module</option>
                    <?php
                     foreach ($lists as $key => $value) {?>
                        <option  value="<?php echo $value['id']; ?>" <?=($value['id']==$module['id'])?'selected':'';?>><?php echo $value['module_name']; ?></option>
                     <?php }?>
                  </select>
                </div>
              </div>
              <div class="ln_solid"></div>
              <div class="form-group">
                <div class="col-md-6 col-md-offset-3">
                   <button type="button" class="btn btn-primary"
                        data-dismiss="modal">
                            Cancel
                  <button id="send" type="submit" class="btn btn-success">Submit</button>
                </div>
              </div>
            </form>   
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

