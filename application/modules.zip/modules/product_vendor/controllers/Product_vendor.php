<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Product_vendor extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('product_model','product');
		$this->load->library('external');
	}

	public function index(){
		echo "404 not found";
	}

	public function add(){
		$data['title'] = 'Add Product';
		$data['page'] = 'addproduct'; 
		$data['category']=$this->product->get_category_list();
		$data['vendor']=$this->product->get_vendor_list();
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();             
		//$data['extra_datatable_data'] .= $this->validation_extra_js_css();       
		$data['extra_datatable_data'] .= $this->external->step_form_extra_js_css();  
		$data['extra_datatable_data'] .= $this->external->file_upld_js_css();  
		$data['extra_datatable_data'] .= $this->external->product_js();     
		$data['design']=$this->product->get_design_list();
		//$data['checklist']=$this->product->get_check_list();
		//$data['extra_datatable_data'] .= $this->step_form_extra_js_css();  
		$this->load->view('template',$data);
	}

	public function products(){
		$data['title'] = 'Products Management';
		$data['page'] = 'products';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();     
		$data['extra_datatable_data'] .= $this->external->validation_extra_js_css();    
		
		$data['extra_datatable_data'] .= '<script type="text/javascript">
											$(document).ready(function (){
											    $("#product").DataTable({
											        "processing": true,
											        "serverSide": true,
											        "ajax":{
											            "url": "'.base_url('product_vendor/product_list').'",
											            "dataType": "json",
											            "type": "POST",
											            "data":{
											              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
											            }
											        },
											        "columns": [
											          { "data": "id" },
											          { "data": "name" },
											          { "data": "cat_name" },
											          { "data": "sub_name" },
											          { "data": "description" },
											          { "data": "action" },
											        ]
											    });
											});

											function change_status(that){
												var number = $(that).attr("data-number");
												var status = $(that).val();
												$.ajax({
													url: "'.base_url('product_vendor/change_status').'",
													data: { 
														"number": number, 
														"status": status
													},
													cache: false,
													type: "POST",
													success: function(response) {
														console.log(response);
														$("#product").DataTable().ajax.reload();
													},
													error: function(xhr) {
														console.log(xhr);
													}
												});
											}
											</script>

											';
											//print_r($data['extra_datatable_data']);exit();
		$this->load->view('template',$data);
	}

	public function copy_varitaions($id)
	{
		if($this->product->copy_varitaions($id))
		{
			$this->session->set_flashdata('success', 'All product data copied successfully!');
		}
		else
		{
			$this->session->set_flashdata('failed', 'Failed to copy, Try agin please!');
		}
		
	    redirect(base_url('/product_vendor/products'));
	}

	public function copy_varitaion_specific($id)
	{	
		$id=explode('_', $id);
		if($rs=$this->product->copy_varitaion_specific($id[1]))
		{
			$this->session->set_flashdata('success', 'Variation data is copied successfully!');
		}
		else
		{
			$this->session->set_flashdata('failed', 'Failed to copy, Try agin please!');
		}
		
	    redirect(base_url('/product_vendor/product_info_updt/'.$id[0]));
	}
	
	//redirect(base_url('/product_vendor/product_info_updt/'.$info['id']));

	// Product List ajax call for product list datatable
	public function product_list(){
		$columns = array(
			0 => "id",
			1 => "name",
			2 => "cat_name",
			3 => "sub_name",
			4 => "description",
			5 => "action"
		);

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
        $totalData = $this->product->table_items_count('products');

        $totalFiltered = $totalData; 
        if($this->session->userdata['user_type']==1){

        if(empty($this->input->post('search')['value'])){
        	$posts = $this->product->all_items($limit,$start,$order,$dir, 'products', "products.status,products.id as id,subcategory_id, categories.name as cat_name, products.name, products.description");
        }else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->product->item_search($limit,$start,$search,$order,$dir, 'products', "products.status,products.id as id,subcategory_id, categories.name as cat_name, products.name, description");
            $totalFiltered = $this->product->item_count_search($search,  'products');
        }
    }
    else
    {
    	 if(empty($this->input->post('search')['value'])){
        	$posts = $this->product->all_items_vendor($limit,$start,$order,$dir, 'products', "products.status,products.id as id,subcategory_id, categories.name as cat_name, products.name, products.description");
        }else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->product->item_search_vendor($limit,$start,$search,$order,$dir, 'products', "products.status,products.id as id,subcategory_id, categories.name as cat_name, products.name, description");
            $totalFiltered = $this->product->item_count_search_vendor($search,  'products');
        }
    }
  		$category = $this->product->all_category_items();
  		//echo "<pre>";print_r($category);echo "<pre>";print_r($posts);exit();
  		$data = array();
		if(!empty($posts)){
			$cnt=count($category);
			$j=0;
			foreach ($posts as $post){
				$j++;
				
					$nestedData['id'] = $j;
					$nestedData['name'] = $post->name;
					$nestedData['cat_name'] = $post->cat_name;
					$nestedData['description'] = $post->description;
				for($i=0;$i<=$cnt-1;$i++)
				{
					
					if($category[$i]['id']==$post->subcategory_id)	
					{
						$nestedData['sub_name'] = $category[$i]['name'];	
					}
					else
					{
						$nestedData['sub_name'] = "-";
					}
				}

				/*$nestedData['action'] = '
				<a href="'.base_url('/product/product_info/'.$rs).'"><button class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</button></a><a href="'.base_url('/product/product_info/'.$rs).'"><button class="btn btn-primary"><i class="fa fa-pencil"></i> View</button></a>
				';*/


				$nestedData['action'] = '
				<a href="'.base_url('/product_vendor/product_info_updt').'/'.$post->id.'"><button class="btn btn-primary"><i class="fa fa-pencil" ></i> Edit</button></a><a href="'.base_url('/product_vendor/copy_varitaions').'/'.$post->id.'"><button class="btn btn-primary"><!--<i class="far fa-copy"></i>-->Copy</button></a><!--<a data-toggle="modal" data-target=".bs-example-modal-lg"><button class="btn btn-primary"><i class="fa fa-pencil"></i> View</button></a>-->
				';
					$data[] = $nestedData;
			}
		}

		$json_data = array(
		"draw"            => intval($this->input->post('draw')),  
		"recordsTotal"    => intval($totalData),  
		"recordsFiltered" => intval($totalFiltered), 
		"data"            => $data   
		);
		echo json_encode($json_data); 
	}

	
	/* As of now no need to add product by admin */
	/*
	public function add(){
		$data['title'] = 'Products Management';
		$data['page'] = 'addproduct';       
		$data['extra_datatable_data'] = $this->validation_extra_js_css();       
		$data['extra_datatable_data'] .= $this->step_form_extra_js_css();       
		$this->load->view('template',$data);
	}

	*/

	public function outproducts(){
		$data['title'] = 'Out of stock products';
		$data['page'] = 'outproducts';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();       
		$this->load->view('template',$data);
	}


		// Get Subcategory
	public function get_sub_category()
	{
		$id = $this->input->post(NULL,true);
		echo json_encode($this->product->get_sub_category($id['id']));
	}

	// Get variation specific item
	public function get_variation_info()
	{
		$id = $this->input->post(NULL,true);
		//echo "<pre>";print_r($this->product->get_variation_info($id['id']));exit();
		echo json_encode($this->product->get_variation_info($id['id']));
	}

	// Get attribute
	public function get_attribute()
	{
		$id = $this->input->post(NULL,true);
		echo json_encode($this->product->get_attribute($id['id']));
	}

	// To store product
	public function do_add_product() {
		$this->form_validation->set_rules('category','Category','trim|required');
		$this->form_validation->set_rules('subcategory','subcategory','trim|required');
		$this->form_validation->set_rules('product_desc','product description','trim|required');
		$this->form_validation->set_rules('product_name','Product Name','trim|required');
	    $info = $this->input->post(NULL,true);
	    if($this->form_validation->run()) {
	    	$rs = $this->product->do_add_product($info);
	    	if($rs) {
	    		
	 		   	$this->session->set_flashdata('success', 'Product has been added successfully!');
	    		//redirect("product/add_variations/".$rs);
	    		redirect(base_url('/product_vendor/product_info/'.$rs));
	    		// $this->add($rs);
	    	} else {
	    		$this->session->set_flashdata('error', 'Some error occurred. Please try again.');
	    	}
	    } else {
	        $validation_errors = validation_errors();
	      
	    	$this->session->set_flashdata('error',$validation_errors);
	    }
		redirect(base_url('/product_vendor/'));
	    }

	public function do_update_product() {
		$this->form_validation->set_rules('category','Category','trim|required');
		$this->form_validation->set_rules('subcategory','subcategory','trim|required');
		$this->form_validation->set_rules('product_desc','product description','trim|required');
		$this->form_validation->set_rules('product_name','Product Name','trim|required');
		$this->form_validation->set_rules('id','ID','trim|required');
	    $info = $this->input->post(NULL,true);

	    if($this->form_validation->run()) {
	    	$rs = $this->product->do_update_product($info);

	    	if($rs) {
	    		
	 		   	$this->session->set_flashdata('success', 'Product has been Updated successfully!');
	    		//redirect("product/add_variations/".$rs);
	    		redirect(base_url('/product_vendor/product_info_updt/'.$info['id']));
	    		// $this->add($rs);
	    	} else {
	    		$this->session->set_flashdata('error', 'Some error occurred. Please try again.');
	    	}
	    } else {
	        $validation_errors = validation_errors();
	      
	    	$this->session->set_flashdata('error',$validation_errors);
	    }
		redirect(base_url('/product_vendor/product_info_updt/'.$info['id']));
	    }

	public function product_info($id) {
		if($id){
			$data['title'] = 'Add Product';
			$data['page'] = 'addvartion'; 
			$data['category']=$this->product->get_category_list();
			//print_r($data['category']);exit();
			$data['design']=$this->product->get_design_list();
			$data['vendor']=$this->product->get_vendor_list();
			$cat_sub_category=$this->product->get_cat_sub_category($id);
			//$data['units']=$this->product->unit_list($cat_sub_category);
			$data['tags']=$this->product->product_tag_list($cat_sub_category);
			
			$data['selected_design']=$this->product->get_design_selected_list($id);
			//$data['selected_checklist']=$this->product->get_checklist_selected_list($id);

			//$data['checklist']=$this->product->get_check_list();
			$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();             
			//$data['extra_datatable_data'] .= $this->validation_extra_js_css();       
			$data['extra_datatable_data'] .= $this->external->step_form_extra_js_css();  
			$data['extra_datatable_data'] .= $this->external->file_upld_js_css();  
			//$data['extra_datatable_data'] .= $this->step_form_extra_js_css();  
			
			$data['product']=$this->product->get_add_product($id);


			if($data['product']['subcategory_id']!=='')
			{
				$data['subcat']=$this->product->get_add_product_category($data['product']['subcategory_id']);
				$data['attribute']=$this->product->get_add_product_atr($data['product']['subcategory_id']);
			}
			else
			{
				$data['attribute']=$this->product->get_add_product_atr($data['product']['category_id']);
				$data['subcat']="None";
			}

			$data['variations']=$this->product->get_variation_product_list($id);
			$data['product_id']=$id;
		
		}
		
		$this->load->view('template',$data);
	}

	public function product_info_updt($id) {
		if($id){
			$data['title'] = 'Edit Product';
			$data['page'] = 'update'; 
			$data['design']=$this->product->get_design_list();
			$data['vendor']=$this->product->get_vendor_list();
			$cat_sub_category=$this->product->get_cat_sub_category($id);
			//$data['units']=$this->product->unit_list($cat_sub_category);
			$data['tags']=$this->product->product_tag_list($cat_sub_category);
			//echo "<pre>";print_r($data['tags']);exit();
			$data['selected_design']=$this->product->get_design_selected_list($id);
			$data['category']=$this->product->get_category_list();
			//$data['selected_checklist']=$this->product->get_checklist_selected_list($id);
			//$data['checklist']=$this->product->get_check_list();
			$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();             
		//	$data['extra_datatable_data'] .= $this->validation_extra_js_css();       
			$data['extra_datatable_data'] .= $this->external->step_form_extra_js_css();  
			$data['extra_datatable_data'] .= $this->external->file_upld_js_css();  
			//$data['extra_datatable_data'] .= $this->step_form_extra_js_css();  
			$data['product']=$this->product->get_add_product($id);

			if($data['product']['subcategory_id']!=='')
			{
				$data['subcat']=$this->product->get_add_product_category($data['product']['subcategory_id']);
				$data['attribute']=$this->product->get_add_product_atr($data['product']['subcategory_id']);
			}
			else
			{
				$data['attribute']=$this->product->get_add_product_atr($data['product']['category_id']);
				$data['subcat']="None";
			}
			$data['variations']=$this->product->get_variation_product_list($id);
			$data['product_id']=$id;
			$data['category']=$this->product->get_category_list();
		}
		//echo "<pre>";print_r($data);exit();
		
		$this->load->view('template',$data);
	}


	public function do_upload_gallery($name,$video="") {
		$final='';
		if($video)
		{
			if(isset($_FILES[$name])){
	            
		            	if($_FILES[$name]['name'])
		            	{
		            		$_FILES[$name]['name']= $_FILES[$name]['name'];
			                $_FILES[$name]['type']= $_FILES[$name]['type'];
			                $_FILES[$name]['tmp_name']= $_FILES[$name]['tmp_name'];
			                $_FILES[$name]['error']= $_FILES[$name]['error'];
			                $_FILES[$name]['size']= $_FILES[$name]['size'];

			                //$config['upload_path']          = './uploads/product_gallery';
			                $config['upload_path'] = $_SERVER['DOCUMENT_ROOT'].'/'.PROJECT_NAME.'/admin/uploads/product_gallery';
			              	$config['allowed_types'] 		= '*';
			                $config['max_size']             = '*';
			                $config['max_width']            = '*';
			                $config['max_height']           = '*';
			                $config['file_name']            = date('ymdHis');
			                $images = array();
			                
			                $this->load->library('upload', $config);

			                if ( ! $this->upload->do_upload($name)){
			                    return array('error' => $this->upload->display_errors());
			                }else{
			                    $data = array('upload_data' => $this->upload->data());
			                    $arr[]=  $data['upload_data']['raw_name'].$data['upload_data']['file_ext'];
			                }
		            	}
	            if(isset($arr))
	            { $final=implode(',', $arr);}
	               
		        }
	        return $final;
		}
		else
		{
			if(isset($_FILES[$name])){
	            foreach ($_FILES[$name]['name'] as $key => $value) {
		            	if($_FILES[$name]['name'][$key])
		            	{
		            		$_FILES[$name.'[]']['name']= $_FILES[$name]['name'][$key];
			                $_FILES[$name.'[]']['type']= $_FILES[$name]['type'][$key];
			                $_FILES[$name.'[]']['tmp_name']= $_FILES[$name]['tmp_name'][$key];
			                $_FILES[$name.'[]']['error']= $_FILES[$name]['error'][$key];
			                $_FILES[$name.'[]']['size']= $_FILES[$name]['size'][$key];

			                $config['upload_path'] = $_SERVER['DOCUMENT_ROOT'].'/'.PROJECT_NAME.'/admin/uploads/product_gallery';
			                $config['allowed_types']        = '*';
			                $config['max_size']             = '*';
			                $config['max_width']            = '*';
			                $config['max_height']           = '*';
			                $config['file_name']            = date('ymdHis');
			                $images = array();
			                $this->load->library('upload', $config);

			                if ( ! $this->upload->do_upload('files[]')){
			                    $error = array('error' => $this->upload->display_errors());
			                    print_r($error);
			                    break;
			                }else{
			                    $data = array('upload_data' => $this->upload->data());
			                    $arr[]=  $data['upload_data']['raw_name'].$data['upload_data']['file_ext'];
			                }
		            	}
	            }
	            if(isset($arr))
	            { $final=implode(',', $arr);}
	               
		        }
	        return $final;
			}
	}

	public function do_add_variation() {
		$this->form_validation->set_rules('product_id','Product Id','trim|required');
		$this->form_validation->set_rules('sku','SKU','trim|required');
		/*$this->form_validation->set_rules('sku','SKU','trim|required');
		$this->form_validation->set_rules('batch_id','Batch Id','trim|required');
		$this->form_validation->set_rules('bar_code','Bar Code','trim|required');*/
		$this->form_validation->set_rules('quantity','Quantity','trim|required');
		$this->form_validation->set_rules('amount','Amount','trim|required');
		$this->form_validation->set_rules('man_date','Manufacture','trim|required');
		$this->form_validation->set_rules('tax','Tax','trim|required');
		//$this->form_validation->set_rules('exp_date','Expiry Date','trim|required');
		//$this->form_validation->set_rules('attribute','Attribute','trim|required');
		
	    $info = $this->input->post(NULL,true);
		  
	    if($this->form_validation->run()) {
	    	if($_FILES['files'])
				{
					$info['image']=$this->do_upload_gallery('files');	
				}
				
			/*	if($_FILES['video'])
				{
					$info['video']=$this->do_upload_gallery('video',1);	
				}*/
        
	    	$rs = $this->product->do_add_variation($info);

	    	if($rs) {
	    		
	 		   	$this->session->set_flashdata('success', 'Product Variations has been added successfully!');
	    		//redirect(site_url("product/add_variations/".$info['product_id']));
	    	} else {
	    		//$this->session->set_flashdata('error', 'Some error occurred. Please try again.');
	    	}
	    } else {
	        $validation_errors = validation_errors();
	      
	    	$this->session->set_flashdata('error',$validation_errors);
	    }

	    redirect(site_url("product_vendor/product_info/".$info['product_id']));
	}

	public function do_update_variation() {
		$this->form_validation->set_rules('product_id','Product Id','trim|required');
		$this->form_validation->set_rules('var_id_updt','Variation Id','trim|required');
		$this->form_validation->set_rules('sku','SKU','trim|required');
		/*$this->form_validation->set_rules('sku','SKU','trim|required');
		$this->form_validation->set_rules('batch_id','Batch Id','trim|required');
		$this->form_validation->set_rules('bar_code','Bar Code','trim|required');*/
		$this->form_validation->set_rules('amount','Amount','trim|required');
		$this->form_validation->set_rules('man_date','Manufacture','trim|required');
		//$this->form_validation->set_rules('exp_date','Expiry Date','trim|required');
		//$this->form_validation->set_rules('attribute','Attribute','trim|required');
	    $info = $this->input->post(NULL,true);
	    //echo "<pre>";print_r($info);exit();
	    if($this->form_validation->run()) {
	    	//echo "<pre>";print_r($info);exit();
	    	if($_FILES['files'])
				{
					$info['image']=$this->do_upload_gallery('files');	
				}
				/*if($_FILES['video'])
				{
					$info['video']=$this->do_upload_gallery('video',1);	
				}*/
	    	$rs = $this->product->do_update_variation($info);
	    	
	 		   	$this->session->set_flashdata('success', 'Product variation info has been Updated successfully!');
	    		redirect(site_url("product_vendor/product_info/".$info['product_id']));
	    } else {
	        $validation_errors = validation_errors();
	      
	    	$this->session->set_flashdata('error',$validation_errors);
	    }
	    redirect(site_url("product_vendor/product_info/".$info['product_id']));
	}

	public function change_status() {
		$this->form_validation->set_rules('id','id','trim|required');
	    $info = $this->input->post(NULL,true);
	    echo json_encode($this->product->change_status($info));
	}

	public function delete_image() {
		$this->form_validation->set_rules('img_name','Image Name','trim|required');
		$this->form_validation->set_rules('vari_id','Variations Id','trim|required');
	    $info = $this->input->post(NULL,true);
	    //print_r($info);exit();
	    echo json_encode($this->product->delete_image($info));
	}
	public function delete_video() {
		$this->form_validation->set_rules('video_name','Video Name','trim|required');
		$this->form_validation->set_rules('vari_id','Variations Id','trim|required');
	    $info = $this->input->post(NULL,true);
	    echo json_encode($this->product->delete_video($info));
	}

}
