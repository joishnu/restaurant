<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Model for Product Management
 */
class Product_model extends CI_Model
{
	
	// for datatable
	public function table_items_count($table){
		$query = $this->db->get($table);
		return $query->num_rows();
	}

	public function all_items($limit,$start,$col,$dir, $table, $select = '*'){
		$this->db->select($select);
        $this->db->join('categories', 'categories.id = '.$table.'.category_id','left');
        $query = $this->db
                ->limit($limit,$start)
                //->order_by($col,$dir)
                //->order('products.id','desc')
                ->get($table);


        if($query->num_rows()>0)
            return $query->result(); 
        else
            return null;
	}

	function item_search($limit,$start,$search,$col,$dir, $table, $select)
    {
    	$this->db->select($select);
		$this->db->join('categories', 'categories.id = '.$table.'.category_id','left');
        $query = $this->db
        	->like($table.'.id',$search)
        	->or_like($table.'.name',$search)
        	->limit($limit,$start)->order_by($table.'.'.$col,$dir)->get($table);
        
        if($query->num_rows()>0)
            return $query->result();  
        else
            return null;
    }


    public function all_items_vendor($limit,$start,$col,$dir, $table, $select = '*'){
        $this->db->select($select);
        $this->db->join('categories', 'categories.id = '.$table.'.category_id','left');
        $this->db->where('vendor_id',$this->session->userdata['id']);
        $query = $this->db
                ->limit($limit,$start)
                //->order_by($col,$dir)
                //->order('products.id','desc')
                ->get($table);


        if($query->num_rows()>0)
            return $query->result(); 
        else
            return null;
    }

    function item_search_vendor($limit,$start,$search,$col,$dir, $table, $select)
    {
        $this->db->select($select);
        $this->db->join('categories', 'categories.id = '.$table.'.category_id','left');
        $this->db->where('vendor_id',$this->session->userdata['id']);
        $query = $this->db
            ->like($table.'.id',$search)
            ->or_like($table.'.name',$search)
            ->limit($limit,$start)->order_by($table.'.'.$col,$dir)->get($table);
        
        if($query->num_rows()>0)
            return $query->result();  
        else
            return null;
    }

    public function item_count_search_vendor($search, $table)
    {

        $query = $this->db
                ->where('vendor_id',$this->session->userdata['id'])
                ->like('id',$search)
                ->or_like('name',$search)
                ->get($table);
        return $query->num_rows();
    } 

    public function all_category_items(){
        return $this->db->select('id, name')->where('parent_id is NOT NULL', NULL, TRUE)->get('categories')->result_array();
        
    }

    public function item_count_search($search, $table)
    {

        $query = $this->db
                ->like('id',$search)
        		->or_like('name',$search)
                ->get($table);
        return $query->num_rows();
    } 

    public function change_statuss($tablename, $status, $id_value, $id_field = 'id' ){
    	switch ($status) {
    		case 1:
    			$status_array = array('status'=>1);		
    			break;

    		case 2:
    			$status_array = array('status'=>2);		
    			break;

    		case 3:
    			$status_array = array('status'=>3);		
    			break;

    		case 4:
    			$status_array = array('status'=>4);		
    			break;
    		
    		default:
    			$status_array = array('status'=>0);		
    			break;
    	}
    	
    	$this->db->where($id_field, $id_value);
    	return $this->db->update($tablename, $status_array);
    }


    public function get_design_selected_list($params)
    {
        return $this->db->select('design_id')->where('product_id',$params)->get('design_product_relation')->result_array();
    }

   /* public function get_checklist_selected_list($params)
    {
        return $this->db->select('checklist_id')->where('product_id',$params)->get('checklist_product_relation')->result_array();
    }*/

    public function do_add_vendor_doc($params=[]){
        try {
            $this->db->trans_begin();
            $where = array(
                'id' => $this->session->userdata('vendor_id')
            );
            $update_data = array(
                 'business_id'=>$params['business_doc'],
                 'pancard'=>$params['pancard_doc'],
            );
            if(!$this->db->update('vendors', $update_data, $where)) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return 1;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function get_category_list()
    {
        return $this->db->select('id, name')->where('parent_id is NULL', NULL, TRUE)->get('categories')->result_array();
    }

    public function get_vendor_list()
    {
        return $this->db->select('*')->where('status', '1')->where('user_type', '2')->get('users')->result_array();
    }

    
    public function get_sub_category($id)
    {
        return $this->db->select('id, name')->where('parent_id', $id)->get('categories')->result_array();
    }

    public function get_attribute($id)
    {
        return $this->db->select('categories.id, attributes.id as att_id, name, attribute_name')->join('attributes','categories.id=attributes.sub_category_id')->where('categories.parent_id', $id)->get('categories')->result_array();
    }

    public function get_add_product_category($id)
    {
         return $this->db->select('name')->where('categories.id', $id)->get('categories')->row_array();
    }

    public function get_add_product_atr($id)
    {

        return $this->db->select('name as attribute_name, attributes.id as id')->join('attribute_relation_category', 'attribute_relation_category.attribute_id=attributes.id')->where('attribute_relation_category.subcategory_id', $id)->get('attributes')->result_array();
    }

    public function get_add_product($id)
    {
          return $this->db->select('category_id, service, subcategory_id, name, description, brand_name, manufacturer_name, vendor_id')->where('id', $id)->get('products')->row_array();
    }

    public function get_all_product()
    {
          return $this->db->select('products.status,products.id as id,subcategory_id, categories.name as cat_name, products.name, description')->join('categories','categories.id=products.category_id','left')->get('products')->result_array();
    }
    
    public function get_design_list()
    {
        return $this->db->select('*')->where('status', '1')->get('designs')->result_array();
    }

   /* public function get_check_list()
    {
        return $this->db->select('*')->where('status', '1')->get('checklist')->result_array();
    }*/

    public function get_variation_product_list($id)
    {
         return $this->db->select('id, product_id, name, sku, serial_no,barcode, amount, man_date, exp_date, batch_id, quantity')->where('product_id', $id)->where('status', 1)->get('variations')->result_array();
    }

    public function get_variation_info($id)
    {
        $all_info=$this->db->select('variations.tax,variations.id as var_id, product_id, sku, barcode, amount, variations.sku,variations.serial_no,  man_date, exp_date, batch_id, attributes.name as attribute_name, product_attribute.value, product_attribute.id as attr_id,product_attribute.attribute_id as orgin_attr_id,variations.image, variations.video, variations.name, variations.quantity, variations.custom_value, variations.offer_value as offer')->join('product_attribute','product_attribute.variation_id=variations.id','left')->join('attributes','product_attribute.attribute_id=attributes.id','left')->where('variations.id', $id)->where('variations.status',1)->get('variations')->result_array();
    
       $tag_info=$this->db->select('variation_id, product_tag_id')->where('variation_id', $id)->get('product_tag_relations')->result_array();

       $info_cnt = count($all_info);
       $tag_cnt = count($tag_info);
       //return $all_info;

       for($i=0;$i<=$info_cnt-1;$i++)
       {
            for($j=0;$j<=$tag_cnt-1;$j++)
            {
                if($all_info[$i]['var_id']==$tag_info[$j]['variation_id'])
                {   
                    if(isset($all_info[$i]['product_tags']))
                    {
                        $all_info[$i]['product_tags'].=','.$tag_info[$j]['product_tag_id'];
                    }
                    else
                    {
                        $all_info[$i]['product_tags']=$tag_info[$j]['product_tag_id'];   
                    }
                }
            }
        }

    // tag process
        $this->db->select('product_id');
        $this->db->where('id', $id);
        $product_id=$this->db->get('variations')->row_array();

        $this->db->select('category_id, subcategory_id');
        $this->db->where('id', $product_id['product_id']);
        $category=$this->db->get('products')->row_array();
        
        $this->db->select('a.name as name, a.id as id , a.description as description, a.status , a.created_on');
        $this->db->join('attribute_relation_category ar','ar.product_tags_id=a.id');
        $this->db->where('ar.category_id', $category['category_id']);
        $this->db->where('ar.subcategory_id', $category['subcategory_id']);
        $tags=$this->db->get('product_tags as a')->result_array();

        $tag_opt='';
    //    $unit_opt='';
        $cnt_tg=count($tags);
              

       $info_cnt = count($all_info);
       $tag_cnt = count($tag_info);

        for($i=0;$i<=$cnt_tg-1;$i++)
        {   
               $txt="" ;
            for($j=0;$j<=$tag_cnt-1;$j++)
            {
                
                if($tags[$i]['id']==$tag_info[$j]['product_tag_id'])
                {
                    $txt="selected";
                }
                $tags[$i]['option']='<option value="'.$tags[$i]['id'].'"'.$txt.'>'.$tags[$i]['name'].'</option>';
            }
                   

        }

        for($i=0;$i<=$cnt_tg-1;$i++)
        {
            $tag_opt.=$tags[$i]['option'];
        }

              
        $all_info[0]['product_tags_opt']=$tag_opt;
        // Units process
/*            $this->db->select('a.name as name, a.id as id , a.description as description, a.status , a.created_on');
            $this->db->join('attribute_relation_category ar','ar.product_units_id=a.id');
            $this->db->where('ar.category_id', $category['category_id']);
            $this->db->where('ar.subcategory_id', $category['subcategory_id']);
            $units=$this->db->get('units as a')->result_array();

            $cnt_tg=count($units);
            $optional='';
            
            for($i=0;$i<=$cnt_tg-1;$i++)
            { 
                $optional.='<option value="'.$units[$i]['id'].'">'.$units[$i]['name'].'</option>';
            }

        if($all_info[0]['custom_value']==1 && isset($all_info[0]['custom_value']))
        {   

           
            
            $unit_info=$this->db->select('variation_id, product_unit_id')->where('variation_id', $id)->get('product_unit_relations')->result_array();

          
            $unit_cnt = count($unit_info);
       

        for($i=0;$i<=$cnt_tg-1;$i++)
        {   $txt="";
            for($j=0;$j<=$unit_cnt-1;$j++)
            {
                
                if($units[$i]['id']==$unit_info[$j]['product_unit_id'])
                {
                    $txt="selected";
                }

                $units[$i]['option']='<option value="'.$units[$i]['id'].'"'.$txt.'>'.$units[$i]['name'].'</option>';
            }
                    
        }
        
        
        for($i=0;$i<=$cnt_tg-1;$i++)
        { 
            if(isset($units[$i]['option']))
            {
                $unit_opt.=$units[$i]['option'];    
            }
            
        }
        if(!$unit_opt)
        {
            $unit_opt=$optional;
        }
            $all_info[0]['product_unit_opt']=$unit_opt;
        
        }

        if($all_info[0]['custom_value']==2)
        {
             $all_info[0]['product_unit_opt']=$optional;
        }*/
       return $all_info;
     
    }
    
    public function do_add_variation($params) {
        //echo "<pre>";print_r($params);exit();
        try {
            $this->db->trans_begin();
            $insert_data = array(
                'product_id' => $params['product_id'],
                'sku' => $params['sku'],
                'serial_no' => $params['serial_no'],
               
              /*  'sku' => $params['sku'],
                'barcode' => $params['bar_code'],
                'batch_id' => $params['batch_id'],*/
                'name' => $params['name'],
                'quantity' => $params['quantity'],
                'amount' => $params['amount'],
                'offer_value' => $params['offer'],
                'man_date' => $params['man_date'],
                'exp_date' => $params['exp_date'],
                'image' => $params['image'],
                //'video' => $params['video'],
                'tax'=>$params['tax'],
                'custom_value'=>$params['custom_val'],
                'created_on'=>date('Y-m-d H:i:s'),
                'created_by'=>$this->session->userdata('id')
            );

            if(!$this->db->insert('variations', $insert_data))
            {
                throw new Exception("Error Processing Request", 1);
            }
            
            $insert_id = $this->db->insert_id();
            $cnt=count($params['attribute_id'])-1;
            for($i=0; $i<=$cnt;$i++)
            {
                $in_data[] = array(
                    'variation_id' => $insert_id,
                    'attribute_id' => $params['attribute_id'][$i],
                    'value' => $params['attribute'][$i]
                );
            }
            
            if(!$this->db->insert_batch('product_attribute', $in_data))
            {
                throw new Exception("Error Processing Request", 1);
            }

/*            if($params['custom_val']=='1')
            {
                $cnt=count($params['units'])-1;
                
                for($i=0; $i<=$cnt;$i++)
                {
                    $unit_data[] = array(
                        'variation_id' => $insert_id,
                        'product_unit_id' => $params['units'][$i],
                        'created_on'=>date('Y-m-d H:i:s')
                    );
                }

            
                if(!$this->db->insert_batch('product_unit_relations', $unit_data))
                {
                    throw new Exception("Error Processing Request", 1);
                }
            }*/

             $cnt=count($params['tags'])-1;
            for($i=0; $i<=$cnt;$i++)
            {
                $unit_dat[] = array(
                    'variation_id' => $insert_id,
                    'product_tag_id' => $params['tags'][$i],
                    'created_on'=>date('Y-m-d H:i:s')
                );
            }
            
            if(!$this->db->insert_batch('product_tag_relations', $unit_dat))
            {
                throw new Exception("Error Processing Request", 1);
            }

            $this->db->trans_commit();
            return $insert_id;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function do_update_variation($params) {
        try {

            $this->db->trans_begin();
            $ex_dt=$this->db->select('image, video')->where('id', $params['var_id_updt'])->get('variations')->row_array();

            $where= array('id' => $params['var_id_updt'] );

            $update_data = array(
                 'sku' => $params['sku'],
           /*     'sku' => $params['sku'],
                'barcode' => $params['bar_code'],
                'batch_id' => $params['batch_id'],*/
                
                'serial_no' => $params['serial_no'],
                'name' => $params['name'],
                'quantity' => $params['quantity'],
                'amount' => $params['amount'],
                'offer_value' => $params['offer'],
                'man_date' => $params['man_date'],
                'exp_date' => $params['exp_date'],
                //'video'=>$params['video'],
                'tax'=>$params['tax'],
                'custom_value'=>$params['custom_val_updt'],
                'updated_on'=>date('Y-m-d H:i:s'),
                'updated_by'=>$this->session->userdata('id')
            );

            if(isset($params['image'])&&$params['image']!='' )
            {
                $update_data ['image']=$params['image'].','.$ex_dt['image'];
            }

            if(!$this->db->update('variations', $update_data, $where))
            {
                throw new Exception("Error Processing Request", 1);
            }
             // $unit_relation=$this->db->select('id, product_unit_id')->where('variation_id', $params['var_id_updt'])->get('product_unit_relations')->result_array();
             
 /*           if($params['custom_val_updt']==2)
            {
                
                $cnt_unit=count($unit_relation);

                $units=array();
                if($cnt_unit>=1)
                {
                    for($i=0;$i<=$cnt_unit-1;$i++)
                    {
                        $units[$i]=$unit_relation[$i]['id'];
                    }
                    if(!$this->db->where_in('id', $units)->delete('product_unit_relations'))
                    {
                        throw new Exception("Error Processing Request", 1);
                    }
                }
            }else
                {
                 
                    if(isset($params['units']))
                    {

                        $cnt_unit=count($unit_relation);
                        $cnt_unit_param=count($params['units']);

                        $unit_updt='';
                        $unit_insert='';
                        
                        $unit_del=$this->db->select('id,product_unit_id')->where('variation_id',$params['var_id_updt'])->where_not_in('product_unit_id',$params['units'])->get('product_unit_relations')->result_array();
                    
                        
                        if($unit_del)
                        {

                            $cnt=count($unit_del);
                            for($i=0;$i<=$cnt-1;$i++)
                            {   
                                $units_del[]=$unit_del[$i]['id'];
                            }
                            
                            if(!$this->db->where_in('id', $units_del)->delete('product_unit_relations'))
                            {
                                throw new Exception("Error Processing Request", 1);
                            }    

                        }

                        $unit_exists=$this->db->select('product_unit_id as id')->where('variation_id',$params['var_id_updt'])->get('product_unit_relations')->result_array();
                       
                        $cnt=count($unit_exists);

                        if($unit_exists)
                        {
                            for($i=0;$i<=$cnt-1;$i++)
                            {
                                $unit_formated[$i]=$unit_exists[$i]['id'];
                            }
                        }
                        else
                        {
                            $unit_formated=array();
                        }

                        $a1=$unit_formated;
                        $a2=$params['units'];

                        $unit_insert=array_diff($a2,$a1);
     
                        if(count($unit_insert)>=1)
                        {   $cnt_units=count($unit_insert);
                            $unit_insert=array_values($unit_insert);
                            for($i=0;$i<=$cnt_units-1;$i++)
                            {   
                                $unit_formt_insert[]=array("product_unit_id" => $unit_insert[$i],
                                                           "variation_id" => $params['var_id_updt'],
                                                           "created_on" => date('Y-m-d H:i:s') );
                            }
                            //echo "<pre>";print_r($unit_formt_insert);exit();

                             if(!$this->db->insert_batch('product_unit_relations', $unit_formt_insert))
                            {
                                throw new Exception("Error Processing Request", 1);
                            }
                        }
                    }
                }*/


            $tag_relation=$this->db->select('id,product_tag_id')->where('variation_id',$params['var_id_updt'])->get('product_tag_relations')->result_array();

            if($tag_relation)
            {
                $cnt_tag=count($tag_relation);
                
                $tag_del=$this->db->select('id,product_tag_id')->where('variation_id',$params['var_id_updt'])->where_not_in('product_tag_id',$params['tags'])->get('product_tag_relations')->result_array();

                if($tag_del)
                {
                    $cnt=count($tag_del);
                    for($i=0;$i<=$cnt-1;$i++)
                    {   
                        $tags_del[]=$tag_del[$i]['id'];
                    }
                    if(!$this->db->where_in('id', $tags_del)->delete('product_tag_relations'))
                    {
                        throw new Exception("Error Processing Request", 1);
                    }    
                }
                    
                    $tag_exists=$this->db->select('product_tag_id as id')->where('variation_id',$params['var_id_updt'])->get('product_tag_relations')->result_array();
                    
                    $tag_exists_cnt=count($tag_exists);

                    for($i=0;$i<=$tag_exists_cnt-1;$i++)
                    {
                        $tag_formated[]=$tag_exists[$i]['id'];
                    }

                    $a1=$tag_formated;
                    $a2=$params['tags'];

                    $tag_insert=array_diff($a2,$a1);
   
                    if(count($tag_insert)>=1)
                    {   $cnt_tag=count($tag_insert);
                        $tag_insert=array_values($tag_insert);
                        for($i=0;$i<=$cnt_tag-1;$i++)
                        {   
                            $tag_formt_insert[]=array('product_tag_id' => $tag_insert[$i],
                                                       'variation_id' => $params['var_id_updt'],
                                                       'created_on' => date('Y-m-d H:i:s') );
                        }


                         if(!$this->db->insert_batch('product_tag_relations', $tag_formt_insert))
                        {
                            throw new Exception("Error Processing Request", 1);
                        }
                    }
              
                }


            $cnt=count($params['attribute_id'])-1;
            for($i=0; $i<=$cnt;$i++)
            {
                $in_data[] = array(
                    'value' => $params['attribute'][$i],
                    'id' => $params['attribute_id'][$i]
                );
            }
            
            $this->db->update_batch('product_attribute', $in_data,'id');

            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }


    public function change_status($params) {
        try {
            $this->db->trans_begin();
            $where= array('id' => $params['id'] );
            $update_data = array(
                'status' => 3,
                'updated_on'=>date('Y-m-d H:i:s'),
                'updated_by'=>$this->session->userdata('vendor_id'),
            );

            if(!$this->db->update('variations', $update_data, $where))
            {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function do_add_product($params) {
        try {
            $this->db->trans_begin();
            if(!isset($params['vendor']))
            {
                 $params['vendor']=$this->session->userdata['id'];
            }   
            $insert_data = array(
                'category_id' => $params['category'],
                'subcategory_id' => $params['subcategory'],
                'vendor_id' => $params['vendor'],
                'brand_name' => $params['brand_name'],
                'manufacturer_name' => $params['man_name'],
                'name' => $params['product_name'],
                'description' => $params['product_desc'],
                'service' => $params['service'],
                'created_on'=>date('Y-m-d H:i:s'),
                'created_by'=>$this->session->userdata('id')
            );

            if(!$this->db->insert('products', $insert_data))
            {
                throw new Exception("Error Processing Request", 1);
            }
      
            $insert_id=$this->db->insert_id();    

            /*$cnt=count($params['design']);

            for($i=0;$i<=$cnt-1;$i++)
            {
                $insert_design[]= array('product_id' => $insert_id, 'design_id' => $params['design'][$i],'created_on'=> date('Y-m-d H:i:s'));
            }

            if(!$this->db->insert_batch('design_product_relation', $insert_design))
            {
                throw new Exception("Error Processing Request", 1);
            }*/
       
          /*  $cnt=count($params['checklist']);

            for($i=0;$i<=$cnt=1;$i++)
            {
                $insert_checklist[]= array('product_id' => $insert_id, 'checklist_id' => $params['checklist'][$i],'created_on'=> date('Y-m-d H:i:s'));
            }
     
            if(!$this->db->insert_batch('design_product_relation', $insert_design))
            {
                throw new Exception("Error Processing Request", 1);
            }

            if(!$this->db->insert_batch('checklist_product_relation', $insert_checklist))
            {
                throw new Exception("Error Processing Request", 1);
            }*/
             
            $this->db->trans_commit();
            return $insert_id;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

   
    public function do_update_product($params) {

        try {
            $this->db->trans_begin();

            $update_data = array(
                'category_id' => $params['category'],
                'subcategory_id' => $params['subcategory'],
                'vendor_id' => $params['vendor'],
                'name' => $params['product_name'],
                'service' => $params['service'],
                'brand_name' => $params['brand_name'],
                'manufacturer_name' => $params['man_name'],
                'description' => $params['product_desc'],
                'updated_on'=>date('Y-m-d H:i:s'),
                'updated_by'=>$this->session->userdata('id'),
            );

            
           $where = array(
                'id' => $params['id']
            );

            if(!$this->db->update('products', $update_data, $where)) {
                throw new Exception("Error Processing Request", 1);
            }
             /*$cnt=count($params['design']);
            for($i=0;$i<=$cnt-1;$i++)
            {
                $result=$this->db->select('id,design_id')->where('design_id',$params['design'][$i])->where('product_id',$params['id'])->get('design_product_relation')->row_array();    
                if($result)
                {
                    $exists[]= array('id' => $result['id']);
                }
                else
                {
                    $not_exists[]= array('product_id' => $params['id'], 'design_id' => $params['design'][$i],'created_on'=> date('Y-m-d H:i:s'));
                }
            }

            if($not_exists)
            {

                if(!$this->db->insert_batch('design_product_relation', $not_exists))
                {
                    throw new Exception("Error Processing Request", 1);
                }
            }

            $result=$this->db->select('id')->where_not_in('design_id',$params['design'])->where('product_id',$params['id'])->get('design_product_relation')->result_array();    

            $cnt=count($result);
            for($i=0;$i<=$cnt-1;$i++)
            {
                $rs[]=$result[$i]['id'];
            }

            if($result)    
            {  
                if(!$this->db->where_in('id', $rs)->delete('design_product_relation'))
                {
                    throw new Exception("Error Processing Request", 1);
                }
            }
*/


           /* $cnt=count($params['checklist']);
            for($i=0;$i<=$cnt-1;$i++)
            {
                $result=$this->db->select('id,checklist_id')->where('checklist_id',$params['checklist'][$i])->where('product_id',$params['id'])->get('checklist_product_relation')->row_array();    
                if($result)
                {
                    $exists[]= array('id' => $result['id']);
                }
                else
                {
                    $not_exists[]= array('product_id' => $params['id'], 'checklist_id' => $params['checklist'][$i],'created_on'=> date('Y-m-d H:i:s'));
                }
            }

            if($not_exists)
            {

                if(!$this->db->insert_batch('checklist_product_relation', $not_exists))
                {
                    throw new Exception("Error Processing Request", 1);
                }
            }

            $result=$this->db->select('id')->where_not_in('checklist_id',$params['checklist'])->where('product_id',$params['id'])->get('checklist_product_relation')->result_array();    

            $cnt=count($result);
            for($i=0;$i<=$cnt-1;$i++)
            {
                $rs[]=$result[$i]['id'];
            }

            if($result)    
            {  
                if(!$this->db->where_in('id', $rs)->delete('checklist_product_relation'))
                {
                    throw new Exception("Error Processing Request", 1);
                }
            }
*/
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function do_modify_status($params) {
        try {
            $this->db->trans_begin();
            
            $update_data = array(
                "status" => $params['status']
            );
            
            $where = array(
                'id' => $params['id']
            );
            
            if(!$this->db->update('products', $update_data, $where)) {
                throw new Exception("Error Processing Request", 1);
            }
            
            $this->db->trans_commit();
            return 1;
            
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return 0;
        }
    }

    public function delete_image($params){
        try {
            $this->db->trans_begin();
           
            $ex_dt=$this->db->select('id, image, video')->where('id', $params['vari_id'])->get('variations')->row_array();
            $ex_dt=explode(",", $ex_dt['image']);
            //print_r($ex_dt);exit();
            $cnt=count($ex_dt)-1;
            //print_r(base_url('/uploads/product_gallery/'.$params['img_name']));exit();

            $final_img_info="";
            for($i=0;$i<=$cnt;$i++)
            {
                if($ex_dt[$i]!=$params['img_name'])
                {
                    $final_img_info[]=$ex_dt[$i];
                }
            }
            if($final_img_info){
                $final_img_info=implode(',', $final_img_info);
            }
            else
            {
                $final_img_info="";
            }
          
            $where = array(
                'id' => $params['vari_id']
            );

            $update_data = array(
                "image" => $final_img_info
            );

            if(!$this->db->update('variations', $update_data, $where)) {
                throw new Exception("Error Processing Request", 1);
            }
              if($final_img_info){

                    unlink(IMGS_RMV.'/uploads/product_gallery/'.$params['img_name']);
                }
            $this->db->trans_commit();
            return 1;
            
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return 0;
        }
    }

    public function delete_video($params){
        try {
            $this->db->trans_begin();
            
            $ex_dt=$this->db->select('id, image, video')->where('id', $params['vari_id'])->get('variations')->row_array();
            $ex_dt=explode(",", $ex_dt['video']);
            //print_r($ex_dt);exit();
            $cnt=count($ex_dt)-1;
            //print_r(base_url('/uploads/product_gallery/'.$params['img_name']));exit();
          
            $where = array(
                'id' => $params['vari_id']
            );

            $update_data = array(
                "video" => ''
            );

            if(!$this->db->update('variations', $update_data, $where)) {
                throw new Exception("Error Processing Request", 1);
            }
            if($params['video_name'])
            {
                unlink(IMGS_RMV.'/uploads/product_gallery/'.$params['video_name']);    
            }
            $this->db->trans_commit();
            return 1;
            
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return 0;
        }
    }

    public function unit_list($id){

            $this->db->select('a.name as name, a.id as id , a.description as description, a.status , a.created_on');
            $this->db->join('attribute_relation_category ar','ar.product_units_id=a.id');
            $this->db->where('ar.category_id', $id['category_id']);
            $this->db->where('ar.subcategory_id', $id['subcategory_id']);
        return $this->db->get('units as a')->result_array();
    }

    public function get_cat_sub_category($id){
        $this->db->select('category_id, subcategory_id');
        $this->db->where('id', $id);
        return $this->db->get('products')->row_array();
    }

    public function product_tag_list($id){
        $this->db->select('a.name as name, a.id as id , a.description as description, a.status , a.created_on');
       $this->db->join('attribute_relation_category ar','ar.product_tags_id=a.id');
       /* $this->db->join('attribute_relation_category ar','ar.subcategory_id=a.id');
        //$this->db->where('ar.product_tags_id', 'a.product_tags.id');
        $this->db->where('ar.category_id', $id['category_id']);
        $this->db->where('ar.subcategory_id', $id['subcategory_id']);
        $this->db->where('a.status','1');
        $this->db->group_by('a.id');*/
        $this->db->where('ar.category_id', $id['category_id']);
        $this->db->where('ar.subcategory_id', $id['subcategory_id']);
        return $this->db->get('product_tags as a')->result_array();
        
    }

    public function copy_varitaions($id)
    {
          //echo "<pre>";print_r($params);exit();
        try {
            $this->db->trans_begin();

            $product_query = $this->db->where('id',$id)->get('products')->row_array();

            $insert_data = array(
                'category_id' => $product_query['category_id'],
                'subcategory_id' => $product_query['subcategory_id'],
                'vendor_id' => $product_query['vendor_id'],
                'name' => $product_query['name'],
                'description' => $product_query['description'],
                'service' => $product_query['service'],
                'created_on'=>date('Y-m-d H:i:s'),
                'created_by'=>$this->session->userdata('id')
            );

            if(!$this->db->insert('products', $insert_data))
                {
                    throw new Exception("Error Processing Request", 1);
                }
          
            $insert_id=$this->db->insert_id();


       /*     $design_query = $this->db->where('product_id',$id)->get('design_product_relation')->result_array();


            $cnt=count($design_query);

            for($i=0;$i<=$cnt-1;$i++)
            {
                $insert_design[]= array('product_id' => $insert_id, 'design_id' => $design_query[$i]['design_id'],'created_on'=> date('Y-m-d H:i:s'));
            }

            if(!$this->db->insert_batch('design_product_relation', $insert_design))
            {
                throw new Exception("Error Processing Request", 1);
            }*/


            $query = $this->db->where('product_id',$id)->get('variations')->result_array();
            
            $cnt_query=count($query);

            $variation_id=[];

            for($i=0;$i<=$cnt_query-1;$i++)
            {
                $insert_data= array(
                    'product_id' => $insert_id,
                  /*  'sku' => $params['sku'],
                    'barcode' => $params['bar_code'],
                    'batch_id' => $params['batch_id'],*/
                    'name' => $query[$i]['name'],
                    'serial_no' => $query[$i]['serial_no'],
                    'quantity' => $query[$i]['quantity'],
                    'amount' => $query[$i]['amount'],
                    'offer_value' => $query[$i]['offer_value'],
                    'man_date' => $query[$i]['man_date'],
                    'exp_date' => $query[$i]['exp_date'],
                    'image' => $query[$i]['image'],
                    //'video' => $params['video'],
                    'tax'=>$query[$i]['tax'],
                    'custom_value'=>$query[$i]['custom_value'],
                    'created_on'=>date('Y-m-d H:i:s'),
                    'created_by'=>$this->session->userdata('id')
                );
                 if(!$this->db->insert('variations', $insert_data))
                    {
                        throw new Exception("Error Processing Request", 1);
                    }

                    $variation_id = $this->db->insert_id();

                // Attribute data into db

                 $attribute_query = $this->db->where('variation_id',$query[$i]['id'])->get('product_attribute')->result_array();

                  $cnt_att=count($attribute_query)-1;

                    for($k=0; $k<=$cnt_att;$k++)
                    {
                        $in_data[] = array(
                            'variation_id' => $variation_id,
                            'attribute_id' => $attribute_query[$k]['attribute_id'],
                            'value' => $attribute_query[$k]['value']
                        );
                    }
                    
                    if(!$this->db->insert_batch('product_attribute', $in_data))
                    {
                        throw new Exception("Error Processing Request", 1);
                    }

                // Tag data into db

                    $tag_query = $this->db->where('variation_id',$query[$i]['id'])->get('product_tag_relations')->result_array();

                    $cnt_tags=count($tag_query)-1;

                    for($n=0; $n<=$cnt_tags;$n++)
                    {
                        $tag_dat[] = array(
                            'variation_id' => $variation_id,
                            'product_tag_id' => $tag_query[$n]['product_tag_id'],
                            'created_on'=>date('Y-m-d H:i:s')
                        );
                    }
                    
                    if(!$this->db->insert_batch('product_tag_relations', $tag_dat))
                    {
                        throw new Exception("Error Processing Request", 1);
                    }

            }

            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }      

    public function copy_varitaion_specific($id)
    {
          //echo "<pre>";print_r($params);exit();
        try {
            $this->db->trans_begin();

            
            $query = $this->db->where('id',$id)->get('variations')->row_array();
            

            $variation_id=[];

            
                $insert_data= array(
                    'product_id' => $query['product_id'],
                  /*  'sku' => $params['sku'],
                    'barcode' => $params['bar_code'],
                    'batch_id' => $params['batch_id'],*/
                    'serial_no' => $query['serial_no'],
                    'name' => $query['name'],
                    'quantity' => $query['quantity'],
                    'amount' => $query['amount'],
                    'offer_value' => $query['offer_value'],
                    'man_date' => $query['man_date'],
                    'exp_date' => $query['exp_date'],
                    'image' => $query['image'],
                    //'video' => $params['video'],
                    'tax'=>$query['tax'],
                    'custom_value'=>$query['custom_value'],
                    'created_on'=>date('Y-m-d H:i:s'),
                    'created_by'=>$this->session->userdata('id')
                );
                 if(!$this->db->insert('variations', $insert_data))
                    {
                        throw new Exception("Error Processing Request", 1);
                    }

                    $variation_id = $this->db->insert_id();

                // Attribute data into db

                 $attribute_query = $this->db->where('variation_id',$query['id'])->get('product_attribute')->result_array();

                  $cnt_att=count($attribute_query)-1;

                    for($k=0; $k<=$cnt_att;$k++)
                    {
                        $in_data[] = array(
                            'variation_id' => $variation_id,
                            'attribute_id' => $attribute_query[$k]['attribute_id'],
                            'value' => $attribute_query[$k]['value']
                        );
                    }
                    
                    if(!$this->db->insert_batch('product_attribute', $in_data))
                    {
                        throw new Exception("Error Processing Request", 1);
                    }

                // Tag data into db

                    $tag_query = $this->db->where('variation_id',$query['id'])->get('product_tag_relations')->result_array();

                    $cnt_tags=count($tag_query)-1;

                    for($n=0; $n<=$cnt_tags;$n++)
                    {
                        $tag_dat[] = array(
                            'variation_id' => $variation_id,
                            'product_tag_id' => $tag_query[$n]['product_tag_id'],
                            'created_on'=>date('Y-m-d H:i:s')
                        );
                    }
                    
                    if(!$this->db->insert_batch('product_tag_relations', $tag_dat))
                    {
                        throw new Exception("Error Processing Request", 1);
                    }

            

            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }      

}

?>