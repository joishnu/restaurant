  <link href="<?php echo base_url('assets/others/jquery.filer-master/css/jquery.filer.css')?>" type="text/css" rel="stylesheet" />
  <link href="<?php echo base_url('assets/others/jquery.filer-master/css/themes/jquery.filer-dragdropbox-theme.css')?>" type="text/css" rel="stylesheet" />
  
  <script type="text/javascript" src="<?php echo base_url('assets/others/jquery.filer-master/js/jquery.filer.min.js')?>"></script>
 <link href="<?php echo base_url('assets/vendors/bootstrap-datepicker.css')?>" type="text/css" rel="stylesheet" />
  
  <script type="text/javascript" src="<?php echo base_url('assets/vendors/bootstrap-datepicker.js')?>"></script>

<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Product Management <small>| Edit Product</small></h3>
      </div>
    </div>
  </div>
   
    <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                 <?php if ($this->session->flashdata('success')) { ?>
                  <div class="alert alert-success alert-dismissible" role="alert">
                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <?php echo $this->session->flashdata('success'); ?>
                  </div>
                  <?php } ?>

                  <?php if ($this->session->flashdata('error')) { ?>
                  <div class="alert alert-danger alert-dismissible" role="alert">
                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <?php echo $this->session->flashdata('error'); ?>
                  <?php }?>
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Edit Product</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <form class="form-horizontal form-label-left"  action="<?php echo base_url('product_vendor/do_update_product');?>" method="post" data-toggle="validator" >
                      <div id="step-1">
                        <h2 class="StepTitle">Product Information</h2>
                        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Name <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <input type="text" value="<?php echo $product['name'];?>" required="required" class="form-control col-md-7 col-xs-12" name="product_name">
                                <input type="hidden" value="<?php echo $product_id;?>" required="required" class="form-control col-md-7 col-xs-12" name="id">
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="description">Description <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <textarea class="form-control col-md-7 col-xs-12" name="product_desc"><?php echo $product['description'];?></textarea>
                            </div>
                          </div>
                           <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Brand Name <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <input type="text" id="brand_name" required="required" class="form-control col-md-7 col-xs-12" name="brand_name" value="<?php echo $product['brand_name'];?>">
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Manufacturer Name <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <input type="text" id="man_name" required="required" class="form-control col-md-7 col-xs-12" name="man_name" value="<?php echo $product['manufacturer_name'];?>">
                            </div>
                          </div>
                          
                       <!--    <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Designs<span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <select name="design[]" class="form-control select2" multiple="" required="" id="design" style="width:100%;">
                                <?php $cnt=count($design);
                                  $sel=count($selected_design);
                                for ($i=0;$i<=$cnt-1;$i++){
                                  ?>
                                    <option value="<?php echo $design[$i]['id'];?>" <?php if(in_array($design[$i]['id'], array_column($selected_design, 'design_id'))){echo "selected";}?>><?php echo $design[$i]['name'];?></option>
                                <?php }?>
                              </select>
                            </div>
                          </div> -->
                         <!--  <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Prelisted Item<span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <select name="checklist[]" class="form-control select2" multiple="" required="" id="checklist" style="width:100%;">
                                <?php $cnt=count($checklist);
                                  $sel=count($selected_checklist);
                                for ($i=0;$i<=$cnt-1;$i++){
                                  ?>
                                    <option value="<?php echo $checklist[$i]['id'];?>" <?php if(in_array($checklist[$i]['id'], array_column($selected_checklist, 'checklist_id'))){echo "selected";}?>><?php echo $checklist[$i]['name'];?></option>
                                <?php }?>
                              </select>
                            </div>
                          </div> -->
                           <?php 
                        if($this->session->userdata['user_type']==1){?>
                          <div class="form-group">
                            <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Vendor Name <span class="required">*</span></label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <select id="vendor" class="form-control" required="" name="vendor">
                                  <?php $cnt=count($vendor);
                                        for($i=0;$i<=$cnt-1;$i++){
                                        ?>
                                        <option value="<?php echo $vendor[$i]['id'];?>" <?php echo $product['vendor_id']==$vendor[$i]['id']?'selected':'';?>><?php echo $vendor[$i]['first_name'].' '.$vendor[$i]['last_name'];?></option>
                                 <?php }?>
                              </select>
                            </div>
                          </div>
                          <?php }?>
                          <div class="form-group">
                            <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Category <span class="required">*</span></label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <select id="category" class="form-control" required="" name="category">
                                  <?php 

                                  $cnt=count($category);
                                        for($i=0;$i<=$cnt-1;$i++){
                                        ?>
                                        <option value="<?php echo $category[$i]['id'];?>" <?php echo $category[$i]['id']==$product['category_id']?'selected':'';?>><?php echo $category[$i]['name'];?></option>
                                 <?php }?>
                              </select>
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Subcategory <span class="required">*</span></label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                           
                             <select id="subcategory" class="form-control" required="" name="subcategory">
                              </select>
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Check Professional Service</label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="service"  class="form-control col-md-7 col-xs-12" name="service" value="<?php echo $product['service'];?>">
                            </div>
                          </div>
                         <div class="form-group">
                           <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <button class="btn btn-primary" type="button">Cancel</button>
                          <button type="submit" class="btn btn-success">Update</button>
                        </div>
                        </div>
                      </div>
                   
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <a href="#" class="btn btn-primary pull-right" data-toggle="modal" data-target=".bs-example-modal-lg"> <i class="fa fa-plus"></i> Add Variations</a><br>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <div class="x_panel">
                            <div class="x_title">
                              <h2>Product Variations</h2>
                              <div class="clearfix"></div>
                            </div>

                            <div class="x_content">
                              <div class="table-responsive">
                              <table class="table table-striped jambo_table bulk_action">
                                  <thead>
                                    <tr class="headings">
                                      <th class="column-title">S.No. </th>
                                 <!--      <th class="column-title">SKU </th>
                                      <th class="column-title">Batch Id </th>
                                      <th class="column-title">Bar Code </th> -->
                                      <th class="column-title">Name</th>
                                      <th class="column-title">Quantity </th>
                                      <th class="column-title">Amount</th>
                                      <th class="column-title">Manufacture Date </th>
                                      <th class="column-title">Exp. Date </th>
                                      <th class="column-title no-link last"><span class="nobr">Action</span>
                                      </th>
                                    </tr>
                                  </thead>

                                  <tbody>
                                   <?php $cnt=count($variations)-1; if($cnt>=0){for($i=0;$i<=$cnt;$i++){?>
                                    <tr class="even pointer">
                                      <td class=" "><?php echo $i+1;?></td>
                                    <!--   <td class=" "><?php echo $variations[$i]['sku'];?></td>
                                      <td class=" "><?php echo $variations[$i]['batch_id'];?></td> -->
                                      <td class=" "><?php echo $variations[$i]['name'];?></td>
                                      <td class=" "><?php echo $variations[$i]['quantity'];?></td>
                                      <td class=" "><?php echo $variations[$i]['amount'];?></td>
                                      <td class=" "><?php echo $variations[$i]['man_date'];?></td>
                                      <td class=" "><?php echo $variations[$i]['exp_date'];?></td>
                                      <td class=" last"><button type="button" class="btn btn-primary edit-item" data-edit="<?php echo $variations[$i]['id'];?>">Edit</button><a href="<?php echo base_url('/product_vendor/copy_varitaion_specific/'.$product_id.'_'.$variations[$i]['id']);?>" class="btn btn-primary copy-item">Copy</a>
                                         <button type="button" class="btn btn-danger remove-item" data-edit="<?php echo $variations[$i]['id'];?>">Delete</button>
                                      </td>
                                    </tr>
                                  <?php }}else{?>
                                      <tr class="even pointer">
                                          <td colspan="8"> <strong>No data available</strong></td>
                                      </tr>
                                  <?php }?>
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          </div>
                     </div>
                      
                      </div>
                     </form>
                  </div>
                </div>
              </div>
            </div>
  </div>
</div>
       <!-- Add Variation modal -->
    
      <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">

            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
              </button>
              <h4 class="modal-title" id="myModalLabel">Add Variations</h4>
            </div>
            <div class="modal-body">
              <form class="form-horizontal form-label-left"  action="<?php echo base_url('product_vendor/do_add_variation');?>" method="post" enctype="multipart/form-data" data-toggle="validator">
              <!-- <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">SKU <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text"  required="required" class="form-control col-md-7 col-xs-12" name="sku">
                  <input type="hidden" placeholder="" name="product_id"  value="<?php echo $product_id;?>" class="form-control">
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Batch ID <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" required="required" class="form-control col-md-7 col-xs-12" name="batch_id">
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Bar Code <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text"  required="required" class="form-control col-md-7 col-xs-12" name="bar_code">
                </div>
              </div> -->
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Name <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text"  required="required" class="form-control col-md-7 col-xs-12" name="name">
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Serial Number <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text"  required="required" class="form-control col-md-7 col-xs-12" name="serial_no">
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">SKU <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text"  required="required" class="form-control col-md-7 col-xs-12" name="sku">
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Quantity <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text"  required="required" class="form-control col-md-7 col-xs-12" name="quantity">
                  <input type="hidden" placeholder="" name="product_id"  value="<?php echo $product_id;?>" class="form-control">
                  <!-- <input type="hidden" placeholder="" name="var_id_updt" id="var_id_updt" class="form-control"> -->
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Enable Custom Value<span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select name="custom_val" class="form-control" required="" id="custom_val">
                      <option value="1">Yes</option>
                      <option value="2">No</option>
                  </select>
                </div>
              </div>
            <!--   <div class="form-group " id="units_cnt">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Units
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select name="units[]" class="form-control select2" multiple="" id="units" style="width:100%;">
                    <?php $cnt=count($units);
                    for ($i=0;$i<=$cnt-1;$i++){?>
                        <option value="<?php echo $units[$i]['id'];?>"><?php echo $units[$i]['name'];?></option>
                    <?php } ?>
                  </select>
                </div>
              </div> -->
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Tags
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select name="tags[]" class="form-control select2" multiple="" id="tags" style="width:100%;">
                    <?php $cnt=count($tags);
                    for ($i=0;$i<=$cnt-1;$i++){?>
                        <option value="<?php echo $tags[$i]['id'];?>"><?php echo $tags[$i]['name'];?></option>
                    <?php } ?>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Amount <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" required="required" class="form-control col-md-7 col-xs-12" name="amount">
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Offer Amount <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" class="form-control col-md-7 col-xs-12" name="offer">
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Tax <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" required="required" class="form-control col-md-7 col-xs-12" name="tax">
                </div>
              </div>
               <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Manufacture Date <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" required="required" class="datepicker form-control col-md-7 col-xs-12" name="man_date">
                </div>
              </div>
               <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Exp. Date <!-- <span class="required">*</span> -->
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" class="expiry form-control col-md-7 col-xs-12" name="exp_date">
                </div>
              </div>
              <div class="x_title">
                  <h2>Attributes</h2>
                  <div class="clearfix"></div>
              </div>
            <?php $cnt=count($attribute); for($i=0;$i<=$cnt-1;$i++){?>
              <div class="form-group">
               <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $attribute[$i]['attribute_name'];?> <span class="required">*</span>
                </label>
                 <div class="col-md-6 col-sm-6 col-xs-12">
                 <input type="text" required="required" class="form-control col-md-7 col-xs-12" name="attribute[]">
                 <input type="hidden" required="required" class="form-control col-md-7 col-xs-12" name="attribute_id[]" value="<?php echo $attribute[$i]['id'];?>">
              </div> 
              </div>
            <?php }?>
              <div class="x_title">
                  <h2>Product Gallery</h2>
                  <div class="clearfix"></div>
              </div>
              <div class="form-group">
               <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Images <span class="required">*</span>
                </label>
                 <a class="file_input col-md-3 col-sm-3 col-xs-12" data-jfiler-name="files" data-jfiler-extensions="jpg, jpeg, png"><i class="icon-jfi-paperclip"></i> Upload Images</a>
              </div>
              <!-- <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Video 
                </label>
                <input type="file" name="video" class="file_multi_video col-md-3 col-sm-3 col-xs-12" accept="video/*">
                 <video width="200" height="200" controls id="video_blk" class="video_blk">
                   <source src="mov_bbb.mp4" id="video_here" class="video_here">
                      Your browser does not support HTML5 video.
                  </video>
              </div> -->
             
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
             </form>
          </div>
        </div>
      </div>
       <!-- Edit Variation modal -->
    
      <div class="modal fade" tabindex="-1" role="dialog" aria-hidden="true" id="edit-item">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">

            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
              </button>
              <h4 class="modal-title" id="myModalLabel">Edit Variations</h4>
            </div>
            <div class="modal-body">
              <form class="form-horizontal form-label-left" action="<?php echo base_url('product_vendor/do_update_variation');?>" method="post" enctype="multipart/form-data" data-toggle="validator">
              <!-- <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">SKU <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" id="sku" required="required" class="form-control col-md-7 col-xs-12" name="sku">
                  <input type="hidden" placeholder="" name="product_id"  value="<?php echo $product_id;?>" class="form-control">
                  <input type="text" placeholder="" name="var_id_updt"  value="" id="var_id_updt" class="form-control">
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Batch ID <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" id="batch_id" required="required" id="batch_id" class="form-control col-md-7 col-xs-12" name="batch_id">
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Bar Code <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" id="bar_code" required="required" class="form-control col-md-7 col-xs-12" name="bar_code" id="bar_code">
                </div>
              </div> -->

              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Name <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text"  required="required" class="form-control col-md-7 col-xs-12" name="name" id="name">
                  <input type="hidden" placeholder="" name="product_id"  value="<?php echo $product_id;?>" class="form-control">
                  <input type="hidden" placeholder="" name="var_id_updt"  value="" id="var_id_updt" class="form-control">
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Serial Number <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text"  required="required" class="form-control col-md-7 col-xs-12" id="serial_no" name="serial_no">
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">SKU <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" id="sku" required="required" class="form-control col-md-7 col-xs-12" name="sku">
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Quantity <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text"  required="required" class="form-control col-md-7 col-xs-12" name="quantity" id="quantity">
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Enable Custom Value<span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select name="custom_val_updt" class="form-control" required="" id="custom_val_updt">
                      <option value="1">Yes</option>
                      <option value="2">No</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Tax <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" id="tax_updt" required="required" class="form-control col-md-7 col-xs-12" name="tax">
                </div>
              </div>
           <!--    <div class="form-group " id="units_cnt_updt">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Units
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select name="units[]" class="form-control select2" multiple="" id="units_updt" style="width:100%;">
                    <?php $cnt=count($units);
                    for ($i=0;$i<=$cnt-1;$i++){?>
                        <option value="<?php echo $units[$i]['id'];?>"><?php echo $units[$i]['name'];?></option>
                    <?php } ?>
                  </select>
                </div>
              </div> -->
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Tags
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <select name="tags[]" class="form-control select2" multiple="" id="tags_updt" style="width:100%;">
                    <?php $cnt=count($tags);
                    for ($i=0;$i<=$cnt-1;$i++){?>
                        <option value="<?php echo $tags[$i]['id'];?>"><?php echo $tags[$i]['name'];?></option>
                    <?php } ?>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Amount <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" id="amount" required="required" class="form-control col-md-7 col-xs-12" name="amount" id="amount">
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Offer Amount <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" class="form-control col-md-7 col-xs-12" name="offer" id="offer">
                </div>
              </div>
               <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Manufacture Date <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" name="man_date" id="man_date" required="required" class="datepicker form-control col-md-7 col-xs-12">
                </div>
              </div>
               <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Exp. Date <!-- <span class="required">*</span> -->
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input type="text" required="required"  id="exp_date" class="expiry form-control col-md-7 col-xs-12" name="exp_date" >
                </div>
              </div>
              <div class="x_title">
                  <h2>Attributes</h2>
                  <div class="clearfix"></div>
              </div>

            <?php $cnt=count($attribute); for($i=0;$i<=$cnt-1;$i++){?>
              <div class="form-group">
               <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><?php echo $attribute[$i]['attribute_name'];?> <span class="required">*</span>
                </label>
                 <div class="col-md-6 col-sm-6 col-xs-12">
                 <input type="text" required="required" class="form-control col-md-7 col-xs-12" placeholder="<?php echo "Enter the ".$attribute[$i]['attribute_name'] ?>" id="<?php echo "vl_".$attribute[$i]['id'];?>" name="attribute[]">
                 <input type="hidden" required="required" class="form-control col-md-7 col-xs-12" name="attribute_id[]" id="<?php echo "id_".$attribute[$i]['id'];?>" value="">
              </div> 
              </div>
            <?php }?>
              <div class="x_title">
                  <h2>Product Gallery</h2>
                  <div class="clearfix"></div>
              </div>
              <div class="form-group image_cnt">
              </div>
              <div class="form-group video_cnt">
              </div>
              <div class="form-group">
               <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Images <span class="required">*</span>
                </label>
                 <a class="file_input col-md-3 col-sm-3 col-xs-12" data-jfiler-name="files" data-jfiler-extensions="jpg, jpeg, png"><i class="icon-jfi-paperclip"></i> Upload Images</a>
              </div>
              <!-- <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Video
                </label>
                <input type="file" name="video" class="file_multi_video col-md-3 col-sm-3 col-xs-12" accept="video/*">
                 <video width="200" height="200" controls id="video_blk" class="video_blk">
                   <source src="mov_bbb.mp4" id="video_here" class="video_here">
                      Your browser does not support HTML5 video.
                  </video>
              </div> -->
             
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Update</button>
            </div>
             </form>
          </div>
        </div>
      </div>
      <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
      

<script type="text/javascript">
 $('.video_blk').hide();
  $(document).on("change", ".file_multi_video", function(evt) {
    $('.video_blk').show();
  var $source = $('.video_here');
  $source[0].src = URL.createObjectURL(this.files[0]);
  $source.parent()[0].load();
});
    $("#design").select2({
      placeholder: "Select Design",
      width: "resolve" 
       
      });
     /* $("#checklist").select2({
        placeholder: "Select Checklist",
        width: "resolve" 
       
      });*/
     /* $("#units").select2({
        placeholder: "Select Units",
        width: "resolve" 
     
    });*/
      $("#tags").select2({
        placeholder: "Select Tags",
        width: "resolve" 
     
    });
  // Image upload
    $('.file_input').filer({
            showThumbs: true,
            templates: {
                box: '<ul class="jFiler-item-list"></ul>',
                item: '<li class="jFiler-item">\
                            <div class="jFiler-item-container">\
                                <div class="jFiler-item-inner">\
                                    <div class="jFiler-item-thumb">\
                                        <div class="jFiler-item-status"></div>\
                                        <div class="jFiler-item-info">\
                                            <span class="jFiler-item-title"><b title="{{fi-name}}">{{fi-name | limitTo: 25}}</b></span>\
                                        </div>\
                                        {{fi-image}}\
                                    </div>\
                                    <div class="jFiler-item-assets jFiler-row">\
                                        <ul class="list-inline pull-left">\
                                            <li><span class="jFiler-item-others">{{fi-icon}} {{fi-size2}}</span></li>\
                                        </ul>\
                                        <ul class="list-inline pull-right">\
                                            <li><a class="icon-jfi-trash jFiler-item-trash-action"></a></li>\
                                        </ul>\
                                    </div>\
                                </div>\
                            </div>\
                        </li>',
                itemAppend: '<li class="jFiler-item">\
                            <div class="jFiler-item-container">\
                                <div class="jFiler-item-inner">\
                                    <div class="jFiler-item-thumb">\
                                        <div class="jFiler-item-status"></div>\
                                        <div class="jFiler-item-info">\
                                            <span class="jFiler-item-title"><b title="{{fi-name}}">{{fi-name | limitTo: 25}}</b></span>\
                                        </div>\
                                        {{fi-image}}\
                                    </div>\
                                    <div class="jFiler-item-assets jFiler-row">\
                                        <ul class="list-inline pull-left">\
                                            <span class="jFiler-item-others">{{fi-icon}} {{fi-size2}}</span>\
                                        </ul>\
                                        <ul class="list-inline pull-right">\
                                            <li><a class="icon-jfi-trash jFiler-item-trash-action"></a></li>\
                                        </ul>\
                                    </div>\
                                </div>\
                            </div>\
                        </li>',
                progressBar: '<div class="bar"></div>',
                itemAppendToEnd: true,
                removeConfirmation: true,
                _selectors: {
                    list: '.jFiler-item-list',
                    item: '.jFiler-item',
                    progressBar: '.bar',
                    remove: '.jFiler-item-trash-action',
                }
            },
            addMore: true,
           /* files: [{
                name: "appended_file.jpg",
                size: 5453,
                type: "image/jpg",
                file: "http://dummyimage.com/158x113/f9f9f9/191a1a.jpg",
            },{
                name: "appended_file_2.png",
                size: 9503,
                type: "image/png",
                file: "http://dummyimage.com/158x113/f9f9f9/191a1a.png",
            }]*/
      });

    $('.subcategory_blk').hide();
    var sub_cat='<?php echo $product['subcategory_id'];?>';
    
     $("#category").on('change',function(){
          var id=$(this).val();
         $.ajax({
            type:"POST",
            url:"<?php echo site_url();?>product_vendor/get_sub_category",
            data:{'id':id},
            dataType:'json',
       success: function(response)
       { 
        var ln=response.length;
        if(ln>=1)
        {
           var cnt;
            for(var i=0;i<=ln-1;i++)
            {
              cnt+='<option value="'+response[i]['id']+'" >'+response[i]['name']+'</option>';
            }

            $('.subcategory_blk').show();
            $('#subcategory').html('');
            $('#subcategory').html(cnt);
           
        }
        else
        {
          $('.subcategory_blk').hide();
        }

        }
      });
   });
    var id=$('#category').val();
     $.ajax({
            type:"POST",
            url:"<?php echo site_url();?>product_vendor/get_sub_category",
            data:{'id':id},
            dataType:'json',
       success: function(response)
       { 
        var ln=response.length;
        if(ln>=1)
        {
           var cnt;
            for(var i=0;i<=ln-1;i++)
            {
              if(sub_cat==response[i]['id']){
                cnt+='<option value="'+response[i]['id']+'" selected>'+response[i]['name']+'</option>';  
              }
              else
              {
                cnt+='<option value="'+response[i]['id']+'">'+response[i]['name']+'</option>';
              }
              
             
            }
            
            $('.subcategory_blk').show();
            $('#subcategory').html('');
            $('#subcategory').html(cnt);
           
        }
        else
        {
          $('.subcategory_blk').hide();
        }

        }
      });
      $('.edit-item').on('click', function(){
      var id=$(this).data('edit');
        $.ajax({
            type:"POST",
            url:"<?php echo site_url();?>product_vendor/get_variation_info",
            data:{'id':id},
            dataType:'json',
              success: function(response)
              { 
            var ln=response.length;
              //$('#sku').val(response[0]['sku']);
              $('#product_id').val(response[0]['product_id']);
              //$('#batch_id').val(response[0]['batch_id']);
              if(response[0]['custom_value'])
              {
                 $('#custom_val_updt').val(response[0]['custom_value']);
              }
              else
              {
                 $('#custom_val_updt').val(2);
              }

              $('#custom_val_updt').val(response[0]['custom_value']);
              $('#name').val(response[0]['name']);
              $('#sku').val(response[0]['sku']);
              $('#serial_no').val(response[0]['serial_no']);
              $('#quantity').val(response[0]['quantity']);
              $('#amount').val(response[0]['amount']);
              $('#tax_updt').val(response[0]['tax']);
              $('#bar_code').val(response[0]['barcode']);
              $('#man_date').val(response[0]['man_date']);
              $('#exp_date').val(response[0]['exp_date']);
              $('#var_id_updt').val(response[0]['var_id']);
              $('#offer').val(response[0]['offer']);
               var cnt;
               $('#edit-item').modal('show');
               $('#tags_updt').html('');
               //$('#units_updt').html('');
                
                for(var i=0;i<=ln-1;i++)
                {
                  $('#id_'+response[i]['orgin_attr_id']).val(response[i]['attr_id']); 
                  $('#vl_'+response[i]['orgin_attr_id']).val(response[i]['value']);
                }
                  $('#tags_updt').append(response[0]['product_tags_opt']);
                 // $('#units_updt').append(response[0]['product_unit_opt']);
                  
                var imgs=response[0]['image'].split(',');
                var cnt_img=imgs.length;
                var img='';
                var url_info="<?php echo IMGS_URL.'uploads/product_gallery/';?>";
                for(var i=0;i<=cnt_img-1;i++)
                {
                  if(i==0)
                  {
                    img='<img src="'+url_info+imgs[i]+'" class="img-thumbnail custm_img_size">';  
                  }
                  else
                  {
                   img+='<span><img src="'+url_info+imgs[i]+'" class="img-thumbnail custm_img_size"><i class="fa fa-trash ele_image" aria-hidden="true" style="font-size:30px;color:red" data-img="'+imgs[i]+'" ></i></span>';
                  }
                  
                }
                 $("#tags_updt").select2({
                        placeholder: "Select Tags",
                        width: "resolve" 
                     
                    });

                 /*$("#units_updt").select2({
                        placeholder: "Select Units",
                        width: "resolve" 
                     
                    });*/
                    
         /*           var vl=$('#custom_val_updt').val();
                      if(vl=='1'){
                        $('#units_cnt_updt').show();
                      }
                      else
                      {
                        $('#units_cnt_updt').hide(); 
                      } 
                    $('#custom_val_updt').on('change', function(){
                      var vl=$(this).val();
                      if(vl=='1'){
                        $('#units_cnt_updt').show();
                      }
                      else
                      {
                        $('#units_cnt_updt').hide(); 
                      }
                  });
                */

                $('.image_cnt').html(img);
             /*   $('.video_cnt').html('<video width="250" height="240" controls id="show_purpose">'+
                                     '<source src="'+url_info+response[0]['video']+'" type="video/mp4">'+
                                    'Your browser does not support the video tag.'+
                                    '</video><i class="fa fa-trash ele_video" aria-hidden="true" style="font-size:30px;color:red" data-video="'+response[0]['video']+'"></i>');*/
                $('.ele_image').on('click', function(){
                    if(confirm('Are you want to delete?'))
                    {
                      var id=$(this).data('img');
                      $.ajax({
                          type:"POST",
                          url:"<?php echo site_url();?>product_vendor/delete_image",
                          data:{'img_name':id,"vari_id":$('#var_id_updt').val()},
                          dataType:'text',
                     success: function(response)
                     { //console.log($(this));
                        //$(this).parent().parent().remove();
                        //$(this).parents().remove();
                        //console.log($(this).parents());
                      }
                    });
                    }
                  });

             /* $('.ele_video').on('click', function(){
                    if(confirm('Are you want to delete?'))
                    {
                      var id=$(this).data('video');
                      
                      $.ajax({
                          type:"POST",
                          url:"<?php echo site_url();?>product/delete_video",
                          data:{'video_name':id,"vari_id":$('#var_id_updt').val()},
                          dataType:'text',
                     success: function(response)
                     { 
                        $('.video_cnt').hide();
                      }
                    });
                    }
                    
                  });*/
        }
      });
    });

     $('.remove-item').on('click', function(){
      if(confirm('Are you want to delete?'))
      {
        var id=$(this).data('edit');
        $.ajax({
            type:"POST",
            url:"<?php echo site_url();?>product_vendor/change_status",
            data:{'id':id},
            dataType:'json',
       success: function(response)
       { 
          location.reload();
        }
      });
      }
      
    });


      $('.datepicker').datepicker({
        format: 'yyyy-mm-dd',
        endDate: '+0d',
        autoclose: true
    });
   /* $('#custom_val').on('change', function(){
        var vl=$(this).val();
        if(vl=='1'){
          $('#units_cnt').show();
        }
        else
        {
          $('#units_cnt').hide(); 
        }
    });*/
   $('.expiry').datepicker({
        format: 'yyyy-mm-dd',
        startDate: '+0d',
        autoclose: true
    });
     


</script>
 <style>
        .file_input{
            display: inline-block;
            padding: 10px 16px;
            outline: none;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
            white-space: nowrap;
            font-family: sans-serif;
            font-size: 11px;
            font-weight: bold;
            border-radius: 3px;
            color: #008BFF;
            border: 1px solid #008BFF;
            vertical-align: middle;
            background-color: #fff;
            margin-bottom: 10px;
            box-shadow: 0px 1px 5px rgba(0,0,0,0.05);
            -webkit-transition: all 0.2s;
            -moz-transition: all 0.2s;
            transition: all 0.2s;
        }
        .file_input:hover,
        .file_input:active {
            background: #008BFF;
            color: #fff;
        }
        .file_multi_video
        {
          display: inline-block;
            padding: 10px 16px;
            outline: none;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
            white-space: nowrap;
            font-family: sans-serif;
            font-size: 11px;
            font-weight: bold;
            border-radius: 3px;
            color: #008BFF;
            border: 1px solid #008BFF;
            vertical-align: middle;
            background-color: #fff;
            margin-bottom: 10px;
            box-shadow: 0px 1px 5px rgba(0,0,0,0.05);
            -webkit-transition: all 0.2s;
            -moz-transition: all 0.2s;
            transition: all 0.2s;
        }
        .file_multi_video:hover,
        .file_multi_video:active {
            background: #008BFF;
            color: #fff;
        }
        .custm_img_size
        {
          max-width: 26%;
        }
    </style>
