  <link href="<?php echo base_url('assets/others/jquery.filer-master/css/jquery.filer.css')?>" type="text/css" rel="stylesheet" />
  <link href="<?php echo base_url('assets/others/jquery.filer-master/css/themes/jquery.filer-dragdropbox-theme.css')?>" type="text/css" rel="stylesheet" />
  
  <script type="text/javascript" src="<?php echo base_url('assets/others/jquery.filer-master/js/jquery.filer.min.js')?>"></script>

<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Product Management <small>| Add New Product</small></h3>
      </div>
    </div>
  </div>
   
    <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                 <?php if ($this->session->flashdata('success')) { ?>
                  <div class="alert alert-success alert-dismissible" role="alert">
                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <?php echo $this->session->flashdata('success'); ?>
                  </div>
                  <?php } ?>

                  <?php if ($this->session->flashdata('error')) { ?>
                  <div class="alert alert-danger alert-dismissible" role="alert">
                  <button type="button" class="close" data-dismiss="alert"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                  <?php echo $this->session->flashdata('error'); ?>
                  <?php }?>
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Add Product</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <form class="form-horizontal form-label-left"  action="<?php echo base_url('product_vendor/do_add_product');?>" method="post" data-toggle="validator">
                      <div id="step-1">
                        <h2 class="StepTitle">Product Information</h2>
                          <?php if (!$this->session->flashdata('success')) { ?>
                          <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Name <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <input type="text" id="product_name" required="required" class="form-control col-md-7 col-xs-12" name="product_name">
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="description">Description <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <textarea name="product_desc" class="form-control col-md-7 col-xs-12" required=""></textarea>
                            </div>
                          </div>
                          <?php 
                        if($this->session->userdata['user_type']==1){?>
                          <div class="form-group">
                            <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Vendor Name <span class="required">*</span></label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <select id="vendor" class="form-control" required="" name="vendor">
                                  <?php $cnt=count($vendor);
                                        for($i=0;$i<=$cnt-1;$i++){
                                        ?>
                                        <option value="<?php echo $vendor[$i]['id'];?>"><?php echo $vendor[$i]['first_name'].' '.$vendor[$i]['last_name'];?></option>
                                 <?php }?>
                              </select>
                            </div>
                          </div>
                          <?php } ?>
                   <!--        <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Designs<span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <select name="design[]" class="form-control select2" multiple="" required="" id="design" style="width:100%;">
                                <?php $cnt=count($design);
                                for ($i=0;$i<=$cnt-1;$i++){?>
                                    <option value="<?php echo $design[$i]['id'];?>"><?php echo $design[$i]['name'];?></option>
                                <?php } ?>
                              </select>
                            </div>
                          </div> -->
                        <!--   <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Prelisted Item<span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <select name="checklist[]" class="form-control select2" multiple="" required="" id="pre_list" style="width:100%;">
                                <?php $cnt=count($checklist);
                                for ($i=0;$i<=$cnt-1;$i++){?>
                                    <option value="<?php echo $checklist[$i]['id'];?>"><?php echo $checklist[$i]['name'];?></option>
                                <?php } ?>
                              </select>
                            </div>
                          </div> -->
                          <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Brand Name <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <input type="text" id="brand_name" required="required" class="form-control col-md-7 col-xs-12" name="brand_name">
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Manufacturer Name <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <input type="text" id="man_name" required="required" class="form-control col-md-7 col-xs-12" name="man_name">
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Category <span class="required">*</span></label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <select id="category" class="form-control" required="" name="category">
                                  <?php $cnt=count($category);
                                        for($i=0;$i<=$cnt-1;$i++){
                                        ?>
                                        <option value="<?php echo $category[$i]['id'];?>"><?php echo $category[$i]['name'];?></option>
                                 <?php }?>
                              </select>
                            </div>
                          </div>
                          <div class="form-group subcategory_blk">
                            <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Subcategory <span class="required">*</span></label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <select id="subcategory" class="form-control" required="" name="subcategory">
                              </select>
                            </div>
                          </div>
                           <div class="form-group">
                            <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Check Professional Service </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                                <input type="text" id="service" class="form-control col-md-7 col-xs-12" name="service">
                            </div>
                          </div>
                         
                      </div>
                      <div class="ln_solid"></div>
                      <div class="form-group">
                          <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          <!-- <button class="btn btn-primary" type="button">Cancel</button> -->
                          <button type="submit" class="btn btn-success">Save</button>
                        </div>
                      <?php }else{?>
                          <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product Name <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <input type="text" value="<?php echo $product['name'];?>" required="required" class="form-control col-md-7 col-xs-12" disabled >
                            </div>
                          </div>
                          <div class="form-group">
                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="description">Description <span class="required">*</span>
                            </label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <textarea class="form-control col-md-7 col-xs-12" disabled><?php echo $product['description'];?></textarea>
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Category <span class="required">*</span></label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                              <input type="text" class="form-control col-md-7 col-xs-12" name="product_name" value="<?php echo $category['name'];?>" disabled>
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Subcategory <span class="required">*</span></label>
                            <div class="col-md-6 col-sm-6 col-xs-12">
                             <input type="text"  class="form-control col-md-7 col-xs-12" value="<?php echo $subcat['name'];?>" disabled>
                            </div>
                          </div>
                        <a href="#" class="btn btn-primary pull-right" data-toggle="modal" data-target=".bs-example-modal-lg"> <i class="fa fa-plus"></i> Add Variations</a>

                        <div class="col-md-12 col-sm-12 col-xs-12">
                          <div class="x_panel">
                            <div class="x_title">
                              <h2>Product Variations</h2>
                              <div class="clearfix"></div>
                            </div>

                            <div class="x_content">
                                <div class="table-responsive">
                                <table class="table table-striped jambo_table bulk_action">
                                  <thead>
                                    <tr class="headings">
                                      <th class="column-title">S.No. </th>
                                      <th class="column-title">SKU </th>
                                      <th class="column-title">Batch Id </th>
                                      <th class="column-title">Bar Code </th>
                                      <th class="column-title">Amount</th>
                                      <th class="column-title">Manufacture Date </th>
                                      <th class="column-title">Exp. Date </th>
                                      <th class="column-title no-link last"><span class="nobr">Action</span>
                                      </th>
                                    </tr>
                                  </thead>

                                  <tbody>
                                   <?php $cnt=count($variations)-1; if($cnt>=0){for($i=0;$i<=$cnt;$i++){?>
                                    <tr class="even pointer">
                                      <td class=" "><?php echo $i+1;?></td>
                                      <td class=" "><?php echo $variations[$i]['sku'];?></td>
                                      <td class=" "><?php echo $variations[$i]['batch_id'];?></td>
                                      <td class=" "><?php echo $variations[$i]['barcode'];?></td>
                                      <td class=" "><?php echo $variations[$i]['amount'];?></td>
                                      <td class=" "><?php echo $variations[$i]['man_date'];?></td>
                                      <td class=" "><?php echo $variations[$i]['exp_date'];?></td>
                                      <td class=" last"><button class="btn btn-primary edit-item" data-edit="<?php echo $variations[$i]['id'];?>">Edit</button>
                                         <button class="btn btn-danger remove-item" data-edit="<?php echo $variations[$i]['id'];?>">Delete</button>
                                      </td>
                                    </tr>
                                  <?php }}else{?>
                                      <tr class="even pointer">
                                          <td colspan="8"> <strong>No data available</strong></td>
                                      </tr>
                                  <?php }?>
                                  </tbody>
                                </table>
                              </div>
                            </div>
                          </div>
                     </div>
                      <?php }?>
                      </div>
                     </form>
                  </div>
                </div>
              </div>
            </div>
  </div>
</div>
      
       <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
      
<script type="text/javascript">
var id=$('#category').val();
   
     $.ajax({
            type:"POST",
            url:"<?php echo site_url();?>product_vendor/get_sub_category",
            data:{'id':id},
            dataType:'json',
       success: function(response)
       { 
        var ln=response.length;
        if(ln>=1)
        {
           var cnt;
            for(var i=0;i<=ln-1;i++)
            {
              cnt+='<option value="'+response[i]['id']+'">'+response[i]['name']+'</option>';
             
            } 

            $('.subcategory_blk').show();
            $('#subcategory').html('');
            $('#subcategory').html(cnt);
           
        }
        else
        {
          $('.subcategory_blk').hide();
        }

        }
      });
 /*$('#video_blk').hide();
  $(document).on("change", ".file_multi_video", function(evt) {
    $('#video_blk').show();
  var $source = $('#video_here');
  $source[0].src = URL.createObjectURL(this.files[0]);
  $source.parent()[0].load();
});*/
      $("#design").select2({
          placeholder: "Select Design",
          width: "resolve" 
       
      });

     /* $("#pre_list").select2({
          placeholder: "Select Prelist",
          width: "resolve" 
       
      });*/
     
  // Image upload
    $('.file_input').filer({
            showThumbs: true,
            templates: {
                box: '<ul class="jFiler-item-list"></ul>',
                item: '<li class="jFiler-item">\
                            <div class="jFiler-item-container">\
                                <div class="jFiler-item-inner">\
                                    <div class="jFiler-item-thumb">\
                                        <div class="jFiler-item-status"></div>\
                                        <div class="jFiler-item-info">\
                                            <span class="jFiler-item-title"><b title="{{fi-name}}">{{fi-name | limitTo: 25}}</b></span>\
                                        </div>\
                                        {{fi-image}}\
                                    </div>\
                                    <div class="jFiler-item-assets jFiler-row">\
                                        <ul class="list-inline pull-left">\
                                            <li><span class="jFiler-item-others">{{fi-icon}} {{fi-size2}}</span></li>\
                                        </ul>\
                                        <ul class="list-inline pull-right">\
                                            <li><a class="icon-jfi-trash jFiler-item-trash-action"></a></li>\
                                        </ul>\
                                    </div>\
                                </div>\
                            </div>\
                        </li>',
                itemAppend: '<li class="jFiler-item">\
                            <div class="jFiler-item-container">\
                                <div class="jFiler-item-inner">\
                                    <div class="jFiler-item-thumb">\
                                        <div class="jFiler-item-status"></div>\
                                        <div class="jFiler-item-info">\
                                            <span class="jFiler-item-title"><b title="{{fi-name}}">{{fi-name | limitTo: 25}}</b></span>\
                                        </div>\
                                        {{fi-image}}\
                                    </div>\
                                    <div class="jFiler-item-assets jFiler-row">\
                                        <ul class="list-inline pull-left">\
                                            <span class="jFiler-item-others">{{fi-icon}} {{fi-size2}}</span>\
                                        </ul>\
                                        <ul class="list-inline pull-right">\
                                            <li><a class="icon-jfi-trash jFiler-item-trash-action"></a></li>\
                                        </ul>\
                                    </div>\
                                </div>\
                            </div>\
                        </li>',
                progressBar: '<div class="bar"></div>',
                itemAppendToEnd: true,
                removeConfirmation: true,
                _selectors: {
                    list: '.jFiler-item-list',
                    item: '.jFiler-item',
                    progressBar: '.bar',
                    remove: '.jFiler-item-trash-action',
                }
            },
            addMore: true,
           /* files: [{
                name: "appended_file.jpg",
                size: 5453,
                type: "image/jpg",
                file: "http://dummyimage.com/158x113/f9f9f9/191a1a.jpg",
            },{
                name: "appended_file_2.png",
                size: 9503,
                type: "image/png",
                file: "http://dummyimage.com/158x113/f9f9f9/191a1a.png",
            }]*/
      });

    
   $("#category").on('change',function(){
          var id=$(this).val();
         $.ajax({
            type:"POST",
            url:"<?php echo site_url();?>product_vendor/get_sub_category",
            data:{'id':id},
            dataType:'json',
       success: function(response)
       { 
        var ln=response.length;
        if(ln>=1)
        {
           var cnt;
            for(var i=0;i<=ln-1;i++)
            {
              cnt+='<option value="'+response[i]['id']+'">'+response[i]['name']+'</option>';
             
            }

            $('.subcategory_blk').show();
            $('#subcategory').html('');
            $('#subcategory').html(cnt);
           
        }
        else
        {
          $('.subcategory_blk').hide();
        }

        }
      });
   });
    
</script>
 <style>
        .file_input{
            display: inline-block;
            padding: 10px 16px;
            outline: none;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
            white-space: nowrap;
            font-family: sans-serif;
            font-size: 11px;
            font-weight: bold;
            border-radius: 3px;
            color: #008BFF;
            border: 1px solid #008BFF;
            vertical-align: middle;
            background-color: #fff;
            margin-bottom: 10px;
            box-shadow: 0px 1px 5px rgba(0,0,0,0.05);
            -webkit-transition: all 0.2s;
            -moz-transition: all 0.2s;
            transition: all 0.2s;
        }
        .file_input:hover,
        .file_input:active {
            background: #008BFF;
            color: #fff;
        }
        .file_multi_video
        {
          display: inline-block;
            padding: 10px 16px;
            outline: none;
            cursor: pointer;
            text-decoration: none;
            text-align: center;
            white-space: nowrap;
            font-family: sans-serif;
            font-size: 11px;
            font-weight: bold;
            border-radius: 3px;
            color: #008BFF;
            border: 1px solid #008BFF;
            vertical-align: middle;
            background-color: #fff;
            margin-bottom: 10px;
            box-shadow: 0px 1px 5px rgba(0,0,0,0.05);
            -webkit-transition: all 0.2s;
            -moz-transition: all 0.2s;
            transition: all 0.2s;
        }
        .file_multi_video:hover,
        .file_multi_video:active {
            background: #008BFF;
            color: #fff;
        }
    </style>
