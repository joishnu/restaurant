<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Model for Design Management
 */
class Design_model extends CI_Model
{
	
	// for datatable
    public function table_items_count($table){
        $query = $this->db->where('status<>','2')->get($table);
        return $query->num_rows();
    }

    public function all_items($limit,$start,$col,$dir, $table, $select = '*'){
        $this->db->select($select);
        $query = $this->db
                ->limit($limit,$start)
                ->where('status<>','2')
                //->order('products.id','desc')
                ->get($table);


        if($query->num_rows()>0)
            return $query->result(); 
        else
            return null;
    }

    public function item_search($limit,$start,$search,$col,$dir, $table, $select)
    {
        $this->db->select($select);
        $query = $this->db
            ->like($table.'.id',$search)
            ->or_like($table.'.name',$search)
            ->or_like($table.'.description',$search)
            ->limit($limit,$start)->order_by($table.'.'.$col,$dir)->get($table);
        
        if($query->num_rows()>0)
            return $query->result();  
        else
            return null;
    }

    public function all_category_items(){
        return $this->db->select('id, name')->where('parent_id is NOT NULL', NULL, TRUE)->get('categories')->result_array();
        
    }

    function item_count_search($search, $table)
    {

        $query = $this->db
                ->like('id',$search)
                ->or_like('name',$search)
                ->or_like('description',$search)
                ->get($table);
        return $query->num_rows();
    } 

    public function get_design_name($id)
    {
        $info['design']= $this->db->select('name, description, CONCAT("'.IMGS_URL.'uploads/designs/", image) as image')->where('id', $id['number'])->get('designs')->row_array();
        $info['selected_chklist']=$this->db->select('checklist_id as id')->where('design_id',$id['number'])->get('checklist_design_relation')->result_array();
        return $info;
    }

    public function get_design_details($id){
        return $this->db->select("*")->where('id',$id)->get('designs')->row_array();
    }

    public function do_add_design($params) {
        try {
            $this->db->trans_begin();
            
            $insert_data = array(
                'name' => $params['name'],
                'description' => $params['description'],
                'image'    => $params['image'],
                'status' => '1',
                'created_on'=>date('Y-m-d H:i:s')
            );

            if(!$this->db->insert('designs', $insert_data))
            {
                throw new Exception("Error Processing Request", 1);
            }
            
            $insert_id = $this->db->insert_id();
            $master="";
            $area="";
            $cnt=count($params['checklist']);
            $cnt_area=count($params['area']);
            if($cnt>=1 && $cnt_area>=1 )
            {

                for($i=0;$i<=$cnt-1;$i++)
                {
                    if($i==0)
                    {
                        $area=$params['area'][$i];
                    }
                    else
                    {
                        $area.=','.$params['area'][$i];   
                    }
                    
                }
                for($i=0;$i<=$cnt-1;$i++)
                {
                    if($i==0)
                    {
                        $master=$params['checklist'][$i];
                    }
                    else
                    {
                        $master.=','.$params['checklist'][$i];   
                    }
                    
                }
                
            }else
            {
                throw new Exception("Error Processing Request", 1);
            }
             
                $insert_checklist= array('design_id' => $insert_id, 'master_checklist_id' => $master,
                    'area_list' => $area,'created_on'=> date('Y-m-d H:i:s'));   

                 if(!$this->db->insert('checklist_design_relation', $insert_checklist))
                {
                    throw new Exception("Error Processing Request", 1);
                }

                //print_r($this->db->last_query());exit();

            $this->db->trans_commit();
            return $insert_id;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function do_update_design($params) {
        try {
            $this->db->trans_begin();
            $this->db->set('name',$params['name']);      
            $this->db->set('description',$params['description']);
            if((isset($params['image']))&&$params['image']!='')
            {
                $this->db->set('image',$params['image']);      
            }
            $this->db->set('updated_on',date('Y-m-d H:i:s'));
            $this->db->where('id',$params['id']);
            $this->db->update('designs');
            if(!$this->db->affected_rows()) {
                throw new Exception("Error Processing Request", 1);
            }

            // checklist process 
            $not_exists=[];
             $cnt=count($params['checklist']);
            for($i=0;$i<=$cnt-1;$i++)
            {
                $result=$this->db->select('id,checklist_id')->where('checklist_id',$params['checklist'][$i])->where('design_id',$params['id'])->get('checklist_design_relation')->row_array();    
                if($result)
                {
                    $exists[]= array('id' => $result['id']);
                }
                else
                {
                    $not_exists[]= array('design_id' => $params['id'], 'checklist_id' => $params['checklist'][$i],'created_on'=> date('Y-m-d H:i:s'));
                }
            }

            if($not_exists)
            {

                if(!$this->db->insert_batch('checklist_design_relation', $not_exists))
                {
                    throw new Exception("Error Processing Request", 1);
                }
            }

            $result=$this->db->select('id')->where_not_in('checklist_id',$params['checklist'])->where('design_id',$params['id'])->get('checklist_design_relation')->result_array();    

            $cnt=count($result);
            for($i=0;$i<=$cnt-1;$i++)
            {
                $rs[]=$result[$i]['id'];
            }

            if($result)    
            {  
                if(!$this->db->where_in('id', $rs)->delete('checklist_design_relation'))
                {
                    throw new Exception("Error Processing Request", 1);
                }
            }
            $this->db->trans_commit();
            return 1;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function do_delete($id)
    {
        try {
            $this->db->trans_begin();
            $this->db->set('status',"2");      
            $this->db->set('updated_on',date('Y-m-d H:i:s'));
            $this->db->where('id',$id);
            $this->db->update('designs');
            if(!$this->db->affected_rows()) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }


    public function change_status($params) {
        try {
            $this->db->trans_begin();
            $where= array('id' => $params['number'] );
            $update_data = array(
                'status' =>$params['status'],
                'updated_on'=>date('Y-m-d H:i:s')
            );

            if(!$this->db->update('designs', $update_data, $where))
            {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function get_check_list()
    {
        return $this->db->select('*')->where('status', '1')->get('checklist')->result_array();
    }

    public function get_area_list()
    {
        return $this->db->select('*')->where('status', '1')->get('area_type')->result_array();
    }

}


?>