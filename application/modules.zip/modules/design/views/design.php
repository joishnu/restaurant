<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Design Management <small>| Design List</small><!-- <a href="javascript:void(0);" class="btn btn-success btn-block pull-right" role="button">Add Product</a> --></h3>
            </div>
        </div>
        <div class="title_right">
            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search" style="text-align: right">
                <a href="#" class="btn btn-primary pull-right" data-toggle="modal" data-target=".bs-example-modal-lg"> <i class="fa fa-plus"></i> Add New Design</a>
               <!--  <a href="<?php echo base_url()."checklist";?>" class="btn btn-primary pull-right"> <i class="fa fa-plus"></i> Add New Checklist</a><br> -->
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Design List<small>All Designs</small> </h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <!-- <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li> -->
                        <!-- <li><a class="close-link"><i class="fa fa-close"></i></a></li> -->
                        
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="row">
                        <?php
                        if ($this->session->flashdata('success')) { ?>
                        <div class="alert alert-success my_alert" role="alert">
                            <?php echo $this->session->flashdata('success'); ?>
                        </div>
                        <?php } if ($this->session->flashdata('fail')) { ?>
                        <div class="alert alert-danger my_alert" role="alert">
                            <?php echo $this->session->flashdata('fail'); ?>
                        </div>
                        <?php } ?>
                    </div>
                    <p class="text-muted font-13 m-b-30"><!-- If you want to write somting you can write here --></p>
                    <table id="product" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Image</th>
                                <th>Status</th>
                                <th>Created On</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<!-- Add Variation modal -->

<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
            </button>
            <h4 class="modal-title" id="myModalLabel">Add New Design</h4>
        </div>
        <div class="modal-body">
            <form class="form-horizontal form-label-left"  action="<?php echo base_url('design/do_add_design');?>" method="post" enctype="multipart/form-data" data-toggle="validator">
                <div class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Design Name <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <input type="text"  required="required" placeholder="Design Name" class="form-control col-md-7 col-xs-12" name="name">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Design Description <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <textarea name="description" required="required" class="form-control col-md-7 col-xs-12" placeholder="Design Description"></textarea>
                </div>
             </div>
              <div class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Master Prelist<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                      <select name="checklist[]" class="form-control select2" multiple="" required="" id="pre_list" style="width:100%;">
                        <?php $cnt=count($checklist);
                        for ($i=0;$i<=$cnt-1;$i++){?>
                            <option value="<?php echo $checklist[$i]['id'];?>"><?php echo $checklist[$i]['name'];?></option>
                        <?php } ?>
                      </select>
                      <div  id="clone_dt">
                      </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Area<span class="required">*</span>
                    </label>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                      <select name="area[]" class="form-control select2" multiple="" required="" id="area" style="width:100%;">
                        <?php $cnt=count($area_list);
                        for ($i=0;$i<=$cnt-1;$i++){?>
                            <option value="<?php echo $area_list[$i]['id'];?>"><?php echo $area_list[$i]['name'];?></option>
                        <?php } ?>
                      </select>
                      <div  id="clone_dt">
                      </div>
                    </div>
                </div>
        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Design Image <span class="required">*</span>
            </label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <img src="<?=base_url('assets/img/choose-an-image.jpg')?>" class="img-responsive img-thumbnail user-image-trigger form-image" width="150px" height="150px">
                <input type="file" name="image"  accept="image/*" class="hidden form-control"  required="">
                <span class="help-block with-errors"></span>
            </div>
        </div>
<!--         <div class="main_prelists">
        <input type="button" value="Add Master-prelist" class="btn btn-primary c_master_prelist" />
        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Master Prelist<span class="required">*</span>
            </label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <input type="text"  required="required" placeholder="Master Prelist Name" class="form-control col-md-7 col-xs-12" name="master[]"><br>
                 <input type="button" value="Add Sub-prelist" class="btn btn-primary c_sub_prelist" />
            </div>
        </div>
        <div class="tooltest0">
        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Sub Prelist<span class="required">*</span>
            </label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <input type="text"  required="required" placeholder="Sub Prelist Name" class="form-control col-md-7 col-xs-12" name="sub[]">
            </div>
        </div>
        <div class="form-group">
            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product List<span class="required">*</span>
            </label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <select class="toollist" name="product_list[]" multiple style="width: 100%;">
                    <option>Slect</option>
                    <option value="1">bla 1</option>
                    <option value="1">bla 1</option>
                </select>
            </div>
        </div>
        </div>
        </div> -->
        <div class="tool-placeholder"></div>
         
    <!-- <button type="button" id="clk">Cpy</button> -->
   <!--  <div class="form-group">
        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Prelisted Item<span class="required">*</span>
        </label>
        <div class="col-md-6 col-sm-6 col-xs-12">
          <select name="checklist[]" class="form-control select2" multiple="" required="" id="pre_list" style="width:100%;">
            <?php $cnt=count($checklist);
            for ($i=0;$i<=$cnt-1;$i++){?>
                <option value="<?php echo $checklist[$i]['id'];?>"><?php echo $checklist[$i]['name'];?></option>
            <?php } ?>
          </select>
          <div  id="clone_dt">
          </div>
        </div>
    </div> -->
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    <button type="submit" class="btn btn-primary">Save changes</button>
</div>
</form>
</div>
</div>
</div>
<!-- Edit Variation modal -->

<div class="modal fade" tabindex="-1" role="dialog" aria-hidden="true" id="edit-item">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title" id="myModalLabel">Edit Design</h4>
            </div>
            <div class="modal-body">
                <form class="form-horizontal form-label-left" action="<?php echo base_url('design/do_update_design');?>" method="post" enctype="multipart/form-data" data-toggle="validator">
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Design Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="text" id="name" placeholder="Design Name" required="required" class="form-control col-md-7 col-xs-12" name="name">
                            <input type="hidden" placeholder="" name="id" id="id_design_hid" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Design Description <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <textarea name="description" required="required" class="form-control col-md-7 col-xs-12" placeholder="Design Description" id="description"> </textarea>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Design Image <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <img src="<?=base_url('assets/img/choose-an-image.jpg')?>" class="img-responsive img-thumbnail user-image-trigger form-image" id="form-img" width="150px" height="150px">
                            <input type="file" name="image"  accept="image/*" class="hidden form-control">
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Prelisted Item<span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12" id="info_show">
                         
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>

    <script type="text/javascript">
          $("#pre_list").select2({
              placeholder: "Select Prelist",
              width: "resolve",

          });
            $("#area").select2({
              placeholder: "Select Prelist",
              width: "resolve",

          });

</script>