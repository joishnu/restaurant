<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Checklist extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('product_vendor/Product_model','product_model');
		$this->load->model('checklist_model','product');
		$this->load->library('external');
	}

	public function index(){
		$data['title'] = 'Checlist Management';
		$data['page'] = 'checklist';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();     
		$data['extra_datatable_data'] .= $this->external->validation_extra_js_css();     
		$data['extra_datatable_data'] .= '<script type="text/javascript">
											$(document).ready(function (){
											    $("#product").DataTable({
											        "processing": true,
											        "serverSide": true,
											        "ajax":{
											            "url": "'.base_url('checklist/chk_list').'",
											            "dataType": "json",
											            "type": "POST",
											            "data":{
											              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
											            }
											        },
											        "columns": [
											          { "data": "id" },
											          { "data": "name" },
											          { "data": "description" },
											          { "data": "status" },
											          { "data": "created_on" },
											          { "data": "action" },
											        ]
											    });

											});
											function edit_func(id){
												
												$.ajax({
													url: "'.base_url('checklist/checklist_name').'",
													data: { 
														"number": id, 
													},
													cache: false,
													type: "POST",
													success: function(response) {
														$("#id_design_hid").val(id);
														var vl=JSON.parse(response);
														$("#name").val(vl.name);
														$("#description").val(vl.description);
														$("#form-img").attr("src",vl.image);
													},
													error: function(xhr) {
														console.log(xhr);
													}
												});
												$("#edit-item").modal("show");
												
											}

											function change_status(that){
												var number = $(that).attr("data-number");
												var status = $(that).val();
												$.ajax({
													url: "'.base_url('checklist/change_status').'",
													data: { 
														"number": number, 
														"status": status
													},
													cache: false,
													type: "POST",
													success: function(response) {
														console.log(response);
														$("#product").DataTable().ajax.reload();
													},
													error: function(xhr) {
														console.log(xhr);
													}
												});
											}

											</script>

											';
											//print_r($data['extra_datatable_data']);exit();
		$this->load->view('template',$data);
	}

	public function checklist_name(){
		echo json_encode($this->product->get_checklist_name($this->input->post(NULL,true)));
	}

	// Product List ajax call for product list datatable
	public function chk_list(){
		$columns = array(
			0 => "id",
			1 => "name",
			2 => "description",
			3 => "status",
			4 => "created_on",
			5 => "action"
		);

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
        $totalData = $this->product->table_items_count('checklist');

        $totalFiltered = $totalData; 
        if(empty($this->input->post('search')['value'])){
        	$posts = $this->product->all_items($limit,$start,$order,$dir, 'checklist', "checklist.status,checklist.name,checklist.id as id,checklist.created_on, checklist.description");
        }else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->product->item_search($limit,$start,$search,$order,$dir, 'checklist', "checklist.status,checklist.name,checklist.id as id,checklist.created_on, checklist.description");
            $totalFiltered = $this->product->item_count_search($search,  'checklist');
        }
  		$data = array();

		if(!empty($posts)){
			$j=0;
			foreach ($posts as $post){
				$j++;
			
				$nestedData['id'] = $j;
				$nestedData['name'] = $post->name;
				$nestedData['description'] = $post->description;
				$nestedData['status'] = '<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
					<option value="0" '.(($post->status == 0)? 'selected="selected"' :" ").' >Deactivate </option>
					<option value="1" '.(($post->status == 1)? 'selected="selected"' :" ").'>Activate</option>
				</select>';
				$nestedData['created_on'] = $post->created_on;
				$nestedData['action'] = '
				<button class="btn btn-primary edit" onclick="edit_func('.$post->id.')"><i class="fa fa-pencil" ></i> Edit</button><a href="'.base_url('/checklist/delete').'/'.$post->id.'"><button class="btn btn-danger"><i class="fa fa-remove" ></i> Delete</button></a><!--<a data-toggle="modal" data-target=".bs-example-modal-lg"><button class="btn btn-primary"><i class="fa fa-pencil"></i> View</button></a>-->
				';
					$data[] = $nestedData;
			}
		}

		$json_data = array(
		"draw"            => intval($this->input->post('draw')),  
		"recordsTotal"    => intval($totalData),  
		"recordsFiltered" => intval($totalFiltered), 
		"data"            => $data   
		);
		echo json_encode($json_data); 
	}

	public function delete($id = 0)
    {
        try {
            if(!$id) {
                throw new Exception('Choose a checklist', 1);
            }
            $rs = $this->product->do_delete($id);

            if(!$rs){
                throw new Exception("Error Processing Request", 1);   
            }

            $this->session->set_flashdata('success', 'Design is deleted successfully');
            redirect(site_url('checklist'));

        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(site_url('checklist'));

        }
    }

	public function do_add_checklist() {
		 try {
            $this->form_validation->set_rules('name','Checklist name','trim|required');
            $this->form_validation->set_rules('description','Description','trim|required');

            if(!$this->form_validation->run()) {
                throw new Exception(validation_errors(), 1);
            }
            $input = $this->input->post(NULL, TRUE);
            //$this->product->validate_name($info['name']);
          

            if(!$this->product->do_add_checklist($input)){
                throw new Exception("Error Processing Request", 1);   
            }

            $this->session->set_flashdata('success', 'Checklist is added successfully');
            redirect(site_url('checklist'));
        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(site_url('checklist'));
        }
	}

	public function do_update_checklist() {
		try {
            $this->form_validation->set_rules('id','id','required');
            $this->form_validation->set_rules('name','name','required');
            if(!$this->form_validation->run()) {
                throw new Exception(validation_errors(), 1);
            }

            $info = $this->input->post(null, true);
            $details=$this->product->get_checklist_details($info['id']);

            $rs = $this->product->do_update_checklist($info);

            if(!$rs){
                throw new Exception("Error Processing Request", 1);   
            }

            $this->session->set_flashdata('success', 'Checklist is updated Successfully');

        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            
        }
        redirect(site_url('design'));
	}

	public function change_status() {
		$this->form_validation->set_rules('number','number','trim|required');
	    $info = $this->input->post(NULL,true);
	    echo json_encode($this->product->change_status($info));
	}

	public function get_product_list() {
	    $info = $this->input->post(NULL,true);
	    echo json_encode($this->product->get_product_list($info));
	}



	public function add_prelist()
	{
		$data['title'] = 'Prelist Management';
		$data['page'] = 'add';       
		$data['category']=$this->product_model->get_category_list();
		$this->load->view('template',$data);
	}

}
