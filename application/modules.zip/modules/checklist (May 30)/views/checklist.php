<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Checklist Management <small>| Checklist</small><!-- <a href="javascript:void(0);" class="btn btn-success btn-block pull-right" role="button">Add Product</a> --></h3>
            </div>
        </div>
        <div class="title_right">
            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search" style="text-align: right">
                <a href="#" class="btn btn-primary pull-right" data-toggle="modal" data-target=".bs-example-modal-lg"> <i class="fa fa-plus"></i> Add New Checklist</a><br>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Checklist<small>All Checklist</small> </h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <!-- <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li> -->
                        <!-- <li><a class="close-link"><i class="fa fa-close"></i></a></li> -->
                        
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="row">
                        <?php
                        if ($this->session->flashdata('success')) { ?>
                        <div class="alert alert-success my_alert" role="alert">
                            <?php echo $this->session->flashdata('success'); ?>
                        </div>
                        <?php } if ($this->session->flashdata('fail')) { ?>
                        <div class="alert alert-danger my_alert" role="alert">
                            <?php echo $this->session->flashdata('fail'); ?>
                        </div>
                        <?php } ?>
                    </div>
                    <p class="text-muted font-13 m-b-30"><!-- If you want to write somting you can write here --></p>
                    <table id="product" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Status</th>
                                <th>Created On</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<!-- Add Variation modal -->

<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span>
            </button>
            <h4 class="modal-title" id="myModalLabel">Add New Checklist</h4>
        </div>
        <div class="modal-body">
            <form class="form-horizontal form-label-left"  action="<?php echo base_url('checklist/do_add_checklist');?>" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Checklist Name <span class="required">*</span>
                </label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <input type="text"  required="required" placeholder="Design Name" class="form-control col-md-7 col-xs-12" name="name">
                </div>
            </div>
            <div class="form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Checklist Description <span class="required">*</span>
            </label>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <textarea name="description" required="required" class="form-control col-md-7 col-xs-12" placeholder="Design Description"></textarea>
            </div>
        </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    <button type="submit" class="btn btn-primary">Save changes</button>
</div>
</form>
</div>
</div>
</div>
<!-- Edit Variation modal -->

<div class="modal fade" tabindex="-1" role="dialog" aria-hidden="true" id="edit-item">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
                <h4 class="modal-title" id="myModalLabel">Edit Checklist</h4>
            </div>
            <div class="modal-body">
                <form class="form-horizontal form-label-left" action="<?php echo base_url('checklist/do_update_checklist');?>" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Checklist Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input type="text" id="name" placeholder="Design Name" required="required" class="form-control col-md-7 col-xs-12" name="name">
                            <input type="hidden" placeholder="" name="id" id="id_design_hid" class="form-control">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Checklist Description <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <textarea name="description" required="required" class="form-control col-md-7 col-xs-12" placeholder="Design Description" id="description"> </textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>