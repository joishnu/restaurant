<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Checklist Management <small>| Checklist</small><!-- <a href="javascript:void(0);" class="btn btn-success btn-block pull-right" role="button">Add Product</a> --></h3>
            </div>
        </div>
        <div class="title_right">
            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search" style="text-align: right">
                <a href="#" class="btn btn-primary pull-right" data-toggle="modal" data-target=".bs-example-modal-lg"> <i class="fa fa-plus"></i> Add New Checklist</a><br>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Checklist<small>All Checklist</small> </h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <!-- <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li> -->
                        <!-- <li><a class="close-link"><i class="fa fa-close"></i></a></li> -->
                        
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <form class="form-horizontal form-label-left"  action="<?php echo base_url('checklist/do_add_checklist');?>" method="post" enctype="multipart/form-data">
                        <!--nested clone demo start-->
                            <div class="nest-clone demo-wrap">
                                <form class="form" method="post"> 
                                    <div class="toclone">
                                        <strong>Master Prelist</strong>
                                        <p class="name"> 
                                            <input type="text" name="master_prelst[]" id="master_prelst" /> 
                                        </p> 
                                        <div class="nest-clone inner-wrap">
                                            <div class="toclone">
                                                <strong>Sub Prelist</strong>
                                                <p class="email"> 
                                                    <input type="text" name="sub_prelist[]" id="sub_prelist" /> 
                                                </p> 
                                            
                                                <div class="nest-clone inner-inner-wrap">
                                                    <div class="toclone">
                                                        <strong>Category</strong>
                                                        <p class="phone"> 
                                                            <select id="category"  required="" name="category" class="category">
                                                              <?php $cnt=count($category);
                                                                    for($i=0;$i<=$cnt-1;$i++){
                                                                    ?>
                                                                    <option value="<?php echo $category[$i]['id'];?>"><?php echo $category[$i]['name'];?></option>
                                                             <?php }?>
                                                            </select>
                                                        </p>
                                                        <strong>Subcategory</strong>
                                                        <p class="phone"> 
                                                            <select id="subcategory" required="" name="subcategory" style="width: 82%;" class="subcategory">
                                                            </select>
                                                        </p>
                                                        <strong>Product Name</strong>
                                                        <p class="phone"> 
                                                            <select class="toollist" name="product_list[]" id="product_list" class="product_list form-control" multiple style="width: 82%;">
                                                            
                                                            </select> 
                                                        </p>  
                                                         <a href="#" class="clone"><button type="button"><i class="fa fa-plus"></i></button></a>
                                                        <a href="#" class="delete"><button type="button"><i class="fa fa-minus"></i></button></a>
                                                    </div>
                                                </div>
                                                <a href="#" class="clone"><button type="button"><i class="fa fa-plus"></i></button></a>
                                                <a href="#" class="delete"><button type="button"><i class="fa fa-minus"></i></button></a>
                                            </div>
                                        </div>
                                        <a href="#" class="clone"><button type="button"><i class="fa fa-plus"></i></button></a>
                                        <a href="#" class="delete"><button type="button"><i class="fa fa-minus"></i></button></a>
                                    </div>

                                </form>
                            </div>
                <!-- clone ends here -->
                </div>
            </div>
        </div>
    </div>
</div>
</div>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
    <script src="<?php echo CUSTOM_URL;?>assets/vendors/clone/jquery-cloneya.min.js"></script>
<script type="text/javascript">

    $("#product_list").select2({
          placeholder: "Select Prelist",
          width: "resolve",
    });

    $("#clk").on('click', function(){
       
        $(".select2").clone()
                     .select2()
                     .appendTo("#clone_dt");
        $('.toollist').select2("destroy");
       /* var original = $(".select2");
        var clone = original.clone();
        clone.select2();
        console.log(clone);
        clone.appendTo("#clone_dt");*/

    });
         
    $('.toollist').select2({ //apply select2 to my element
        placeholder: "Select Product",
        allowClear: true
    });


    $('.c_sub_prelist').click(function () {

        $('.toollist').select2("destroy");
        var noOfDivs = $('.tooltest0').length;
        var clonedDiv = $('.tooltest0').first().clone(true);
        clonedDiv.insertAfter(".tool-placeholder");
        clonedDiv.attr('id', 'tooltest' + noOfDivs);
        

        $('.toollist').select2({ //apply select2 to my element
            placeholder: "Search your Tool"
        });


    });

    $('.c_master_prelist').click(function () {

        $('.toollist').select2("destroy");
        var noOfDivs = $('.main_prelists').length;
        var clonedDiv = $('.main_prelists').first().clone(true);
        clonedDiv.insertAfter(".tool-placeholder");
        clonedDiv.attr('id', 'tooltest' + noOfDivs);

        $('.toollist').select2({ //apply select2 to my element
            placeholder: "Select Product"
        });


    });

</script>

<style type="text/css">
            .demo-wrap{
                margin: 40px auto;
                display:block;
                position:relative;
                max-width:500px;
            }
            .inner-wrap, .inner-inner-wrap{
                margin-left:10px;
                padding-left:10px;
                border-left:1px #ccc solid;
                padding-bottom:10px;
                margin-bottom:10px;
            }
            input, textarea { 
                padding: 9px; 
                border: solid 1px #E5E5E5; 
                outline: 0; 
                font: normal 13px/100% Verdana, Tahoma, sans-serif; 
                width: 200px; 
                background: #FFFFFF; 
            } 

            textarea { 
                width: 400px; 
                max-width: 400px; 
                height: 150px; 
                line-height: 150%; 
            } 

            input:hover, textarea:hover, 
            input:focus, textarea:focus { 
                border-color: #C9C9C9; 
            } 

            .form label { 
                margin-left: 10px; 
                color: #999999; 
            } 

            .submit input { 
                width: auto; 
                padding: 9px 15px; 
                background: #617798; 
                border: 0; 
                font-size: 14px; 
                color: #FFFFFF; 
            }
        </style>

    <script>
        $('#simple-clone').cloneya();

        $('.nest-clone').cloneya();

        $('.nest-clone-p').cloneya({
            preserveChildCount: true
        });

        $('#limit-clone').cloneya({
            maximum: 3,
            minimum: 2
        })
                .on('maximum.cloneya', function (e, limit, toclone) {
                    var limitmsg = 'No more than ' + limit + ' clones for you!'
                    alert(limitmsg);
                })
                .on('minimum.cloneya', function (e, limit, toclone) {
                    var limitmsg = 'No less than ' + limit + ' clones for you!'
                    alert(limitmsg);
                });

        $('#animate-clone').cloneya()
                .on('before_clone.cloneya', function (event, toclone) {
                    // do something
                })
                .on('after_clone.cloneya', function (event, toclone, newclone) {
                    // do something   
                })
                .on('before_append.cloneya', function (event, toclone, newclone) {
                    $(newclone).css('display', 'none');
                    $(toclone).fadeOut('fast', function () {
                        $(this).fadeIn('fast');
                    });
                })
                .on('after_append.cloneya', function (event, toclone, newclone) {
                    $(newclone).slideToggle();
                    console.log('finished cloning ' + toclone.attr('id') + ' to ' + newclone.attr('id'));
                })
                .off('remove.cloneya')
                .on('remove.cloneya', function (event, clone) {
                    clone.css('background-color', 'red');

                    $(clone).slideToggle('slow', function () {
                        $(clone).remove();
                    });

                })
                .on('after_delete.cloneya', function () {
                    console.log('deleted');
                });
    </script>


<script type="text/javascript">
    $(".category").on('change',function(){
          var id=$(this).val();
         $.ajax({
            type:"POST",
            url:"<?php echo site_url();?>product_vendor/get_sub_category",
            data:{'id':id},
            dataType:'json',
       success: function(response)
       { 
        var ln=response.length;
            if(ln>=1)
            {
               var cnt;
                for(var i=0;i<=ln-1;i++)
                {
                  cnt+='<option value="'+response[i]['id']+'">'+response[i]['name']+'</option>';
                 
                }

                $('.subcategory').html('');
                $('.subcategory').html(cnt);
            }
        }
      });
   });
    var id=$('.category').val();
     $.ajax({
            type:"POST",
            url:"<?php echo site_url();?>product_vendor/get_sub_category",
            data:{'id':id},
            dataType:'json',
       success: function(response)
       { 
        var ln=response.length;
        if(ln>=1)
        {
           var cnt;
            for(var i=0;i<=ln-1;i++)
            {
              cnt+='<option value="'+response[i]['id']+'">'+response[i]['name']+'</option>';
             
            }

            $('.subcategory').html('');
            $('.subcategory').html(cnt);
           
        }
        }
      });


     $(".subcategory").on('change',function(){
        var thisobj=$(this);
          var id=$(this).val();
          var cat_id=$('#category').val();
         $.ajax({
            type:"POST",
            url:"<?php echo site_url();?>checklist/get_product_list",
            data:{'sub_cat_id':id, 'cat_id':cat_id },
            dataType:'JSON',
       success: function(response)
       { 
        console.log(response);
        //var rs=JSON.parse(response);
       
    //    console.log(response);
       var ln=response.length;
            if(ln>=1)
            {
               var cnt="";
               var cnt1=[];
                for(var i=0;i<=ln-1;i++)
                {
                  cnt+='<option value="'+response[i]['id']+'">'+response[i]['name']+'</option>';
                  var b;
                  b={ id :response[i]['id'],text:response[i]['name'] };
                  cnt1.push(b);
                }
                console.log(cnt);
                console.log(cnt1);
                //$('.product_list').html('');
                //$('.product_list').html(cnt);
                /*var data = {
                    id: 1,
                    text: 'Barn owl'
                };

                */
                var newOption = new Option(cnt1.text, cnt1.id, false, false);

                //$(this).parent().parent().find('.phone select').select2();
                /*thisobj.parent().parent().parent().find('.phone select.select2-hidden-accessible').css('background','red');*/
                thisobj.parent().parent().parent().find('.phone select.select2-hidden-accessible').select2('destroy');
                thisobj.parent().parent().parent().find('.phone select.select2-hidden-accessible').select2().append(newOption).trigger('change');
                //$('#mySelect2').append(newOption).trigger('change');
                //  console.log(thisobj.css('background-color','red'));       

            }
        }
      });
         
   });
</script>
