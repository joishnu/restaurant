<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Model for Design Management
 */
class Tag_model extends CI_Model
{
	
	// for datatable
    public function table_items_count($table){
        $query = $this->db->get($table);
        return $query->num_rows();
    }

    public function all_items($limit,$start,$col,$dir, $table, $select = '*'){
        $this->db->select($select);
        $query = $this->db
                ->limit($limit,$start)
                ->where('status<>','2')
                ->order_by('id','desc')
                ->get($table);


        if($query->num_rows()>0)
            return $query->result(); 
        else
            return null;
    }

    function item_search($limit,$start,$search,$col,$dir, $table, $select)
    {
        $this->db->select($select);
        $query = $this->db
            ->like($table.'.id',$search)
            ->or_like($table.'.name',$search)
            ->limit($limit,$start)->order_by($table.'.'.$col,$dir)->get($table);
        
        if($query->num_rows()>0)
            return $query->result();  
        else
            return null;
    }

   public function item_count_search($search, $table)
    {

        $query = $this->db
                ->like('id',$search)
                ->or_like('name',$search)
                ->get($table);
        return $query->num_rows();
    } 

    public function get_tag_name($id)
    {
        return $this->db->select('name, description')->where('id', $id['number'])->get('product_tags')->row_array();

    }

    public function do_add_tag($params) {
        try {
            $this->db->trans_begin();
              //echo "<pre>";print_r($params);die();
            $insert_data = array(
                'name'    => $params['name'],
                'description'    => $params['description'],
                'status'  => '1',
                'created_on' => date('Y-m-d H:i:s'),
                'updated_on' => date('Y-m-d H:i:s'),
            );
            
            if(!$this->db->insert('product_tags', $insert_data))
            {
                throw new Exception("Error Processing Request", 1);
            }
            
            $insert_id = $this->db->insert_id();

            $this->db->trans_commit();
            return $insert_id;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function do_update_tag($params) {
        try {
            $this->db->trans_begin();
            $update_data = array(
                'name'=> $params['name'],
                'description'=> $params['description'],
                'updated_on'=>date('Y-m-d H:i:s'),
            );
           
            $where = array(
                'id' => $params['id']
            );
            $this->db->update('product_tags', $update_data, $where);

            if(!$this->db->affected_rows()) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return 1;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }


    public function do_delete($id)
    {
        try {
            $this->db->trans_begin();
            $this->db->set('status',"2");      
            $this->db->set('updated_on',date('Y-m-d H:i:s'));
            $this->db->where('id',$id);
            $this->db->update('product_tags');
            if(!$this->db->affected_rows()) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }


    public function change_status($params) {
        try {
            $this->db->trans_begin();
            $where= array('id' => $params['number'] );
            $update_data = array(
                'status' =>$params['status'],
                'updated_on'=>date('Y-m-d H:i:s')
            );

            if(!$this->db->update('product_tags', $update_data, $where))
            {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

}


?>