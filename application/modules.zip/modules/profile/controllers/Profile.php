<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Profile extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->model('profile/profile_model','profile');
		$this->load->model('authenticate/Authenticate_model','authenticate');
	}

	public function index()
	{
		redirect(base_url().'profile/changepassword');
	}
	
	public function changepassword(){
		$data['title'] = 'Change Password';
		$data['page'] = "changePassword";
		$this->load->view("template",$data);
	}
	public function updatePassword(){
    	 $this->form_validation->set_rules('newpassword','Password','required|trim|valid_password');
        $this->form_validation->set_rules('confirm_password','Confirm Password','trim|required|matches[newpassword]');
        $this->form_validation->set_rules('oldpassword','Old password','trim|required');
        $post_data=$this->input->post(null,true);
        //echo"<pre>";print_r($post_data);die;
		$result = $this->profile->updatePassword($post_data);
		$this->session->set_flashdata('success', 'Password changed successfully');
		redirect(base_url().'profile/changepassword','refresh');

	}
	public function edit_profile(){
		$id=$this->session->userdata('id');
		$data['title'] = 'Change Profile';
		$data['list'] = $this->profile->get_real_info($id);
	    //echo"<pre>";print_r($data['list']);die;
		$data['page'] = "profile";
		$this->load->view("template",$data);
	}
	public function updateProfile(){
    	$this->form_validation->set_rules('first_name','first_name','required');
        $this->form_validation->set_rules('email','Email','required');
        $this->form_validation->set_rules('phone','phone','required');
        $post_data=$this->input->post(null,true);
		$result = $this->profile->updateprofile($post_data);
		$this->session->set_flashdata('success', 'profile has been changed successfully');
		redirect(base_url().'profile/edit_profile','refresh');

	}

}
