<?php if (!defined('BASEPATH'))exit('No direct script access allowed');
class Profile_model extends CI_Model {	

     public function get_real_info(){
      $id=$this->session->userdata('id');
      $this->db->select("*");
      $this->db->from("users");
      $this->db->where('id',$id);
      $result=$this->db->get()->row();
        // echo"<pre>";print_r($result);die;

      return $result;
  }
    public function updateprofile($params){

     $id=$this->session->userdata('id');
       $data = array(
                  'first_name' => $params['first_name'],
                  'phone' => $params['phone'],
                  'email' => $params['email']
              );
              //echo"<pre>";print_r($data);die;

               $this->db->where('id',$this->session->userdata('id'));
            return $this->db->update('users',$data);
     
     }
     public function updatePassword($params){
      $this->db->select("password");
          $this->db->from("users");
          $this->db->where('id',$this->session->userdata('id'));
          $result=$this->db->get()->row_array();
          if($result['password']){
               // success
               $this->db->set('password',$params['newpassword']);
               $this->db->where('id',$this->session->userdata('id'));
               $this->db->update('users');
                return true;
          }else{
             
         return false;
          }
  }
}