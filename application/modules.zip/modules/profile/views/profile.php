<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Edit Profile <small>|Edit profile</small></h3>
      </div>
    </div>
    
  </div>
  <div class="clearfix"></div>
  <div class="row">
     <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Profile</h2>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <div id="wizard" class="form_wizard wizard_horizontal">
            
             <form method="post" id="formProfile"  action="<?=site_url('profile/updateProfile');?>" class="form-horizontal" enctype="multipart/form-data" data-toggle="validator">
                <div id="step-1">
                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">First name <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="first_name" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" data-validate-words="2" name="first_name" placeholder="Please enter first name" required="required" type="text" value="<?php echo $list->first_name;?>" required>
                        </div>
                      </div>
                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Mobile<span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="phone" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" data-validate-words="2" name="phone" placeholder="Please enter phone" required="required" type="number" value="<?php echo $list->phone;?>" required>
                        </div>
                      </div>

                      <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Email <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="email" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" data-validate-words="2" name="email" placeholder="Please enter email address" required="required" type="text" value="<?php echo $list->email;?>" required>
                        </div>
                      </div>
                      <div class="form-group">
                <div class="col-md-6 col-md-offset-3">
                  <button id="send" type="submit" class="btn btn-success">Save</button>
                </div>
              </div>
              </form>
            </div>
          </div>
        </div>
     </div>
  </div>
</div>
</div>


