<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3><?php echo $title;?></h3>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <?php $this->load->view('includes/show_flashdata'); ?>   
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2><?php echo $title;?></h2>
                    
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="x_content">
                        <form class="form-horizontal form-label-left" enctype="multipart/form-data" novalidate id="admin_update_form" method="post" action="<?=base_url('employees/submit_employee')?>" data-toggle="validator" data-disable="false">
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Name<span class="required">*</span></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="first_name" class="form-control col-md-7 col-xs-12"  name="name" placeholder="Please enter name" required="required" type="text" value="">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Email <span class="required">*</span></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="email" class="form-control col-md-7 col-xs-12"  name="email" placeholder="Please enter email address" required="required" type="text" value="">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Phone <span class="required">*</span></label>
                                <div class="col-md-2 col-sm-2 col-xs-4">
                                    <select id="country_code" name="country_code" class="form-control col-md-7 col-xs-12">
                                        <option value="">Please select country code</option>
                                        <?php
                                        foreach ($countries as $key => $value) {
                                        echo "<option value='".$value['phonecode']."' ".((isset($value['phonecode'])  == $admins['country_code'])?"selected":"").">".$value['name']." (+".$value['phonecode'].") </option>";
                                        
                                        }
                                        ?>
                                    </select>
                                    <div class="help-block with-errors"></div>
                                </div>
                                <div class="col-md-4 col-sm-4 col-xs-8">
                                    <input id="phone" class="form-control col-md-7 col-xs-12"  name="phone" placeholder="Please enter phone number" required="required" type="text" value="">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Address <span class="required">*</span></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="address" class="form-control col-md-7 col-xs-12"  name="address" placeholder="Please enter address" required="required" type="text" value="">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Image</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="images" class="form-control col-md-7 col-xs-12" name="images" placeholder="Please upload profile picture"  type="file" multiple="" required="">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Status <span class="required">*</span></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select id="status" name="status" class="form-control col-md-7 col-xs-12" required="">
                                        <option value="">Please select status</option>
                                        <option value="1">Activate</option>
                                        <option value="2">Deactivate</option>
                                    </select>
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="ln_solid"></div>
                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-3">
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>