<?php

if (!defined('BASEPATH'))exit('No direct script access allowed');

class Employees_model extends CI_Model {

	public function table_items_count($table)
	{
		$query = $this->db->get($table)->num_rows();
		//echo $this->db->last_query();die();
		return $query;
	}

	public function all_items($limit,$start,$col,$dir, $table, $select = '*'){
		$this->db->select($select);
		$query = $this->db
				->limit($limit,$start)
				//->order_by($col,$dir)
				->get($table);

		if($query->num_rows()>0)
            return $query->result(); 
        else
            return null;
	}

	public function item_search($limit,$start,$search,$col,$dir, $table, $select)
    {
    	$this->db->select($select);
        $query = $this->db
        	->like($table.'.id',$search)
        	->or_like('address',$search)
        	->limit($limit,$start)->order_by($table.'.'.$col,$dir)->get($table);
        
       
        if($query->num_rows()>0)
            return $query->result();  
        else
            return null;
    }

    public function add_employee($data)
    {
    	$insert_data = array(
    		'name' 	=>	$data['name'],
    		'vendor_id'=>$this->session->userdata('id'),
    		'email' =>	$data['email'],
    		'country_code' => $data['country_code'],
    		'phone'	=>	$data['phone'],
    		'image' => $data['image'],
    		'address'=>$data['address'],
    		'added_on'=>date('Y-m-d H:i:s'),
    		'status'=>$data['status']
    	);
    	$this->db->insert('employee', $insert_data);
    	return $this->db->affected_rows();
    }

    public function change_status($table,$status,$id)
    {
    	try {

            $this->db->trans_begin();
            $where= array('id' => $id );
            $update_data = array(
                'status' =>$status,
                'updated_on'=>date('Y-m-d H:i:s')
            );
            $result = $this->db->update('employee', $update_data, $where);
            
            if(!$result)
            {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function do_delete($id)
    {	
    	$this->db->where('id', $id);
    	return $this->db->delete('employee');
    }

    public function get_employee($id)
    {	
    	$this->db->select('name,email,country_code,phone,address,CONCAT("'.IMGS_URL.'", image) as image');
    	$this->db->where('id', $id);
    	$result = $this->db->get('employee')->row_array();
    	
    	return $result;
    }

    public function update_employee($data)
    {
    	$update_data = array(
    		'name' 	=>	$data['name'],
    		'vendor_id'=>$this->session->userdata('id'),
    		'email' =>	$data['email'],
    		'country_code' => $data['country_code'],
    		'phone'	=>	$data['phone'],
    		//'image' => $data['image'],
    		'address'=>$data['address'],
    		'added_on'=>date('Y-m-d H:i:s'),
    		
    	);
        if($data['image'] !=""){
            $update_data['image'] = $data['image'];
        }
    	$this->db->where('id', $data['id']);
    	$this->db->update('employee', $update_data);
    	return $this->db->affected_rows();
    }

}