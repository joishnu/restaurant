<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Employees extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->library('external');
		$this->load->model('general/general_model','general');
		$this->load->model('employees_model','employee');
	}


	public function index(){
		$data['title'] = 'Employee Management';
		$data['page'] = 'employee_list';       
		$data['countries'] = $this->general->get_all_country();
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();
		$data['extra_datatable_data'] .= '<script type="text/javascript">
											$(document).ready(function (){
											    $("#employee_list").DataTable({
											        "processing": true,
											        "serverSide": true,
											        "ajax":{
											            "url": "'.base_url('employees/employee_list').'",
											            "dataType": "json",
											            "type": "POST",
											            "data":{
											              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
											            }
											        },
											        "columns": [
											          { "data": "id" },
											          { "data": "name" },
											          { "data": "email" },
											          { "data": "phone" },
											          { "data": "address" },
											          { "data": "status" },
											          { "data": "action" },
											        ]
											    });
											});

											function edit_func(id){
												
												$.ajax({
													url: "'.base_url('employees/edit_employee').'",
													data: { 
														"number": id, 
													},
													cache: false,
													type: "POST",
													success: function(response) {
														$(".id_employee_id").val(id);
														var vl=JSON.parse(response);
														$(".first_name").val(vl.name);
														$(".email").val(vl.email);
														$(".form-img").attr("src",vl.image);
														$(".country_code").val(vl.country_code);
														$(".phone").val(vl.phone);
														$(".address").val(vl.address);
													},
													error: function(xhr) {
														
													}
												});
												$("#edit-item").modal("show");
												
											}

											function view_func(id){
												$.ajax({
													url: "'.base_url('employees/edit_employee').'",
													data: { 
														"number": id, 
													},
													cache: false,
													type: "POST",
													success: function(response) {
														$(".id_employee_id").val(id);
														var vl=JSON.parse(response);
														$(".first_name").val(vl.name);
														$(".email").val(vl.email);
														$(".form-img").attr("src",vl.image);
														$(".country_code").val(vl.country_code);
														$(".phone").val(vl.phone);
														$(".address").val(vl.address);
													},
													error: function(xhr) {
														
													}
												});
												$("#view-item").modal("show");
												
											}

											function change_status(that){
												var number = $(that).attr("data-number");
												var status = $(that).val();
												$.ajax({
													url: "'.base_url('employees/change_status').'",
													data: { 
														"number": number, 
														"status": status
													},
													cache: false,
													type: "POST",
													success: function(response) {
														console.log(response);
														$("#employee_list").DataTable().ajax.reload();
													},
													error: function(xhr) {
														
													}
												});
											}
											$(".form-image").on("click", function(){
										        $(this).parents(".form-group").find("input[type=file]").trigger("click");
										   });
									        $("input[name=image]").on("change", function(event) {
									            if ($(this).val() !== "") {
									                read_image(event, ".user-image-trigger");
									            } else {
									                $(".user-image-trigger").attr({"src":base_url("assets/img/choose-an-image.jpg"),"width":"150px","height":"150px"});
									            }
										    });
											</script>';
		$this->load->view('template',$data);       
	}

	public function employee_list(){
		$columns = array(
			0 => "id",
			1 => "name",
			2 => "email",
			3 => "phone",
			4 => "address",
			5 => "status",
			6 => "action"
		);

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
        $totalData = $this->employee->table_items_count('employee');
        
        $totalFiltered = $totalData; 
        if(empty($this->input->post('search')['value'])){
        	$posts = $this->employee->all_items($limit,$start,$order,$dir, 'employee', "id,name,email,phone,address,status,image"	);
        }else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->employee->item_search($limit,$start,$search,$order,$dir, 'employee', "id,name,email,phone,address,status,image");

            $totalFiltered = $this->employee->item_count_search($search,  'employee');
        }
  
  		$data = array();
		if(!empty($posts)){
			$j=0;
			foreach ($posts as $post){
				$j++;
				$nestedData['id'] = $j;
				$nestedData['name'] = $post->name;
				$nestedData['email'] = $post->email;
				$nestedData['phone'] = $post->phone;
				$nestedData['address'] = $post->address;
				$nestedData['status'] = '<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
					<option value="2" '.(($post->status == 2)? 'selected="selected"' :" ").' >Deactivate </option>
					<option value="1" '.(($post->status == 1)? 'selected="selected"' :" ").'>Activate</option>
				</select>';
				$nestedData['action'] = '<button class="btn btn-primary edit" onclick="edit_func('.$post->id.')"><i class="fa fa-pencil" ></i> Edit</button>
				<a href="'.base_url('/employees/delete').'/'.$post->id.'"><button class="btn btn-danger"><i class="fa fa-remove" ></i> Delete</button></a>
				<button class="btn btn-primary edit" onclick="view_func('.$post->id.')"><i class="fa fa-pencil" ></i> View</button>
				';
				$data[] = $nestedData;
			}
		}

		$json_data = array(
		"draw"            => intval($this->input->post('draw')),  
		"recordsTotal"    => intval($totalData),  
		"recordsFiltered" => intval($totalFiltered), 
		"data"            => $data   
		);

		echo json_encode($json_data); 
	}

	public function add_employee($value='')
	{
		$data['countries'] = $this->general->get_all_country();
		$data['title'] = 'Employee Management';
		$data['page'] = 'add_employee';       
		$data['extra_datatable_data'] = $this->external->validation_extra_js_css();       
		$data['extra_datatable_data'] .= $this->external->datetimepciker();       
		$data['extra_datatable_data'] .= '<script>$("#valid_date").datetimepicker({
		        format: "DD-MM-YYYY"
		})</script>';
		$this->load->view('template',$data);
	}
	public function submit_employee(){
		try {

            $this->form_validation->set_rules('email', 'email address', 'required');
			$this->form_validation->set_rules('country_code', 'country code', 'required');
			$this->form_validation->set_rules('phone', 'phone number', 'required');
			$this->form_validation->set_rules('address', 'Address', 'required');
            if(!$this->form_validation->run()) {
                throw new Exception(validation_errors(), 1);
            }
            $info = $this->input->post(null,true);

            if(empty($_FILES) || !isset($_FILES['images']) || $_FILES['images']['error']){
                throw new Exception("Please upload image");   
            }
            $image=upload_file('images','employee');
			
            
            if(!$image){
                throw new Exception("Error in uploading image");
            }
            $info['image']='uploads/employee/'.$image;
			$result=$this->employee->add_employee($info);
			if(!$result){
				throw new Exception("Not added", 1);
			}
			redirect('/employees', 'refresh');
        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(site_url('employees/add_employee'));
        }
	}

	public function change_status($value='')
	{
		$data = $this->employee->change_status('employee', $this->input->post('status'), $this->input->post('number'));
		print_r($data);
	}

	public function delete($id = 0)
    {
        try {
            if(!$id) {
                throw new Exception('Choose a employee', 1);
            }
            $rs = $this->employee->do_delete($id);

            if(!$rs){
                throw new Exception("Error Processing Request", 1);   
            }

            $this->session->set_flashdata('success', 'Employee is deleted successfully');
            redirect(site_url('employees'));

        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(site_url('employees'));

        }
    }

    public function edit_employee(){
		echo json_encode($this->employee->get_employee($this->input->post('number')));
	}

	public function do_update_employee()
	{
		try {

            $this->form_validation->set_rules('email', 'email address', 'required');
			$this->form_validation->set_rules('country_code', 'country code', 'required');
			$this->form_validation->set_rules('phone', 'phone number', 'required');
			$this->form_validation->set_rules('address', 'Address', 'required');
            if(!$this->form_validation->run()) {
                throw new Exception(validation_errors(), 1);
            }
            $info = $this->input->post(null,true);

            if(empty($_FILES) || !isset($_FILES['image']) || $_FILES['image']['error']){
                throw new Exception("Please upload image");   
            }
            $image=upload_file('image','employee');
            if($image!=false){
	        	$info['image']='uploads/employee/'.$image;
	        }
			$result=$this->employee->update_employee($info);
			if(!$result){
				throw new Exception("Not updated", 1);
			}
			$this->session->set_flashdata('success', 'Employee updated successfully');
			redirect('/employees', 'refresh');
        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(site_url('employees'));
        }
	}
	
}