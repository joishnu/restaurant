<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Enquiries Management <small>| Enquiries section</small></h3>
      </div>
    </div>
  </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
              <ul class="nav navbar-right panel_toolbox">
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <div class="x_content">
          <form class="form-horizontal form-label-left" enctype="multipart/form-data" novalidate id="admin_update_form" method="post" action="<?=base_url('enquiries/enquiries_edit')?>" >
            <?=(isset($admins['id']))? '<input type="hidden" name="enq_id" value="'.$admins['id'].'">' :''?>
            <div class="item form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Name <span class="required">*</span></label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <input id="name" class="form-control col-md-7 col-xs-12"  name="name" placeholder="Please enter  name" required="required" type="text" value="<?=(isset($admins['name']))?$admins['name']:''?>">
              </div>
            </div>
            <div class="item form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Phone <span class="required">*</span></label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <input id="phone" class="form-control col-md-7 col-xs-12"  name="phone" placeholder="Please enter  phone" required="required" type="text" value="<?=(isset($admins['phone']))?$admins['phone']:''?>">
              </div>
            </div>
            <div class="item form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Email <span class="required">*</span></label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <input id="email" class="form-control col-md-7 col-xs-12"  name="email" placeholder="Please enter email address" required="required" type="text" value="<?=(isset($admins['email']))?$admins['email']:''?>">
              </div>
            </div>
            <div class="item form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Description <span class="required">*</span></label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <input id="description" class="form-control col-md-7 col-xs-12"  name="description" placeholder="Please enter description address" required="required" type="text" value="<?=(isset($admins['description']))?$admins['description']:''?>">
              </div>
            </div>
            <div class="ln_solid"></div>
            <div class="form-group">
              <div class="col-md-6 col-md-offset-3">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
              </div>
            </div>
          </form>
        </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- data-validate-length-range="6" data-validate-words="2"
data-validate-length-range="6" data-validate-words="2"
data-validate-length-range="6" data-validate-words="2"
data-validate-length-range="6" data-validate-words="2" -->