<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * @author Bimlesh
 *
 */
class Enquiries extends CI_Controller {
    public $active_status = array('1' => "Activate" , '2'=>"Deactivate");

	function __construct(){
		parent::__construct();
        $this->load->library('external');
		$this->load->model('enquiries_model','enquiries');
	}
    public function enquiry_list(){
        $data['title'] = 'Enquiries Management';
        $data['page'] = 'list';       
        $data['extra_datatable_data'] = $this->external->datatable_extra_js_css();       
        $data['extra_datatable_data'] .= $this->external->validation_extra_js_css();     
        $data['extra_datatable_data'] .= $this->external->datetimepciker();       
        $data['extra_datatable_data'] .= '<script type="text/javascript">
                                            $(document).ready(function (){
                                                $("#admintable").DataTable({
                                                    "processing": true,
                                                    "serverSide": true,
                                                    "ajax":{
                                                        "url": "'.base_url('enquiries/enquiries_list').'",
                                                        "dataType": "json",
                                                        "type": "POST",
                                                        "data":{
                                                          "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
                                                        }
                                                    },
                                                    "columns": [
                                                      { "data": "id" },
                                                      { "data": "name" },
                                                      { "data": "email" },
                                                      { "data": "phone" },
                                                      { "data": "description" },
                                                      { "data": "variation_id" },
                                                      {"data":"complain_status"},
                                                      { "data": "added_on" },
                                                      { "data": "status" },
                                                      { "data": "action" },

                                                    ]
                                                });
                                            });

                                            function change_status(that){
                                                var number = $(that).attr("data-number");
                                                var status = $(that).val();
                                                $.ajax({
                                                    url: "'.base_url('enquiries/change_status_enquiries').'",
                                                    data: { 
                                                        "number": number, 
                                                        "status": status
                                                    },
                                                    cache: false,
                                                    type: "POST",
                                                    success: function(response) {
                                                        console.log(response);
                                                        $("#admintable").DataTable().ajax.reload();
                                                    },
                                                    error: function(xhr) {
                                                        console.log(xhr);
                                                    }
                                                });
                                            }

                                            
                                            </script>
                                        <a href=""><button class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</button></a>


                                            ';
        $this->load->view('template',$data);
    }
    public function change_status_enquiries(){
        return $this
                ->enquiries
                ->change_status(
                    'enquiries', 
                    $this->input->post('status'), 
                    $this->input->post('number')
                );
    }

	public function enquiries_list(){
        $columns = array(
            0 => "id",
            1 => "name",
            2 => "email",
            3=>"description",
            4=>"phone",
            5=>"variation_id",
            6=>"complain_status",
            8 => "status",
            9=>"added_on"

        );

        $limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
        $totalData = $this->enquiries->table_items_count('enquiries');

        $totalFiltered = $totalData; 
        if(empty($this->input->post('search')['value'])){
        $posts = $this->enquiries->all_items($limit,$start,$order,$dir, 'enquiries', "id,name,email,description,status,phone,variation_id,complain_status,added_on");
        }else {
            $search = $this->input->post('search')['value']; 

        $posts = $this->enquiries->all_items($limit,$start,$order,$dir, 'enquiries', " id,name,email,description,status,phone,variation_id,complain_status,added_on");
            $totalFiltered = $this->enquiries->item_count_search($search,  'enquiries');
        }
        $data = array();
        if(!empty($posts)){
            foreach ($posts as $post){
                $nestedData['id'] = '';
                $nestedData['name'] = $post->name;
                $nestedData['email'] = $post->email;
                $nestedData['phone'] = $post->phone;
                $nestedData['variation_id'] = $post->variation_id;
                $nestedData['description'] = $post->description;
                $nestedData['complain_status'] = $post->complain_status;
                $nestedData['added_on'] = $post->added_on;
                $nestedData['status'] = $this->active_status[$post->status];
                $nestedData['action'] = '
              <select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
                    <option value="2" '.(($post->status == 2)? 'selected="selected"' :" ").' >Deactivate </option>
                    <option value="1" '.(($post->status == 1)? 'selected="selected"' :" ").'>Activate</option>
                </select>
                <a href="#" class=""><i class=""></i></a>
                <a href="#" class=""><i class=""></i></a>
                <a href="#" class=""><i class=""></i></a>
                <a href="#" class=""><i class=""></i></a>

                ';            
                 $data[] = $nestedData;
            }
        }

        $json_data = array(
        "draw"            => intval($this->input->post('draw')),  
        "recordsTotal"    => intval($totalData),  
        "recordsFiltered" => intval($totalFiltered), 
        "data"            => $data   
        );

        echo json_encode($json_data); 
    }


	
  
   
}