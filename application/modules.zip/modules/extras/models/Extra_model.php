<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Extra_model extends CI_Model {

    // public function emails(){
    // 	return $this->db->get('email_templates')->result_array();
    // }

    //  public function add($data){
    //     return $this->db->insert('email_templates',$data);
    // }

    // public function update($data, $id){
    //     $this->db->where('id', $id);
    //     return $this->db->update('email_templates', $data);
    // }

    // public function info($id){
    //     $this->db->where('id', $id);
    //     return $this->db->get('email_templates')->row_array();
    // }

    public function table_items_count($table){
        $query = $this->db->get($table);
        return $query->num_rows();
    }

    public function all_items($limit,$start,$col,$dir, $table, $select = '*'){
        $this->db->select($select);
   
        $query = $this->db
                ->limit($limit,$start)
                ->order_by($col,$dir)
                ->get($table);

        if($query->num_rows()>0)
            return $query->result(); 
        else
            return null;
        
    }


    public function all_items_enquery($limit,$start,$col,$dir){
        $this->db->select('e.id,e.name,e.email,e.description,e.status,e.phone,e.variation_id,e.complain_status,e.added_on, products.name as pro_name');
        $this->db->join('variations', 'variations.id = e.variation_id');
        $this->db->join('products', 'variations.product_id = products.id ');
        $query = $this->db
                ->limit($limit,$start)
                ->order_by($col,$dir)
                ->get('enquiries as e');

        if($query->num_rows()>0)
            return $query->result(); 
        else
            return null;
    }

    public function all_items_enquery_search($limit,$start,$search,$col,$dir){
        $this->db->select('e.id,e.name,e.email,e.description,e.status,e.phone,e.variation_id,e.complain_status,e.added_on, products.name as pro_name');
        $this->db->join('variations', 'variations.id = e.variation_id');
        $this->db->join('products', 'variations.product_id = products.id ');
        $query = $this->db
            ->like('e.name',$search)
            ->or_like('e.email',$search)
            ->or_like('e.description',$search)
            ->or_like('products.name',$search)
            ->limit($limit,$start)->get('enquiries as e');
        if($query->num_rows()>0)
            return $query->result(); 
        else
            return null;
    }

    function item_search($limit,$start,$search,$col,$dir, $table, $select='*'){
        $this->db->select($select);
        $query = $this->db
            ->like($table.'.id',$search)
            ->or_like('name',$search)
            ->or_like('email',$search)
            ->or_like('phone',$search)
            ->or_like('subject',$search)
            ->or_like('description',$search)
            ->limit($limit,$start)->order_by($table.'.'.$col,$dir)->get($table);
        
       
        if($query->num_rows()>0)
            return $query->result();  
        else
            return null;
    }

    function item_count_search($search, $table){

        $query = $this->db
                ->like('id',$search)
                ->or_like('address',$search)
                ->get($table);
        return $query->num_rows();
    } 

    function change_status($table, $status, $id_value, $field_change = 'status', $id_field = 'id'){
        $this->db->where($id_field, $id_value);
        $this->db->update($table, array($field_change=> $status));
    }

    public function getdata($table){
        return $this->db->get($table)->result_array();
    }

    public function edit_social_result($id=""){
        $this->db->select("*");
        $this->db->from("social_links");
        $return=$this->db->get()->row_array();
        return $return ;
    }
    public function do_update($params) {
        try { 
            $this->db->trans_begin();
            $where = array(
                'id' => $params['social_id']
            );
                $update_data = array(
                'title' => $params['title'],
                'description' => $params['description']
            );
            if(!$this->db->update('social_links', $update_data, $where)) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return TRUE;
            
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return FALSE;
        }
    }


    public function get_cms($slug){
        $this->db->where('sulg', $slug);
        return $this->db->get('cms')->row_array();
    }

    public function updatecms($id, $title, $desc){
        
        $this->db->where('id', $id);
        return $this->db->update('cms', array( 'title' => $title,  'description' => $desc));
    }
} 
?>