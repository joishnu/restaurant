<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
      </div>
    </div>
  </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Edit Social Links<small></small></h2>
            <ul class="nav navbar-right panel_toolbox">
              <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
              <li><a class="close-link"><i class="fa fa-close"></i></a></li>
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
      <form method="post" id="formProfile"  action="<?=site_url('extras/social_update');?>" class="form-horizontal">
         <input type="hidden" name="social_id" value="<?=$list['id'];?>">
              <span class="section">Edit Social Links</span>
              <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Title <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input id="title" class="form-control col-md-7 col-xs-12" data-validate-length-range="4" data-validate-words="1" name="title" placeholder="Please enter title" required="required" type="text" value="<?php echo$list['title'];?>">
                </div>
              </div>
                  <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Link <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input id="link" class="form-control col-md-7 col-xs-12" data-validate-length-range="4" data-validate-words="1" name="link" placeholder="Please enter link" required="required" type="text" value="<?php echo$list['link'];?>">
                </div>
              </div>
              <div class="item form-group">
                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Description <span class="required">*</span></label>
                <div class="col-md-6 col-sm-6 col-xs-12">
                  <input id="description" class="form-control col-md-7 col-xs-12" data-validate-length-range="4" data-validate-words="1" name="description" placeholder="Please enter  description" required="required" type="text" value="<?php echo$list['description'];?>">
                </div>
              </div>
              <div class="ln_solid"></div>
              <div class="form-group">
                <div class="col-md-6 col-md-offset-3">
                  <button type="submit" class="btn btn-primary">Cancel</button>
                  <button id="send" type="submit" class="btn btn-success">Submit</button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

