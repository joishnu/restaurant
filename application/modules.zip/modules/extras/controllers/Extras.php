<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * 
 */
class Extras extends CI_Controller{
	
	function __construct(){
		parent::__construct();
		$this->load->library('external');
		$this->load->model('extra_model', 'extra');
	}

	/*         enquiries           */
	public function enquiries(){
		$data['title'] = 'Enquiries Management';
        $data['page'] = 'list';       
        $data['extra_datatable_data'] = $this->external->datatable_extra_js_css();
        $data['extra_datatable_data'] .= '
        	<script type="text/javascript">
        		$(document).ready(function (){
        			$("#admintable").DataTable({
        				"processing": true,
        				"serverSide": true,
        				"ajax":{
        					"url": "'.base_url('extras/enquiries_list').'",
        					"dataType": "json",
							"type": "POST",
							"data":{
							"'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
							}
						},
						"columns": [
							{ "data": "id" },
							{ "data": "name" },
							{ "data": "email" },
							{ "data": "phone" },
							{ "data": "description" },
							{ "data": "variation_id" },
							{"data":"complain_status"},
							{ "data": "added_on" },
							{ "data": "action" },
						]
					});
				});

				function change_status(that){
					var number = $(that).attr("data-number");
					var status = $(that).val();
					$.ajax({
						url: "'.base_url('extras/change_status_enquery').'",
						data: { 
							"number": number, 
							"status": status
						},
						cache: false,
						type: "POST",
						success: function(response) {
							console.log(response);
							$("#admintable").DataTable().ajax.reload();
						},
						error: function(xhr) {
							console.log(xhr);
						}
					});
				}
			</script>';
        $this->load->view('template',$data);	
	}

	public function enquiries_list(){
        $columns = array(
            0 => "id",
            1 => "name",
            2 => "email",
            3=>"description",
            4=>"phone",
            5=>"variation_id",
            6=>"complain_status",
            8=>"added_on"

        );

        $limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];

        $totalData = $this->extra->table_items_count('enquiries');

        $totalFiltered = $totalData; 
        if(empty($this->input->post('search')['value'])){
        $posts = $this->extra->all_items_enquery($limit,$start,$order,$dir);
        }else {
            $search = $this->input->post('search')['value']; 

        $posts = $this->extra->all_items_enquery_search($limit,$start,$search,$order,$dir);
            
        }

        $data = array();
        if(!empty($posts)){
            foreach ($posts as $post){
                $nestedData['id'] = '';
                $nestedData['name'] = $post->name;
                $nestedData['email'] = $post->email;
                $nestedData['phone'] = $post->phone;
                $nestedData['variation_id'] = $post->pro_name;
                $nestedData['description'] = $post->description;
                $nestedData['complain_status'] = ($post->complain_status == 1)?"Request" : "Fixed";
                $nestedData['added_on'] = $post->added_on;
                $nestedData['action'] = '
              <select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
                    <option value="1" '.(($post->complain_status == 1)? 'selected="selected"' :" ").' >Requested </option>
                    <option value="2" '.(($post->complain_status == 2)? 'selected="selected"' :" ").'>Fixed</option>
                </select>
                ';            
                 $data[] = $nestedData;
            }
        }

        $json_data = array(
        "draw"            => intval($this->input->post('draw')),  
        "recordsTotal"    => intval($totalData),  
        "recordsFiltered" => intval($totalFiltered), 
        "data"            => $data   
        );

        echo json_encode($json_data); 
    }

    public function change_status_enquery(){
    	return $this->extra
    				->change_status(
    					'enquiries', 
    					$this->input->post('status'),
    					$this->input->post('number'),
    					'complain_status' 
    				);
    }

    /*         Contact           */
    public function contact(){
    	$data['title'] = 'Contact us Management';
        $data['page'] = 'list_contact';       
        $data['extra_datatable_data'] = $this->external->datatable_extra_js_css();
        $data['extra_datatable_data'] .= '
        	<script type="text/javascript">
        		$(document).ready(function (){
        			$("#admintable").DataTable({
        				"processing": true,
        				"serverSide": true,
        				"ajax":{
        					"url": "'.base_url('extras/contact_list').'",
        					"dataType": "json",
							"type": "POST",
							"data":{
							"'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
							}
						},
						"columns": [
							{ "data": "id" },
							{ "data": "name" },
							{ "data": "email" },
							{ "data": "phone" },
							{ "data": "subject" },
							{ "data": "description" },
							{ "data": "action" },
						]
					});
				});


				function change_status(that){
					var number = $(that).attr("data-number");
					var status = $(that).val();
					$.ajax({
						url: "'.base_url('extras/change_status_contact').'",
						data: { 
							"number": number, 
							"status": status
						},
						cache: false,
						type: "POST",
						success: function(response) {
							console.log(response);
							$("#admintable").DataTable().ajax.reload();
						},
						error: function(xhr) {
							console.log(xhr);
						}
					});
				}
			</script>';
        $this->load->view('template',$data);
    }

    public function contact_list(){
        $columns = array(
            0 => "id", 
            1 => "name", 
            2 => "email", 
            3 => "phone", 
            4 => "subject", 
            5 => "description", 
            6 => "action", 

        );

        $limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];

        $totalData = $this->extra->table_items_count('contact_us');

        $totalFiltered = $totalData; 
        if(empty($this->input->post('search')['value'])){
        $posts = $this->extra->all_items($limit,$start,$order,$dir, 'contact_us');
        }else {
            $search = $this->input->post('search')['value']; 

        $posts = $this->extra->item_search($limit,$start,$search,$order,$dir, 'contact_us');
            
        }

        $data = array();
        if(!empty($posts)){
            foreach ($posts as $post){
                $nestedData['id'] = '';
                $nestedData['name'] = $post->name;
                $nestedData['email'] = $post->email;
                $nestedData['phone'] = $post->phone;
                $nestedData['subject'] = $post->subject;
                $nestedData['description'] = $post->description;
                $nestedData['action'] = '
              <select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
                    <option value="1" '.(($post->is_read == 1)? 'selected="selected"' :" ").' >New </option>
                    <option value="2" '.(($post->is_read == 2)? 'selected="selected"' :" ").'>Checked</option>
                </select>
                ';            
                 $data[] = $nestedData;
            }
        }

        $json_data = array(
        "draw"            => intval($this->input->post('draw')),  
        "recordsTotal"    => intval($totalData),  
        "recordsFiltered" => intval($totalFiltered), 
        "data"            => $data   
        );

        echo json_encode($json_data); 
    }


    public function change_status_contact(){
    	return $this->extra
    				->change_status(
    					'contact_us', 
    					$this->input->post('status'),
    					$this->input->post('number'),
    					'is_read'
    				);
    }


    public function social(){
    	$data['title'] = 'Social Links';
		$data['page'] = 'social_list';       
        $data['list']=$this->extra->getdata('social_links');
		$this->load->view('template',$data);
    }

    public function social_edit($id=""){
        $data['title'] = 'Edit Social Links';
        $data['page'] = 'social_edit';       
        $data['list']=$this->extra->edit_social_result($id);
        $this->load->view('template',$data);
    }

    public function social_update(){
        $this->form_validation->set_rules('title','title','required'); 
        $this->form_validation->set_rules('description','description','required');    
        $info=$this->input->post(NULL,true);

        $result=$this->extra->do_update($info);

        if ($result) {
            redirect(site_url('extras/social'));
        }
         else {
            redirect(site_url('extras/social_edit/'.$info['social_id']));
        }
    }

    public function privacy(){
    	$data['title'] = 'privacy';
        $data['page'] = 'privacy';       
        $data['info']=$this->extra->get_cms('privacy_policy');
        $data['extra_datatable_data'] = $this->external->textarea();       
		$data['extra_datatable_data'] .= '
			<script type="text/javascript">
				function uploadValueToText() {
					var val = $("#editor-one").html();
					$("#descr").val(val);
				}
			</script>';
        $this->load->view('template',$data);	
    }

    public function terms(){
    	$data['title'] = 'terms and conditions';
        $data['page'] = 'terms';       
        $data['info']=$this->extra->get_cms('terms');
        $data['extra_datatable_data'] = $this->external->textarea();       
		$data['extra_datatable_data'] .= '
			<script type="text/javascript">
				function uploadValueToText() {
					var val = $("#editor-one").html();
					$("#descr").val(val);
				}
			</script>';
        $this->load->view('template',$data);	
    }

    public function about(){
    	$data['title'] = 'About Us';
        $data['page'] = 'about';       
        $data['info']=$this->extra->get_cms('about_us');
        $data['extra_datatable_data'] = $this->external->textarea();       
		$data['extra_datatable_data'] .= '
			<script type="text/javascript">
				function uploadValueToText() {
					var val = $("#editor-one").html();
					$("#descr").val(val);
				}
			</script>';
        $this->load->view('template',$data);	
    }

    public function contactus(){
    	$data['title'] = 'contact Us';
        $data['page'] = 'contact';       
        $data['info']=$this->extra->get_cms('contact_us');
        $data['extra_datatable_data'] = $this->external->textarea();       
		$data['extra_datatable_data'] .= '
			<script type="text/javascript">
				function uploadValueToText() {
					var val = $("#editor-one").html();
					$("#descr").val(val);
				}
			</script>';
        $this->load->view('template',$data);	
    }

    public function updatecms(){
    	$this->form_validation->set_rules('title','title','required');
    	$this->form_validation->set_rules('descr','descr','required');
    	$this->extra->updatecms($this->input->post('cms_id'), $this->input->post('title'), $this->input->post('descr'));
    	 redirect('/extras/'.$this->input->post('page_name'), 'refresh');
    }

    




}
?>