<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Offers_model extends CI_Model {

    public function get_vendor()
    {
        if($this->session->userdata('user_type') != 1){
            $this->db->where('id', $this->session->userdata('id'));
            $this->db->where('user_type', 2);
        }else{
            $this->db->where('user_type', 2);
        }
        $this->db->select('id,CONCAT(users.first_name," ",users.last_name) as name');
        $result = $this->db->get('users')->result_array();
        return $result;
    }
    public function get_subscription_plan()
    {
        $this->db->select('*');
        $result = $this->db->get('subscription')->result_array();
        return $result;
    }
    //public function get_product_list($params = [], $vendor,  $page = 1, $per_page = 10)
    public function get_product_list($id)
    {     
        
        $variation_info=$this->db->select('product_id')->where('id', $id)->get('offers')->row_array();

        $variation_id=explode(',', $variation_info['product_id']);

        $this->db->select('variations.id as product_id, products.name,variations.id variation_id,variations.name,variations.amount,variations.offer_value,CONCAT("'.base_url('uploads/product_gallery/').'",variations.image) image');
        $this->db->join('variations', 'variations.product_id = products.id', 'right');
        //$this->db->where('products.vendor_id', $vendor);
        //$this->db->where_in('variations.id',$variation_id);
        $this->db->where('products.status',1);
        $this->db->order_by('products.id', 'desc');
        $result = $this->db->get('products')->result_array();
        foreach ($result as $key => $value) {
            $result[$key]['percent'] = number_format(($value['amount']-$value['offer_value'])/$value['amount']*100,0);
        }
        return $result;
    }


    public function add_offer($data)
    {
        $insert_data = array(
            'offer_name'=>$data['offer_name'],
           // 'vendor_id' => $data['vendor'],
            'user_type'=>$data['user_type'],
            'user_id' => implode(",", $data['customer']),
            'product_id'=>implode(",", $data['product']),
            'actual_amount'=>$data['actual_amount'],
            'discount_val'=>$data['discount_val'],
            'offer_amount_type'=>$data['offer_amount_type'],
            'amount' => $data['offer_amount'],
            'rank' => $data['rank'],
            'image' => $data['image'],
            'status' => 1,
            'created_on' => date('Y-m-d H:i;s')
        );
        if(isset($data['subscription_type'])){
            $insert_data['subscription_plan'] = $data['subscription_type'];
        }
        $this->db->insert('offers', $insert_data);
        if($this->db->affected_rows()){
            $this->db->select('device_id');
            $this->db->where("id in (".implode(",", $data['customer']).")");
            $rs=$this->db->get('users')->result_array();
            $device_id = array_column($rs,'device_id');
            foreach ($data['customer'] as $key => $value) {
                $insert_data = array(
                    'user_id' => $value,
                    'user_type'=>1,
                    'title'   => $data['offer_name'],
                    'message' => "You Have new offers from MAHWUM.",
                    'message_read'=>0,
                    'status'=>1,
                    'added_on'=>date('Y-m-d H:i:s'),
                    'notification_type'=>1
                );
                $this->db->insert('notification', $insert_data);
            }
            return $device_id;
        }else{
            return false;
        }
    }

    public function get_offer()
    {
        $user_type = $this->session->userdata('user_type');
        if($user_type !=1){
            $this->db->where('vendor_id', $user_type);
        }
        $this->db->select('offers.*,CONCAT(users.first_name," ",users.last_name) as vendor_name');
        $this->db->join('users', 'users.id = offers.vendor_id', 'left');
        $this->db->where('offers.status !=',3);
        $result = $this->db->get('offers')->result_array();
        //show($result);
        if($result){
            foreach ($result as $key => $value) {
                $value['product_id'] = explode(",", $value['product_id']);
                $value['user_id'] = explode(",", $value['user_id']);
                $result[$key] = $value;
            }
            foreach ($result as $keys => $values) {
                //echo "<pre>";print_r($values);
                if($values['subscription_plan'] !=0){
                    $this->db->select('name');
                    $this->db->where('id', $values['subscription_plan']);
                    $values['plan_name']=$this->db->get('subscription')->row('name');
                }
                foreach ($values['product_id'] as $key => $value) {
                    $this->db->select('products.name');
                    $this->db->join('products', 'products.id = variations.product_id', 'left');
                    $this->db->where('variations.id', $value);
                    $values['product'][]=$this->db->get('variations')->row_array();

                }foreach ($values['user_id'] as $key => $value) {
                    $this->db->select('id,CONCAT(users.first_name," ",users.last_name) as customer_name');
                    $this->db->where('id', $value);
                    $values['customer'][]=$this->db->get('users')->row_array();
                }

                $result[$keys]=$values;
                unset($result[$keys]['product_id']);
                unset($result[$keys]['user_id']);
            }
        }
        
        return $result;
    }

    public function change_status($table,$status,$id)
    {
        try {
            $this->db->trans_begin();
            $where= array('id' => $id );
            $update_data = array(
                'status' =>$status,
                'updated_on'=>date('Y-m-d H:i:s')
            );
            $result = $this->db->update('offers', $update_data, $where);
            if(!$result)
            {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function do_delete($id)
    {   
        $this->db->set('status',3);
        $this->db->where('id', $id);
        $result = $this->db->update('offers');
        return $result;
    }

    public function get_offer_details($id)
    {
        $this->db->select('*');
        $this->db->where('id', $id);
        $result = $this->db->get('offers')->row_array();
        if($result){
            $result['product_id'] = explode(",", $result['product_id']);
            $result['user_id'] = explode(",", $result['user_id']);
        }
        return $result;
    }

    public function update_offer($data)
    {   
        try{
            
            $this->db->select('image');
            $this->db->where('id', $data['id']);
            $last_img = $this->db->get('offers')->row('image');

            if(empty($_FILES) || !isset($_FILES['image']) || $_FILES['image']['error']){
                $data['image'] = $last_img;
            }else{
                $image=upload_file('image','offer');
                if(!$image){
                    throw new Exception("Error in uploading image");
                }
                $data['image']='uploads/offer/'.$image;
            }          
            
            $update_data = array(
               // 'vendor_id' => $data['vendor'],
                'user_type'=>$data['user_type'],
                'user_id' => implode(",", $data['customer']),
                'product_id'=>implode(",", $data['product']),
                'actual_amount'=>$data['actual_amount'],
                'discount_val'=>$data['discount_val'],
                'offer_amount_type'=>$data['offer_amount_type'],
                'amount' => $data['offer_amount'],
                'rank' => $data['rank'],
                'image' => $data['image'],
                'updated_on' => date('Y-m-d H:i;s')
            );

            if(isset($data['subscription_type'])){
                $update_data['subscription_plan'] = $data['subscription_type'];
            }

            $this->db->where('id', $data['id']);
            $this->db->update('offers', $update_data);
            $rs=$this->db->affected_rows();
            if(!$rs){
                throw new Exception("Error Processing Request", 1);
            }
            $response['status']=true;
        }catch(Exception $e){
            $response['status'] = false;
            $response['message'] = $e->getMessage();
        }
        return $response;
    }

    public function get_cutomer_list($data)
    {   

        if($data['type'] == 1){
            $this->db->select('id,CONCAT(first_name," ",last_name) as name');
            $this->db->where('user_type', 3);
            $this->db->where('status', 1);
            $result = $this->db->get('users')->result_array();
        }else{
            $this->db->select('u.id,CONCAT(u.first_name," ",u.last_name) as name');
            $this->db->join('users u', 'u.id = su.user_id', 'left');
            $this->db->where('u.status', 1);
            $this->db->where('su.subscription_id', $data['subscription_type']);
            $result = $this->db->get('subscribe_user su')->result_array();
        }
        return $result;
    }

    public function get_variation_list(){
        $this->db->select('variations.id, variations.name, variations.serial_no, variations.amount');
        $this->db->join('variations', 'variations.product_id = products.id', 'right');
        $this->db->where('products.status',1);
        $this->db->order_by('products.id', 'desc');
        $result = $this->db->get('products')->result_array();
        return $result;
    }
}