<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3><?php echo $title;?></small></h3>
            </div>
        </div>
        <div class="title_right">
            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search" style="text-align: right">
            </div>
        </div>
    </div>
    <?php $this->load->view('includes/show_flashdata'); ?>   
    <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Offer List</h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <!-- <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                            <li><a class="close-link"><i class="fa fa-close"></i></a></li> -->
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <p class="text-muted font-13 m-b-30"><!-- If you want to write somting you can write here --></p>
                        <table id="offerlist" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Offer Name</th>
                                    <th>Vendor Name</th>
                                    <th>User Type</th>
                                    <th>Users</th>
                                    <th>Product Name</th>
                                    <th>Actual Price</th>
                                    <th>Offer Price</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($offers as $key => $value): ?>
                                <tr data-id="<?=$value['id'];?>">
                                    <td><?=$key+1;?></td>
                                    <td><?=$value['offer_name'];?></td>
                                    <td><?php echo $value['vendor_name'];?></td>
                                    <td><?php 
                                        if($value['user_type']==1) {
                                            echo "Normal";
                                        }else echo "Subscribe User :".$value['plan_name'];?>
                                    </td>
                                    <td><ul><?php foreach($value['customer'] as $customer){?>
                                            <li><?php echo $customer['customer_name'];?></li>
                                        <?php }?></ul>
                                    </td>
                                    <td><ul><?php foreach($value['product'] as $product){?>
                                            <li><?php echo $product['name'];?></li>
                                        <?php }?></ul>
                                    </td>
                                    <td><?php echo $value['actual_amount'];?></td>
                                    <td><?php echo $value['amount'];?></td>
                                    <td>
                                        <select class="btn btn-primary" data-number="<?php echo $value['id'];?>" onchange="return change_status(this)">
                                            <option value="2" <?php if($value['status']==2) echo "selected"?>>Deactivate </option>
                                            <option value="1" <?php if($value['status']==1) echo "selected"?>>Activate</option>
                                        </select>
                                    </td>
                                    <td>
                                        <?php //if(in_array("edit_role", $permission['_permissions'])){?>
                                            <a class="btn btn-primary" href="<?=site_url('offers/edit/'.$value['id']);?>"><i class="fa fa-pencil"></i> Edit</a>
                                        <?php //}if(in_array("delete_role", $permission['_permissions'])){?>
                                            <a href="<?=site_url('offers/delete/'.$value['id']);?>"><button class="btn btn-danger"><i class="fa fa-remove" ></i> Delete</button></a>
                                        <?php //}?>
                                    </td>

                                </tr>
                            <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function (){
        $("#offerlist").DataTable();
    });

    function change_status(that){
        var number = $(that).attr("data-number");
        var status = $(that).val();
        $.ajax({
            url: "<?php echo base_url('offers/change_status');?>",
            data: { 
                "number": number, 
                "status": status
            },
            cache: false,
            type: "POST",
            success: function(response) {
                //console.log(response);
                location.reload();
                //$("#offerlist").DataTable().ajax.reload();
            },
            error: function(xhr) {
                
            }
        });
    }
</script>