<style type="text/css">
    fieldset {
  overflow: hidden
}

.some-class {
  float: left;
  clear: none;
}

label {
  float: left;
  clear: none;
  display: block;
  padding: 2px 1em 0 0;
}

input[type=radio],
input.radio {
  float: left;
  clear: none;
  margin: 2px 0 0 2px;
}
</style>
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3><?php echo $title;?></h3>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <?php $this->load->view('includes/show_flashdata'); ?>   
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2><?php echo $title;?></h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="x_content">
                        <form class="form-horizontal form-label-left" enctype="multipart/form-data" novalidate id="admin_update_form" method="post" action="<?=base_url('offers/do_add_offers')?>" data-toggle="validator" data-disable="false">
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Offer Name<span class="required">*</span></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input class="form-control col-md-7 col-xs-12"  name="offer_name" placeholder="Please enter name" required="required" type="text" value="">
                                </div>
                                <!-- <div class="help-block with-errors"></div> -->
                            </div>
                            <div class="item form-group">
                               <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">User Type<span class="required">*</span></label>
                                <div class="some-class">
                                    <input type="radio" class="radio user_type" name="user_type" value="1" required="" />
                                    <label for="y"> Normal User</label>
                                    <input type="radio" class="radio user_type" name="user_type" value="2" required="" />
                                    <label for="z"> Subscribe User</label>
                                </div>
                                <div class="help-block with-errors"></div>
                            </div>
                            <div class="item form-group sub" style="display: none">
                               <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Subscription Type<span class="required">*</span></label>
                                <div class="some-class">
                                    <?php foreach($subscription as $key => $value){?>
                                        <input type="radio" class="radio user_type" name="subscription_type" value="<?php echo $value['id'];?>" required/>
                                        <label for="y"><?php echo $value['name'];?></label>
                                    <?php }?>
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Customer<span class="required">*</span></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select class="form-control select2 product" name="customer[]" multiple="" required id="customer_list">
                                    </select>
                                    <div class="help-block with-errors"></div>
                                </div>
                                <input type="checkbox" class="radio" id="checkbox"/>
                                <!-- <input type="checkbox" id="checkbox"> -->
                                <label for="z">Select All</label>
                            </div>
                         <!--    <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Select Vendor<span class="required">*</span></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select class="form-control select2 product" name="vendor"  required>
                                        <option></option>
                                        <?php foreach($vendor as $value): ?>
                                            <option value="<?=$value['id'];?>"><?=$value['name'];?></option>
                                        <?php endforeach; ?>
                                   </select>
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div> -->
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Product<span class="required">*</span></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                   <select class="form-control select2 product" name="product[]" multiple="" required id="product_list">
                                   <?php $cnt=count($product_list); for($i=0;$i<=$cnt-1;$i++) {?>
                                       <option value="<?php echo $product_list[$i]['id'];?>"  data-amount="<?php echo $product_list[$i]['amount'];?>" ><?php echo $product_list[$i]['serial_no'].'-'.$product_list[$i]['name'];?></option>
                                   <?php } ?>
                                   </select>
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> Actual Amount<span class="required">*</span></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input class="form-control col-md-7 col-xs-12"  name="actual_amount" placeholder="Please enter amount" id="actual_amount" required="required" type="text" readonly="">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> Offer Amount Type<span class="required">*</span></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                   <select class="form-control select2" name="offer_amount_type" required id="offer_amount_type">
                                    <option value="1">%</option>
                                    <option value="2">Amount</option>
                                   </select> 
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> Discount Value<span class="required">*</span></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input class="form-control col-md-7 col-xs-12"  name="discount_val" placeholder="Please enter" required="required" type="text" value="" id="discount_val">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> Final Offer Amount<span class="required">*</span></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input class="form-control col-md-7 col-xs-12"  name="offer_amount" placeholder="Please enter amount" type="text" value="" readonly="">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"> Rank<span class="required">*</span></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input class="form-control col-md-7 col-xs-12"  name="rank" placeholder="Please enter amount" required="required" type="text" value="">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Image<span class="required">*</span></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="images" class="form-control col-md-7 col-xs-12" name="images" placeholder="Please upload profile picture"  type="file" required="">
                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-6 col-md-offset-3">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script type="text/javascript">
    function offer_amount_cal()
    {
        var origin=parseFloat( $('#actual_amount').val());
        if($('#offer_amount_type').val()==1){
            var rs_tmp=(origin/100)*$('#discount_val').val();    
            var rs=origin-rs_tmp;
        }
        else
        {
            var rs=origin-$('#discount_val').val();    
        }
        
        $('[name=offer_amount]').val(rs);
    }

    $(".product").select2({
        width: "resolve" 
    });

    $('.user_type').click(function() {
        var type = $('input[name=user_type]:checked').val(); 
        $("#customer_list option").remove();
        if(type == 1){
            $(".sub").css("display", "none");
            $('input[name="subscription_type"]').removeAttr("required","false");
            var data = {type:type}
        }else{
            $(".sub").css("display", "block");
            $('input[name="subscription_type"]').attr("required","true");
            var subscription_type = $('input[name=subscription_type]:checked').val(); 
            var data = {type:type,subscription_type:subscription_type}
        }
        $.ajax({
            url:"<?php echo base_url();?>"+'offers/customer_list',
            data:data, 
            cache: false,
            type: "GET",
            dataType: 'json',
            success: function(result) {
               console.log(result);
               $str = '';
                $.each(result.data, function(index, value){
                    $str += '<option value="'+value.id+'">'+value.name+'</option>';
                });
                $('#customer_list').append($str);
            },
            error: function(xhr) {
                
            }
        });

    });

    /*$('[name=vendor]').on('change', function(e){
        var vendor = $(this).val();
        $("#product_list option").remove();
        $.ajax({
            url:"<?php echo base_url();?>"+'offers/list_products',
            data:{vendor: vendor}, 
            cache: false,
            type: "GET",
            dataType: 'json',
            success: function(result) {
               console.log(result);
               $str = '';
                $.each(result.data, function(index, value){
                    $str += '<option data-amount="'+value.amount+'" value="'+value.product_id+'">'+value.name+"-"+value.amount+" Rs"+'</option>';
                });
                $('#product_list').append($str);
            },
            error: function(xhr) {
                
            }
        });
    });*/

    $("#checkbox").click(function(){
        if($("#checkbox").is(':checked') ){
            $("#customer_list > option").prop("selected","selected");
            $("#customer_list").trigger("change");
        }else{
            $("#customer_list > option").removeAttr("selected");
            $("#customer_list").trigger("change");
        }
    });

    $("#product_list").on("change",function(){
        var countries = [];
        var total = 0;
        $.each($("#product_list option:selected"), function(){            
            total = parseFloat(total)+parseFloat($(this).attr('data-amount'));
            //countries.push($(this).attr('data-amount'));
        });
        $('#actual_amount').val(total);
        //alert(total);
    });

    $("#discount_val").on("keyup",function(){
      offer_amount_cal();
    });

    $("#offer_amount_type").on("change",function(){
      offer_amount_cal();
    });

</script>