<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Offers extends MX_Controller {
	function __construct()
	{
		parent::__construct();
        $controller_name = $this->uri->segment(1);  
        
        $this->load->library('external');
		$this->load->model('offers_model','offer');
	}
	
	public function index(){
		$data['title'] = 'Offers';
        $data['offers'] = $this->offer->get_offer();
		$data['page'] = 'index';
        $data['extra_datatable_data'] = $this->external->datatable_extra_js_css();
        $this->load->view('template', $data);
	}
    
	public function add()
    {
        $data['title'] = 'Offers';
        $data['vendor'] = $this->offer->get_vendor();
        $data['subscription'] = $this->offer->get_subscription_plan();
        $data['product_list'] = $this->offer->get_variation_list();

        $data['page'] = 'add';
        $data['extra_datatable_data'] = $this->external->validation_extra_js_css();
        $this->load->view('template', $data);
    }

    public function list_products() {

        if(!$this->input->is_ajax_request()) {show_404();}
        $vendor = $this->input->get('vendor');
        $products = $this->offer->get_product_list(array('show_all' => true, 'filter' => [], 'search' => $this->input->get('search')), $vendor, false);
        echo json_encode(['status' => true, 'data' => $products, 'message' => "Select a Product"]);
    }

    public function do_add_offers()
    {
        try{
            $post_data =$this->input->post();
            $this->form_validation->set_rules('offer_name', 'Offer Name', 'trim|required');
            //$this->form_validation->set_rules('vendor', 'Vendor', 'trim|required');
            $this->form_validation->set_rules('product[]', 'Product', 'trim|required');
            $this->form_validation->set_rules('rank', 'Rank', 'trim|required');
            $this->form_validation->set_rules('offer_amount', 'Offer Amount', 'trim|required');
            $this->form_validation->set_rules('user_type', 'User Type', 'trim|required');
            $this->form_validation->set_rules('customer[]', 'Customer', 'trim|required');
            if($post_data['user_type'] == 2){
                $this->form_validation->set_rules('subscription_type', 'Subscription type', 'trim|required');
            }
            if(!$this->form_validation->run()) {
                throw new Exception(validation_errors(), 1);
            }
            if(empty($_FILES) || !isset($_FILES['images']) || $_FILES['images']['error']){
                throw new Exception("Please upload image"); 
            }
            $image=upload_file('images','offer');
            if(!$image){
                throw new Exception("Upload a file with extension gif|jpg|png|jpeg|bmp|pdf|doc|docx");
            }
            
            $post_data['image']='uploads/offer/'.$image;

            $result = $this->offer->add_offer($post_data);
            if(!$result){
                throw new Exception("Error Processing Request", 1);
            }

            $this->load->library('fcm');
            $this->fcm->set_title("Mahwum:Offers");
            $this->fcm->set_image(base_url('/assets/img/logo.png'));
            $this->fcm->set_message("You Have new offers");
            $this->fcm->add_multiple_recipients($result);
            $res1 = $this->fcm->send();
            $this->session->set_flashdata('success', "Added Successfully");
            redirect(base_url('offers'));
        }catch(Exception $e){
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(base_url('offers/add'));
        }
    }

    public function change_status(){
        $post_data = $this->input->post();
        $data = $this->offer->change_status('offers', $this->input->post('status'), $this->input->post('number'));
        print_r($data);
    }

    public function delete($id = 0)
    {
        try {
            if(!$id) {
                throw new Exception('Choose a Offer', 1);
            }
            $rs = $this->offer->do_delete($id);

            if(!$rs){
                throw new Exception("Error Processing Request", 1);   
            }

            $this->session->set_flashdata('success', 'Offer is deleted successfully');
            redirect(site_url('offers'));

        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(site_url('offers'));

        }
    }

    public function edit($id)
    {   
        $data['title'] = 'Offers';
        $data['vendor'] = $this->offer->get_vendor();
        $data['page'] = 'edit';
        $data['offer_detail'] = $this->offer->get_offer_details($id);
        $data['extra_datatable_data'] = $this->external->validation_extra_js_css();
        //$data['products'] = $this->offer->get_product_list(array('show_all' => true, 'filter' => [], 'search' => $this->input->get('search')), $data['offer_detail']['vendor_id'], false);
        $data['products'] = $this->offer->get_product_list($id);
        $send_data['type'] = $data['offer_detail']['user_type'];
        if($data['offer_detail']['user_type'] == 2){
            $send_data['subscription_type'] = $data['offer_detail']['subscription_plan'];
        }
        $data['customer'] = $this->offer->get_cutomer_list($send_data);
        $data['subscription'] = $this->offer->get_subscription_plan();
        $this->load->view('template', $data);
    }

    public function do_update_offers()
    {
        try{
            $post_data =$this->input->post();
            $this->form_validation->set_rules('offer_name', 'Offer Name', 'trim|required');
            //$this->form_validation->set_rules('vendor', 'Vendor', 'trim|required');
            $this->form_validation->set_rules('product[]', 'Product', 'trim|required');
            $this->form_validation->set_rules('rank', 'Rank', 'trim|required');
            $this->form_validation->set_rules('offer_amount', 'Offer Amount', 'trim|required');
            //$this->form_validation->set_rules('images', 'Image', 'trim|required');
            $this->form_validation->set_rules('user_type', 'User Type', 'trim|required');
            $this->form_validation->set_rules('customer[]', 'Customer', 'trim|required');
            if($post_data['user_type'] == 2){
                $this->form_validation->set_rules('subscription_type', 'Subscription type', 'trim|required');
            }
            if(!$this->form_validation->run()) {
                throw new Exception(validation_errors(), 1);
            }
            $result = $this->offer->update_offer($post_data);
            if(!$result['status']){
                throw new Exception($result['message'], 1);
            }
            $this->session->set_flashdata('success', "Updated Successfully");
            redirect(base_url('offers'));
        }catch(Exception $e){
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(base_url('offers/edit/'.$post_data['id']));
        }
    }

    public function customer_list()
    {
        if(!$this->input->is_ajax_request()) {show_404();}
        $customer = $this->offer->get_cutomer_list($this->input->get());
        echo json_encode(['status' => true, 'data' => $customer, 'message' => "Select a Product"]);
    }
}