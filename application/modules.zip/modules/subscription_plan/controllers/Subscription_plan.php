<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Subscription_plan extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->library('external');
		$this->load->model('subscription_model','subscription');
	}
	
	public function index(){
		$data['title'] = 'Subscription List';
		$data['page'] = 'index';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();       
		$data['extra_datatable_data'] .= '<script type="text/javascript">
											$(document).ready(function (){
											    $("#subscription_list").DataTable({
											        "processing": true,
											        "serverSide": true,
											        "ajax":{
											            "url": "'.base_url('subscription_plan/subscription_list').'",
											            "dataType": "json",
											            "type": "POST",
											            "data":{
											              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
											            }
											        },
											        "columns": [
											          { "data": "id" },
											          { "data": "name" },
											          { "data": "description" },
											          { "data": "image" },
											          { "data": "price" },
											          { "data": "duration" },
											          { "data": "status" },
											          { "data": "action" },
											        ]
											    });
											});

											function edit_func(id){
												
												$.ajax({
													url: "'.base_url('subscription_plan/edit_subscription').'",
													data: { 
														"number": id, 
													},
													cache: false,
													type: "POST",
													success: function(response) {
														$("#id_subscription_id").val(id);
														var vl=JSON.parse(response);
														$("#name").val(vl.name);
														$("#description").val(vl.description);
														$("#form-img").attr("src",vl.image_path);
														$("#price").val(vl.price);
														$("#duration").val(vl.duration);
													},
													error: function(xhr) {
														
													}
												});
												$("#edit-item").modal("show");
												
											}

											function change_status(that){
												var number = $(that).attr("data-number");
												var status = $(that).val();
												$.ajax({
													url: "'.base_url('subscription_plan/change_status').'",
													data: { 
														"number": number, 
														"status": status
													},
													cache: false,
													type: "POST",
													success: function(response) {
														console.log(response);
														$("#subscription_list").DataTable().ajax.reload();
													},
													error: function(xhr) {
														
													}
												});
											}

											$(".form-image").on("click", function(){
										            $(this).parents(".form-group").find("input[type=file]").trigger("click");
										        });
										        $("input[name=image]").on("change", function(event) {
										            if ($(this).val() !== "") {
										                read_image(event, ".user-image-trigger");
										            } else {
										                $(".user-image-trigger").attr({"src":base_url("assets/img/choose-an-image.jpg"),"width":"150px","height":"150px"});
										            }
										    });
											</script>';
		$this->load->view('template',$data);
	}

	public function subscription_list(){
		$columns = array(
			0=> 'id',
			1=> 'name',
			2=> 'description',
			3=>	'image',
			4=> 'price',
			5=> 'duration',
			6=> 'status',
			7=> 'action',
			
		);

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = '';
        $dir = '';
        $totalData = $this->subscription->table_items_count('subscription');

        $totalFiltered = $totalData; 
        if(empty($this->input->post('search')['value'])){
        	$posts = $this->subscription->all_items($limit,$start,$order,$dir, 'subscription', "subscription.id,subscription.name,subscription.status,subscription.description, subscription.duration, subscription.price,subscription.image_path");
        }else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->subscription->item_search($limit,$start,$search,$order,$dir, 'subscription', "subscription.id,subscription.name,subscription.status,subscription.description, subscription.duration, subscription.price,subscription.image_path");
            $totalFiltered = $this->subscription->item_count_search($search,  'subscription');
        }
        
  		$data = array();
		if(!empty($posts)){
			$j=0;
			foreach ($posts as $post){
				$j++;
			
				$nestedData['id'] = $j;
				$nestedData['name'] = $post->name;
				$nestedData['description'] = $post->description;
				$nestedData['image'] = '<img src="'.IMGS_URL.$post->image_path.'" width="50%">';
				$nestedData['status'] = '<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
					<option value="2" '.(($post->status == 2)? 'selected="selected"' :" ").' >Deactivate </option>
					<option value="1" '.(($post->status == 1)? 'selected="selected"' :" ").'>Activate</option>
				</select>';
				$nestedData['price'] = $post->price;
				$nestedData['duration'] = $post->duration;
				$nestedData['status'] ='<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
					<option value="2" '.(($post->status == 2)? 'selected="selected"' :" ").' >Deactivate </option>
					<option value="1" '.(($post->status == 1)? 'selected="selected"' :" ").'>Activate</option>
				</select>';
				$nestedData['action'] = '<button class="btn btn-primary edit" onclick="edit_func('.$post->id.')"><i class="fa fa-pencil" ></i> Edit</button><!--<a data-toggle="modal" data-target=".bs-example-modal-lg"><button class="btn btn-primary"><i class="fa fa-pencil"></i> View</button></a>-->';
				$data[] = $nestedData;
			}
		}	

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),  
			"recordsTotal"    => intval($totalData),  
			"recordsFiltered" => intval($totalFiltered), 
			"data"            => $data   
		);
		echo json_encode($json_data); 
	}	
		
	public function change_status(){
		$data = $this->subscription->change_status('subscription', $this->input->post('status'), $this->input->post('number'));
		print_r($data);
	}

	public function edit_subscription(){
		echo json_encode($this->subscription->get_subscriptione($this->input->post(NULL,true)));
	}

	public function do_update_subscription()
	{
		try {
            $this->form_validation->set_rules('id','id','trim|required');
            $this->form_validation->set_rules('name','name','trim|required');
            $this->form_validation->set_rules('description','name','trim|required');
            $this->form_validation->set_rules('price','name','trim|required');
            $this->form_validation->set_rules('duration','name','trim|required');
            if(!$this->form_validation->run()) {
                throw new Exception(validation_errors(), 1);
            }

            $info = $this->input->post(null, true);
            $details=$this->subscription->get_subscriptione_detail($info['id']);
	        $image=upload_file('image','subscription');

	        if($image!=false){
	            $info['image']=$image;
	        	$info['image']='uploads/subscription/'.$image;
	        }


	        /*if(!is_bool($image) && $image!=false){
	            unlink(IMGS_RMV.$details['image_path']);    
	        }*/
	        
            $rs = $this->subscription->do_update_subscription($info);
            if(!$rs){
                throw new Exception("Error Processing Request", 1);   
            }

            $this->session->set_flashdata('success', 'Subscription is updated Successfully');

        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
        }
        redirect(site_url('subscription_plan'));
	}
}