<?php

if (!defined('BASEPATH'))exit('No direct script access allowed');

class Subscription_model extends CI_Model {

    public function table_items_count($table){
    	//print_r($table);
		$query = $this->db->get($table);
		return $query->num_rows();
	}

	public function all_items($limit,$start,$col,$dir, $table, $select = '*'){
		$this->db->select($select);
		$query = $this->db
				->limit($limit,$start)
				//->order_by($col,$dir)
				->get($table);

		if($query->num_rows()>0)
            return $query->result(); 
        else
            return null;
	}

	function item_search($limit,$start,$search,$col,$dir, $table, $select)
    {
    	$this->db->select($select);
        $query = $this->db
        	->like($table.'.id',$search)
        	->or_like('address',$search)
        	->limit($limit,$start)->order_by($table.'.'.$col,$dir)->get($table);
        
       
        if($query->num_rows()>0)
            return $query->result();  
        else
            return null;
    }

    public function get_subscriptione($id)
    {   

        return $this->db->select('id,name,description,price,duration,CONCAT("'.IMGS_URL.'", image_path) as image_path')->where('id', $id['number'])->get('subscription')->row_array();
    }

    public function get_subscriptione_detail($id)
    {   
        return $this->db->select('id,name,description,price,duration,image_path as image_path')->where('id', $id)->get('subscription')->row_array();
    }

    public function change_status($table,$status,$id)
    {
        try {

            $this->db->trans_begin();
            $where= array('id' => $id );
            $update_data = array(
                'status' =>$status,
                'updated_on'=>date('Y-m-d H:i:s')
            );
            $result = $this->db->update('subscription', $update_data, $where);
            
            if(!$result)
            {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function do_update_subscription($params='')
    {
        try {
            //show($params);
            $this->db->trans_begin();
            $this->db->set('name',$params['name']);      
            $this->db->set('description',$params['description']);
            $this->db->set('price',$params['price']);
            $this->db->set('duration',$params['duration']);
            if($params['image'] !=""){
                $this->db->set('image_path',$params['image']);      
            }
            $this->db->set('updated_on',date('Y-m-d H:i:s'));
            $this->db->where('id',$params['id']);
            $this->db->update('subscription');
            if(!$this->db->affected_rows()) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return 1;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }
}
