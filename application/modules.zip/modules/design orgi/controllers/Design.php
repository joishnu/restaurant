<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Design extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('design_model','product');
		$this->load->library('external');
	}

	public function index(){
		$data['title'] = 'Design Management';
		$data['page'] = 'design';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();     
		$data['extra_datatable_data'] .= $this->external->validation_extra_js_css();     
		$data['extra_datatable_data'] .= '<script type="text/javascript">
											$(document).ready(function (){
											    $("#product").DataTable({
											        "processing": true,
											        "serverSide": true,
											        "ajax":{
											            "url": "'.base_url('design/product_list').'",
											            "dataType": "json",
											            "type": "POST",
											            "data":{
											              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
											            }
											        },
											        "columns": [
											          { "data": "id" },
											          { "data": "name" },
											          { "data": "description" },
											          { "data": "image" },
											          { "data": "status" },
											          { "data": "created_on" },
											          { "data": "action" },
											        ]
											    });
											});
											function edit_func(id){
												
												$.ajax({
													url: "'.base_url('design/design_name').'",
													data: { 
														"number": id, 
													},
													cache: false,
													type: "POST",
													success: function(response) {
														$("#id_design_hid").val(id);
														var vl=JSON.parse(response);
														$("#name").val(vl.name);
														$("#description").val(vl.description);
														$("#form-img").attr("src",vl.image);
													},
													error: function(xhr) {
														console.log(xhr);
													}
												});
												$("#edit-item").modal("show");
												
											}

											function change_status(that){
												var number = $(that).attr("data-number");
												var status = $(that).val();
												$.ajax({
													url: "'.base_url('design/change_status').'",
													data: { 
														"number": number, 
														"status": status
													},
													cache: false,
													type: "POST",
													success: function(response) {
														console.log(response);
														$("#product").DataTable().ajax.reload();
													},
													error: function(xhr) {
														console.log(xhr);
													}
												});
											}

											$(".form-image").on("click", function(){
										            $(this).parents(".form-group").find("input[type=file]").trigger("click");
										        });
										        $("input[name=image]").on("change", function(event) {
										            if ($(this).val() !== "") {
										                read_image(event, ".user-image-trigger");
										            } else {
										                $(".user-image-trigger").attr({"src":base_url("assets/img/choose-an-image.jpg"),"width":"150px","height":"150px"});
										            }
										    });
											
											</script>

											';
											//print_r($data['extra_datatable_data']);exit();
		$this->load->view('template',$data);
	}

	public function design_name(){
		echo json_encode($this->product->get_design_name($this->input->post(NULL,true)));
	}

	// Product List ajax call for product list datatable
	public function product_list(){
		$columns = array(
			0 => "id",
			1 => "name",
			2 => "description",
			3 => "image",
			4 => "status",
			5 => "created_on",
			6 => "action"
		);

		$limit = $this->input->post('length');
        $start = $this->input->post('start');
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
        $totalData = $this->product->table_items_count('designs');

        $totalFiltered = $totalData; 
        if(empty($this->input->post('search')['value'])){
        	$posts = $this->product->all_items($limit,$start,$order,$dir, 'designs', "designs.status,designs.name,designs.id as id,designs.created_on, designs.description, designs.image");
        }else {
            $search = $this->input->post('search')['value']; 

            $posts =  $this->product->item_search($limit,$start,$search,$order,$dir, 'designs', "designs.status,designs.name,designs.id as id,designs.created_on, designs.description,designs.image");
            $totalFiltered = $this->product->item_count_search($search,  'designs');
        }
  		$data = array();

		if(!empty($posts)){
			$j=0;
			foreach ($posts as $post){
				$j++;
			
				$nestedData['id'] = $j;
				$nestedData['name'] = $post->name;
				$nestedData['description'] = $post->description;
				$nestedData['image'] = '<img src="'.IMGS_URL."uploads/designs/".$post->image.'" width="50%">';
				$nestedData['status'] = '<select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
					<option value="2" '.(($post->status == 2)? 'selected="selected"' :" ").' >Deactivate </option>
					<option value="1" '.(($post->status == 1)? 'selected="selected"' :" ").'>Activate</option>
				</select>';
				$nestedData['created_on'] = $post->created_on;
				$nestedData['action'] = '
				<button class="btn btn-primary edit" onclick="edit_func('.$post->id.')"><i class="fa fa-pencil" ></i> Edit</button><a href="'.base_url('/design/delete').'/'.$post->id.'"><button class="btn btn-danger"><i class="fa fa-remove" ></i> Delete</button></a><!--<a data-toggle="modal" data-target=".bs-example-modal-lg"><button class="btn btn-primary"><i class="fa fa-pencil"></i> View</button></a>-->
				';
					$data[] = $nestedData;
			}
		}

		$json_data = array(
		"draw"            => intval($this->input->post('draw')),  
		"recordsTotal"    => intval($totalData),  
		"recordsFiltered" => intval($totalFiltered), 
		"data"            => $data   
		);
		echo json_encode($json_data); 
	}


	public function delete($id = 0)
    {
        try {
            if(!$id) {
                throw new Exception('Choose a design', 1);
            }
            $rs = $this->product->do_delete($id);

            if(!$rs){
                throw new Exception("Error Processing Request", 1);   
            }

            $this->session->set_flashdata('success', 'Design is deleted successfully');
            redirect(site_url('design'));

        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(site_url('design'));

        }
    }

	public function do_add_design() {
		 try {
            $this->form_validation->set_rules('name','Design name','trim|required');
            $this->form_validation->set_rules('description','Description','trim|required');

            if(!$this->form_validation->run()) {
                throw new Exception(validation_errors(), 1);
            }
            $input = $this->input->post(NULL, TRUE);
            //$this->product->validate_name($info['name']);
            if(empty($_FILES) || !isset($_FILES['image']) || $_FILES['image']['error']){
                throw new Exception("Please upload image");   
            }
            $image=upload_file('image','designs');
            
            if(!$image){
                throw new Exception("Error in uploading image");
            }
            $input['image']=$image;
            

            if(!$this->product->do_add_design($input)){
                throw new Exception("Error Processing Request", 1);   
            }

            $this->session->set_flashdata('success', 'Design is added successfully');
            redirect(site_url('design'));
        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(site_url('design'));
        }
	}

	public function do_update_design() {
		try {
            $this->form_validation->set_rules('id','id','required');
            $this->form_validation->set_rules('name','name','required');
            if(!$this->form_validation->run()) {
                throw new Exception(validation_errors(), 1);
            }

            $info = $this->input->post(null, true);
            $details=$this->product->get_design_details($info['id']);
	        $image=upload_file('image','designs');

	        if($image!=false){
	            $info['image']=$image;
	        }

	        if(!is_bool($image) && $image!=false){
	            unlink(IMGS_RMV.'/uploads/designs/'.$details['image']);    
	        }
	        $info['image']=$image;
            $rs = $this->product->do_update_design($info);

            if(!$rs){
                throw new Exception("Error Processing Request", 1);   
            }

            $this->session->set_flashdata('success', 'Design is updated Successfully');

        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            
        }
        redirect(site_url('design'));
	}

	public function change_status() {
		$this->form_validation->set_rules('number','number','trim|required');
	    $info = $this->input->post(NULL,true);
	    echo json_encode($this->product->change_status($info));
	}

}
