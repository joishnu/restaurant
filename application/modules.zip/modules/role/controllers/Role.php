<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
 * @author Bimlesh
 *
 */
class Role extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('role_model','role');

	}
	public function add(){
		$data['title'] = 'Role';
        $data['list']=$this->role->role_result();
		$data['page'] = 'add';       
		$this->load->view('template',$data);
	}
    public function edit($id=""){
        $data['title'] = 'Edit Role';
        $data['list']=$this->role->role_results($id);
        $data['page'] = 'edit';       
        $this->load->view('template',$data);
    }
	public function add_role(){
        $this->form_validation->set_rules('name','name','trim|required');
        $info = $this->input->post(NULL,true);
        if($this->form_validation->run()) {
        $rs = $this->role->do_add_role($info);
        if($rs) {
        $this->session->set_flashdata('success', 'Role has been updated successfully');
        redirect(site_url('role/add'));
        } 
        else {
        $this->session->set_flashdata('error', 'Some error occurred. Please try again.');
        }
        } 
        else {
        $this->session->set_flashdata('error',validation_errors());
        }
        redirect(site_url('role/add'));
    }
    public function update_role(){
        $this->form_validation->set_rules('name','name','trim|required');
        $info = $this->input->post(NULL,true);

        if($this->form_validation->run()) {
        $rs = $this->role->do_update_role($info);
        if($rs) {
        $this->session->set_flashdata('success', 'role has been updated successfully');
        redirect(site_url('role/add'));
        } 
        else {
        $this->session->set_flashdata('error', 'Some error occurred. Please try again.');
        }
        } 
        else {
        $this->session->set_flashdata('error',validation_errors());
        }
        redirect(site_url('role/add/'.$info['role_id']));
    }

}