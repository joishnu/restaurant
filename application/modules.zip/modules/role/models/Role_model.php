<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
 * @author bimlesh
 *
 */
class Role_model extends CI_Model {

	public function do_add_role($params){

        try {
            $this->db->trans_begin();
                    $role= array(
                        'name' => $params['name'],
                    );
                
                $this->db->insert('roles',$role);

            if(!$this->db->affected_rows()) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return 1;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }
    public function do_update_role($params){
     //echo"<pre>";print_r($params);die;
       try { 
            $this->db->trans_begin();
            $where = array(
                'id' => $params['role_id']
            );
                $update_data = array(
                'name' => $params['name']
            );
            if(!$this->db->update('roles', $update_data, $where)) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return TRUE;
            
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return FALSE;
        }
    }
    
    public function role_result(){
        $this->db->select("*");
        $this->db->from("roles");
        $return=$this->db->get()->result_array();
        return $return ;
    }
    public function role_results($id=""){
        $this->db->select("*");
        $this->db->from("roles");
        $this->db->where('id',$id);
        $return=$this->db->get()->row_array();
        return $return ;
    }
  	
}
