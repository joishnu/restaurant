<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>User Management <small>| Admin section</small></h3>
      </div>
    </div>
  </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Admin add and edit information<small>Both Superadmin and Sub-admin information</small></h2>
              <ul class="nav navbar-right panel_toolbox">
<!--                 <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                <li><a class="close-link"><i class="fa fa-close"></i></a></li>
 -->              </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <div class="x_content">
          <form class="form-horizontal form-label-left" enctype="multipart/form-data" novalidate id="admin_update_form" method="post" action="<?=base_url('users/admin_edit_back')?>"  data-toggle="validator" data-disable="false">
            <?=(isset($admins['id']))? '<input type="hidden" name="user_id" value="'.$admins['admin_id'].'">' :''?>
            <div class="item form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">First name <span class="required">*</span></label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <input id="first_name" class="form-control col-md-7 col-xs-12"  name="first_name" placeholder="Please enter first name" required="required" data-parsley-text-message="test" type="text" value="<?=(isset($admins['first_name']))?$admins['first_name']:''?>">
              </div>
            </div>
            <div class="item form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Last name <span class="required">*</span></label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <input id="last_name" class="form-control col-md-7 col-xs-12"  name="last_name" placeholder="Please enter last name" required="required" type="text" value="<?=(isset($admins['last_name']))?$admins['last_name']:''?>">
              </div>
            </div>

            <div class="item form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Email <span class="required">*</span></label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <input id="email" class="form-control col-md-7 col-xs-12"  name="email" placeholder="Please enter email address" required="required" type="text" value="<?=(isset($admins['email']))?$admins['email']:''?>">
              </div>
            </div>

            <div class="item form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Phone <span class="required">*</span></label>
              <div class="col-md-2 col-sm-2 col-xs-4">
                <select id="country_code" name="country_code" class="form-control col-md-7 col-xs-12">
                  <option value="">Please select country code</option>
                  <?php 
                  foreach ($countries as $key => $value) {
                    // echo "<option value='".$value['phonecode']."' ".((isset($value['phonecode'])  == $admins['country_code'])?"selected":"").">".$value['name']." (+".$value['phonecode'].") </option>";

                    echo "<option value='".$value['phonecode']."' ".(isset($value['phonecode'])&& (($value['phonecode']) == $admins['country_code'])?"selected":"").">".$value['name']." (+".$value['phonecode'].") </option>";
                  }
                  ?>
                </select>
              </div>
              <div class="col-md-4 col-sm-4 col-xs-8">
                <input id="phone" class="form-control col-md-7 col-xs-12"  name="phone" placeholder="Please enter phone number" required="required" type="text" value="<?=(isset($admins['phone']))?$admins['phone']:''?>">
              </div>
            </div>

            <div class="item form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Role<span class="required">*</span></label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <select id="role" name="role" class="form-control col-md-7 col-xs-12" required="">
                  <option value="">Please select Role</option>
                  <option value="1" <?=(isset($admins['role']) && ($admins['role'] == 1))?"selected":''; ?>>Admin</option>
                  <option value="2" <?=(isset($admins['role']) && ($admins['role'] == 2))?"selected":''; ?>>Sub-Admin</option>
                </select>
              </div>
            </div>

         <!--    <div class="item form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Valid till <span class="required">*</span></label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <input id="valid_date" class="form-control col-md-7 col-xs-12 date" name="valid_date" placeholder="Please enter validity date" required="required" type="text" value="<?=(isset($admins['validity']))?date('d-m-Y', strtotime($admins['validity'])):''?>">
              </div>
            </div>
 -->
            <div class="item form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Profile Picture </label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <input id="images" class="form-control col-md-7 col-xs-12" name="images[]" placeholder="Please upload profile picture"  type="file" multiple="" required="">
              </div>
            </div>

            <div class="item form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"></label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <?=(isset($admins['profile']))? "<img style='max-width:100%; max-height:250px;' src='".base_url('assets/uploads/profiles/admin/').$admins['profile']."'>" :''?>
              </div>
            </div>
            

            <div class="item form-group">
              <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Status <span class="required">*</span></label>
              <div class="col-md-6 col-sm-6 col-xs-12">
                <select id="status" name="status" class="form-control col-md-7 col-xs-12" required="">
                  <option value="">Please select status</option> 
                  <option value="1" <?= (isset($admins['status']) && ($admins['status'] == 1 ))?"selected":''; ?>>Activate</option>
                  <option value="2" <?= (isset($admins['status']) && ($admins['status'] == 2))?"selected":''; ?>>Deactivate</option>
                </select>
              </div>
            </div>


            <div class="ln_solid"></div>
            <div class="form-group">
              <div class="col-md-6 col-md-offset-3">
                <!-- <button type="submit" class="btn btn-primary">Cancel</button>
                <button id="send" type="submit" class="btn btn-success">Update</button> -->
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
              </div>
            </div>
          </form>
        </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- data-validate-length-range="6" data-validate-words="2"
data-validate-length-range="6" data-validate-words="2"
data-validate-length-range="6" data-validate-words="2"
data-validate-length-range="6" data-validate-words="2" -->

