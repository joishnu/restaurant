<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>User Management <small>| Admin list</small></h3>
            </div>
        </div>
        <div class="title_right">
            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search" style="text-align: right">
                <a href="<?=base_url('users/admin_edit_back');?>" class="btn btn-primary"> <i class="fa fa-plus"></i> Add Admin</a>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Admin List<small>Both Superadmin and Sub-admin list</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <p class="text-muted font-13 m-b-30"><!-- If you want to write somting you can write here --></p>
                    <table id="admintable" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Email</th>
                                <th>Type</th>
                                <th>Registered</th>
                                <!-- <th>Validity</th> -->
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
<div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span></button>
            <h4 class="modal-title" id="myModalLabel">Edit Admin Details</h4>
        </div>
        <div class="modal-body" style="padding: 0;">
            <div class="x_content">
                <form class="form-horizontal form-label-left" novalidate id="admin_update_form">
                    <div class="item form-group">
                        <input type="hidden" name="user_id" value="" id="user_id">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">First name <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input id="first_name" class="form-control col-md-7 col-xs-12"  name="first_name" placeholder="Please enter first name" required="required" type="text">
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Last name <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input id="last_name" class="form-control col-md-7 col-xs-12"  name="last_name" placeholder="Please enter last name" required="required" type="text">
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Email <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input id="email" class="form-control col-md-7 col-xs-12"  name="email" placeholder="Please enter email address" required="required" type="text">
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Phone <span class="required">*</span></label>
                        <div class="col-md-2 col-sm-2 col-xs-4">
                            <select id="country_code" name="country_code" class="form-control col-md-7 col-xs-12">
                                <option value="">Please select country code</option>
                                <?php
                                foreach ($countries as $key => $value) {
                                echo "<option value='".$value['id']."'>".$value['name']." (+".$value['phonecode'].") </option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-4 col-sm-4 col-xs-8">
                            <input id="phone" class="form-control col-md-7 col-xs-12"  name="phone" placeholder="Please enter phone number" required="required" type="text">
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Role<span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <select id="role" name="role" class="form-control col-md-7 col-xs-12">
                                <option>Please select Role</option>
                                <option>Admin</option>
                                <option>Sub-Admin</option>
                            </select>
                        </div>
                    </div>
                 <!--    <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Valid till <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input id="valid_date" class="form-control col-md-7 col-xs-12 date" name="valid_date" placeholder="Please enter validity date" required="required" type="text">
                        </div>
                    </div> -->
                    <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Profile Picture <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <input id="profil_pic" class="form-control col-md-7 col-xs-12" name="profil_pic" placeholder="Please upload profile picture" required="required" type="file">
                        </div>
                    </div>
                    <div class="item form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">Status <span class="required">*</span></label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <select id="status" name="status" class="form-control col-md-7 col-xs-12">
                                <option>Please select status</option>
                                <option>Activate</option>
                                <option>Deactivate</option>
                            </select>
                        </div>
                    </div>
                    <div class="ln_solid"></div>
                    <div class="form-group">
                        <div class="col-md-6 col-md-offset-3">
                            <!-- <button type="submit" class="btn btn-primary">Cancel</button>
                            <button id="send" type="submit" class="btn btn-success">Update</button> -->
                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Save changes</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        <div class="modal-footer">
            
        </div>
    </div>
</div>
</div>
<!-- data-validate-length-range="6" data-validate-words="2"
data-validate-length-range="6" data-validate-words="2"
data-validate-length-range="6" data-validate-words="2"
data-validate-length-range="6" data-validate-words="2" -->