<script async defer src="http://maps.google.com/maps/api/js?key=<?=GOOGLE_API_KEY;?>&sensor=false&libraries=places" type="text/javascript"></script>

<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>User Management <small>| Vendors list</small></h3>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Vendor Form</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div id="wizard" class="form_wizard wizard_horizontal">
                        <ul class="wizard_steps">
                            <li>
                                <a href="#step-1">
                                    <span class="step_no">1</span>
                                    <span class="step_descr"> Step 1<br/><small>Basic Vendor Details</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#step-2">
                                    <span class="step_no">2</span>
                                    <span class="step_descr">Step 2<br /><small>Vendor Business Details</small></span>
                                </a>
                            </li>
                            <li>
                                <a href="#step-3">
                                    <span class="step_no">3</span>
                                    <span class="step_descr">Step 3<br/><small>Documents Upload</small> </span>
                                </a>
                            </li>
                            <li>
                                <a href="#step-4">
                                    <span class="step_no">4</span>
                                    <span class="step_descr">Step 3<br/><small>Warehouse Information</small> </span>
                                </a>
                            </li>
                            <li>
                                <a href="#step-5">
                                    <span class="step_no">5</span>
                                    <span class="step_descr">Step 5<br/><small>Bank Details</small> </span>
                                </a>
                            </li>
                            <li>
                                <a href="#step-6">
                                    <span class="step_no">6</span>
                                    <span class="step_descr">Step 6<br /><small>Final Step</small></span>
                                </a>
                            </li>
                        </ul>
                        <form class="form-horizontal form-label-left" enctype="multipart/form-data" method="post" action="<?=base_url('users/addvendor_back');?>" data-toggle="validator">
                            <div id="step-1">
                             
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first_name">First name <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="first_name" class="form-control col-md-7 col-xs-12"   name="first_name" placeholder="Please enter first name" required="required" type="text" data-validate-length-range="2">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last_name">Last name <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="last_name" class="form-control col-md-7 col-xs-12"   name="last_name" placeholder="Please enter last name" required="required" type="text" data-validate-length-range="1">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="email">Email <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="email" class="form-control col-md-7 col-xs-12"   name="email" placeholder="Please enter email address" required="required" type="email" data-validate-length-range="5">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="phone">Phone <span class="required">*</span></label>
                                    <div class="col-md-2 col-sm-2 col-xs-4">
                                        <select id="country_code" name="country_code" class="form-control col-md-7 col-xs-12">
                                            <option value="">Please select country code</option>
                                            <?php
                                            foreach ($countries as $key => $value) {
                                            echo "<option value='".$value['phonecode']."'>".ucwords(strtolower($value['name']))." (+".$value['phonecode'].") </option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                    <div class="col-md-4 col-sm-4 col-xs-8">
                                        <input id="phone" class="form-control col-md-7 col-xs-12"   name="phone" placeholder="Please enter phone number" required="required" type="text" data-validate-length-range="7">
                                    </div>
                                </div>
                             <!--    <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="role">Role<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select id="role" name="role" class="form-control col-md-7 col-xs-12">
                                            <option>Please select Role</option>
                                            <option value="1" selected="">Vendor</option>
                                            <option value="2" >Sub-Vendor</option>
                                            <?php foreach($role as $key => $value){?>
                                                <option value="<?php echo $value['id'];?>"><?php echo $value['name'];?></option>
                                            <?php }?>
                                        </select>
                                    </div>
                                </div> -->
                              <!--   <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="valid_date">Valid till <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="valid_date" class="form-control col-md-7 col-xs-12 date" name="valid_date" placeholder="Please enter validity date" required="required" type="text">
                                    </div>
                                </div> -->
                            </div>
                            <div id="step-2">
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="company_name">Company Name <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="company_name" class="form-control col-md-7 col-xs-12"   name="company_name" placeholder="Please enter Company name" required="required" type="text" data-validate-length-range="4">
                                    </div>
                                </div>
                                <!-- <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="type">Type<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select id="type" name="type" class="form-control col-md-7 col-xs-12">
                                            <option>Please select Type</option>
                                            <option value="1" selected="">Normal Vendor</option>
                                            <option value="2">Premium Vendor</option>
                                        </select>
                                    </div>
                                </div> -->
                                <!--   <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="commission">Commission<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="commission" class="form-control col-md-7 col-xs-12"   name="commission" placeholder="Please enter commission in precent(%)" required="required" type="text">
                                    </div>
                                </div>
                                -->
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="address">Address<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="address" class="form-control col-md-7 col-xs-12"   name="address" placeholder="Please enter Complete address of company" type="text" required="">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="country">Country<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select id="country" name="country" class="form-control col-md-7 col-xs-12" required="">
                                            <option value="">Please select Country</option>
                                            <?php
                                            foreach ($countries as $key => $value) {
                                            echo "<option value='".$value['id']."'>".ucwords(strtolower($value['name']))."</option>";
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="state">State<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select id="state" name="state" class="form-control col-md-7 col-xs-12" required="">
                                            <option value="">Please select state</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="city">City<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select id="city" name="city" class="form-control col-md-7 col-xs-12" required="">
                                            <option value="">Please select city</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="officenumber">Office Number<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="officenumber" class="form-control col-md-7 col-xs-12"   name="officenumber" placeholder="Please enter office contact number with STD code" required="required" type="text">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="company_name">GST No. <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="gst" class="form-control col-md-7 col-xs-12"   name="gst" placeholder="Please enter GST No." required="required" type="text">
                                    </div>
                                </div>
                            </div>
                            <div id="step-3">
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="license">License<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="license" class="form-control col-md-7 col-xs-12"   name="license" placeholder="Please enter business license number" required="required" type="text" data-validate-length-range="5">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="license_file">Upload License<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="license_file" class="form-control col-md-7 col-xs-12" name="license_file[]" placeholder="Please enter business license number" multiple required="required" type="file">
                                    </div>
                                </div>
                                <hr>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="address_proof">Address proof<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="address_proof" class="form-control col-md-7 col-xs-12"   name="address_proof" placeholder="Please enter business license number" required="required" type="text">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="address_proof_file">Upload Address<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="address_proof_file" class="form-control col-md-7 col-xs-12" name="address_proof_file[]" placeholder="Please enter business license number" required="required"  multiple type="file">
                                    </div>
                                </div>
                                <hr>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="identity">Identity Number<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="identity" class="form-control col-md-7 col-xs-12"   name="identity" placeholder="Please enter business license number" required="required" type="text">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="identity_file">Upload Number<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="identity_file" class="form-control col-md-7 col-xs-12" name="identity_file[]" placeholder="Please enter business license number" required="required" multiple type="file">
                                    </div>
                                </div>
                                <hr>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="files">Upload Profile<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="files" class="form-control col-md-7 col-xs-12" name="files[]" placeholder="Please enter business license number" required="required" type="file" multiple>
                                    </div>
                                </div>
                            </div>
                            <div id="step-4">
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="additional">Warehouse Address 1</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <!-- <textarea placeholder="Please enter Warehouse Address 1" class="form-control col-md-7 col-xs-12" name="address1" id="address1"></textarea> -->
                                        <input type="text" class="form-control" id="address1" name="address1"  placeholder = "Address 1" onFocus="initializeAutocomplete(this.id)" required="">
                                         <input name="address1_lat"  id="address1_lat" type="hidden" readonly />
                                         <input name="address1_long" id="address1_long" type="hidden" readonly />
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="additional">Warehouse Address 2</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                     <!--    <textarea placeholder="Please enter Warehouse Address 2" class="form-control col-md-7 col-xs-12" name="address2" id="address2"></textarea> -->
                                      <input type="text" class="form-control" id="address2" name="address2"  placeholder = "Address 2" onFocus="initializeAutocomplete(this.id)">
                                        <input name="address2_lat"  id="address2_lat" type="hidden" readonly />
                                        <input name="address2_long" id="address2_long" type="hidden" readonly />
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="additional">Warehouse Address 3</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <!-- <textarea placeholder="Please enter Warehouse Address 3" class="form-control col-md-7 col-xs-12" name="address3" id="address3"></textarea> -->
                                         <input type="text" class="form-control" id="address3" name="address3"  placeholder = "Address 3" onFocus="initializeAutocomplete(this.id)">
                                        <input name="address3_lat"  id="address3_lat" type="hidden" readonly />
                                        <input name="address3_long" id="address3_long" type="hidden" readonly />
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="additional">Warehouse Address 4</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <!-- <textarea placeholder="Please enter Warehouse Address 4" 
                                        class="form-control col-md-7 col-xs-12" name="address4" id="address4"></textarea> -->
                                         <input type="text" class="form-control" id="address4" name="address4"  placeholder = "Address 4" onFocus="initializeAutocomplete(this.id)">
                                        <input name="address4_lat"  id="address4_lat"  type="hidden" readonly />
                                         <input name="address4_long" id="address4_long" type="hidden" readonly />
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="additional">Warehouse Address 5</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                       <!--  <textarea placeholder="Please enter Warehouse Address 5" class="form-control col-md-7 col-xs-12" name="address5" id="address5"></textarea> -->
                                        <input type="text" class="form-control" id="address5" name="address5"  placeholder = "Address 5" onFocus="initializeAutocomplete(this.id)">
                                        <input name="address5_lat"  id="address5_lat" type="hidden" readonly />
                                        <input name="address5_long" id="address5_long" type="hidden" readonly />
                                    </div>
                                </div>
                            </div>
                            <div id="step-5">
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="additional">Bank Name<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="bank_name" class="form-control col-md-7 col-xs-12" name="bank_name" placeholder="Please enter Bank Name" required="required" type="text">
                                    </div>
                                </div>
				              <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="additional">Bank Branch Name<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input id="branch_name" class="form-control col-md-7 col-xs-12" name="branch_name" placeholder="Please enter Bank Branch Name" required="required" type="text">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="additional">Bank Account Name<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="bank_ac" class="form-control col-md-7 col-xs-12" name="bank_ac" placeholder="Please enter Bank Account Name" required="required" type="text">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="additional">Bank Account Number<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="account_no" class="form-control col-md-7 col-xs-12" name="account_no" placeholder="Please enter Account Number" required="required" type="text">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="additional">IFSC Code<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="ifsc" class="form-control col-md-7 col-xs-12" name="ifsc" placeholder="Please enter IFSC Code" required="required" type="text">
                                    </div>
                                </div>
                            </div>
                            <div id="step-6">
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="additional">Additional information</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <textarea placeholder="Please enter additional information (only visible to admin)" class="form-control col-md-7 col-xs-12" name="additional" id="additional"></textarea>
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="additional">Password<span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="password" class="form-control col-md-7 col-xs-12" name="password" placeholder="Please enter password" required="required" type="password" required="">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="status">Status <span class="required">*</span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select id="status" name="status" class="form-control col-md-7 col-xs-12" required="">
                                            <option value="">Please select status</option>
                                            <option value="1" selected="">Activate</option>
                                            <option value="2" >Deactivate</option>
                                        </select>
                                    </div>
                                </div>
                              <!--   <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name"><span class="required"><input type="checkbox" name="terms"></span></label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <label class="col-md-7 col-xs-12" style="padding-top: 9px;">Acceptance of <a href="#">terms and conditions</a>
                                    </label>
                                </div>
                            </div> -->
                            <div class="item form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">  </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <button type="submit" name="submit1" class="btn btn-primary">Save</button>
                                    <!-- <input type="reset" name="reset" class="btn btn-primary"> -->
                                </label>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
</div>
</div>
<style type="text/css">
.stepContainer{
height: 2rem !important;
}
.buttonFinish{
display: none !important;
}
</style>



<script type="text/javascript">
    function initializeAutocomplete(id){
        var input = document.getElementById(id);

        // var options = {
        //   types: ['(regions)'],
        //   componentRestrictions: {country: "IN"}
        // };
        var options = {}

        var autocomplete = new google.maps.places.Autocomplete(input, options);

        google.maps.event.addListener(autocomplete, 'place_changed', function() {
          var place = autocomplete.getPlace();
          var lat = place.geometry.location.lat();
          var lng = place.geometry.location.lng();
          var placeId = place.place_id;
          // to set city name, using the locality param
          var componentForm = {
            locality: 'short_name',
          };
          for (var i = 0; i < place.address_components.length; i++) {
            var addressType = place.address_components[i].types[0];
            if (componentForm[addressType]) {
              var val = place.address_components[i][componentForm[addressType]];
              //document.getElementById("city").value = val;
            }
          }
          document.getElementById(id+"_lat").value = lat;
          document.getElementById(id+"_long").value = lng;
        });
    }

</script>
