 <?php //print_r($info); ?>
<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="">
        <h3><?php echo $info['vendor_name'];?></h3>
      </div>
    </div>
    
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel" style="margin-top: 2.65rem">
          <div class="x_title">
            <h2>Vendor Information <small>Profile</small></h2>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <div class="col-md-3 col-sm-3 col-xs-12 profile_left">
              <div class="profile_img">
                <div id="crop-avatar">
                  <img class="img-responsive avatar-view" src="<?=($info['profile'])? CUSTOM_VENDOR_PROFILE.$info['profile']:base_url('assets/uploads/profiles/vendor/default.jpg')?>" alt="Avatar" title="Change the avatar">
                </div>
              </div>
              <h3><?=($info['first_name'])? ucfirst($info['first_name'].' '.$info['last_name']):''; ?></h3>
              <h4><?=($info['email'])? $info['email']:''; ?></h4>
              <h4><?=($info['phone'])? '+'.$info['country_code'].'-'.$info['phone']:''; ?></h4>
              <ul class="list-unstyled user_data">
                <li><hr></li>
                <li>
                  <label>GST No.:</label><br>
                  <?=($info['gst'])? ucfirst($info['gst']):''; ?>
                </li>
                <li><hr></li>
                <li>
                  <label>Document:</label><br>
                  <?=($info['is_document'] == 1)? 'Verified <i class="fa fa-check"></i>':'Unverified'; ?>
                </li>
                <li><hr></li>
                <li>
                  <label>Email:</label><br>
                  <?=($info['is_email'] == 1)? 'Verified <i class="fa fa-check"></i>':'Unverified'; ?>
                </li>
                <li><hr></li>
                <li>
                  <label>Phone:</label><br>
                  <?=($info['is_phone'] == 1)? 'Verified <i class="fa fa-check"></i>':'Unverified'; ?>
                </li>
                <li><hr></li>
              </ul>
            </div>

            <div class="col-md-9 col-sm-9 col-xs-12">


              <!-- <div class="profile_title">
                <div class="col-md-6">
                  <h2>User Activity Report</h2>
                </div>
                <div class="col-md-6">
                  <div id="reportrange" class="pull-right" style="margin-top: 5px; background: #fff; cursor: pointer; padding: 5px 10px; border: 1px solid #E6E9ED">
                    <i class="glyphicon glyphicon-calendar fa fa-calendar"></i>
                    <span>December 30, 2014 - January 28, 2015</span> <b class="caret"></b>
                  </div>
                </div>
              </div> -->
                <!-- start of user-activity-graph -->
              <!-- <div id="graph_bar" style="width:100%; height:280px;"></div> -->
                <!-- end of user-activity-graph -->

                <div class="" role="tabpanel" data-example-id="togglable-tabs">
                  <ul id="myTab" class="nav nav-tabs bar_tabs" role="tablist">

                    <li role="presentation" class="active"><a href="#tab_content1" id="home-tab" role="tab" data-toggle="tab" aria-expanded="true">Bank Details</a>
                    </li>
                    <li role="presentation" class=""><a href="#tab_content2" role="tab" id="profile-tab" data-toggle="tab" aria-expanded="false">Warehouse Adresses</a>
                    </li>
                    <li role="presentation" class=""><a href="#tab_content3" role="tab" id="profile-tab2" data-toggle="tab" aria-expanded="false">Business License</a>
                    </li>
                    <li role="presentation" class=""><a href="#tab_content4" role="tab" id="profile-tab2" data-toggle="tab" aria-expanded="false">Address Proof</a>
                    </li>

                    <li role="presentation" class=""><a href="#tab_content5" role="tab" id="profile-tab2" data-toggle="tab" aria-expanded="false">Identity</a>
                    </li>

                  </ul>
                  <div id="myTabContent" class="tab-content">
                    <div role="tabpanel" class="tab-pane fade active in" id="tab_content1" aria-labelledby="home-tab">
                        <table class="data table table-striped no-margin">
                         
                          <tbody>
                            <tr>
                              <td><strong>Bank Name</strong></td>
                              <td><?php echo $info['bank_name'];?></td>
                            </tr>
                            
                            <tr>
                               <td><strong>Account Name</strong></td>
                               <td><?php echo $info['account_name'];?></td>
                            </tr>

                            <tr>
                               <td><strong>Branch Name</strong></td>
                               <td><?php echo $info['branch_name'];?></td>
                            </tr>

                            <tr>
                                <td><strong>Account Number</strong></td>
                               <td><?php echo $info['account_number'];?></td>
                            </tr>

                            <tr>
                                <td><strong>IFSC Code</strong></td>
                               <td><?php echo $info['ifsc'];?></td>
                            </tr>
                          </tbody>
                        </table>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="tab_content2" aria-labelledby="profile-tab">
                      <table class="data table table-striped no-margin">
                          <tbody>
                          <?php $cnt=count($info['stores']);
                          for($i=0;$i<=$cnt-1;$i++){?>
                            <tr>
                              <td><strong>Address <?php echo $i+1;?></strong></td>
                              <td><?php echo $info['stores'][$i]['store_address'];?></td>
                            </tr>
                          <?php }?>
                          </tbody>
                        </table>
                    </div>

                    <div role="tabpanel" class="tab-pane fade" id="tab_content3" aria-labelledby="profile-tab">
                       <ul class="list-unstyled user_data">
                        <li>
                          <label>Business License Number</label>
                          <br>
                          <?=($info['business_license_number'])? ucfirst($info['business_license_number']):''; ?>

                          <br><br>
                          <img style="width: 40%;" src="<?php echo CUSTOM_VENDOR_PROFILE.$info['business_license_doc']; ?>">
                        </li>

                      </ul>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="tab_content4" aria-labelledby="profile-tab">
                       <ul class="list-unstyled user_data">
                        
                        <li>
                          <label>Address proof Number</label>
                          <br>
                          <?=($info['address_proof_number'])? ucfirst($info['address_proof_number']):''; ?>
                          <br><br>
                          <img style="width: 40%;" src="<?php echo CUSTOM_VENDOR_PROFILE.$info['address_proof_doc']; ?>">
                        </li>
                      </ul>
                    </div>
                    <div role="tabpanel" class="tab-pane fade" id="tab_content5" aria-labelledby="profile-tab">
                       <ul class="list-unstyled user_data">
                        <li>
                          <label>Identity Number</label><br>
                          <?=($info['identity_number'])? ucfirst($info['identity_number']):''; ?>
                          <br><br>
                          <img style="width: 40%;" src="<?php echo CUSTOM_VENDOR_PROFILE.$info['identity_doc']; ?>">
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
