<div class="right_col" role="main">
  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>User Management <small>| Vendors list</small></h3>
      </div>
    </div>
    <div class="title_right">
      <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search" style="text-align: right">
        <a href="<?=base_url('users/addvendor');?>" class="btn btn-primary"> <i class="fa fa-plus"></i> Add Vendor</a>
      </div>
    </div>
  </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Vendors List<small>Both premium and normal venrods list</small></h2>
              <ul class="nav navbar-right panel_toolbox">
                <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                <li><a class="close-link"><i class="fa fa-close"></i></a></li>
              </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <p class="text-muted font-13 m-b-30"><!-- If you want to write somting you can write here --></p>
            <table id="vendortable" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Business License Number</th>
                  <th>Company Name</th>
                  <th>Vendor Name</th>
                  <th>Email</th>
                  <th>Contact</th>
                  <th>Type</th>
                  <th>Register Date</th>
                  <th>Profile</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <!-- <tr>
                  <td></td>
                  <td>Google</td>
                  <td>DELS<?php echo mt_rand(10000,99999).'NM'.mt_rand(10000,99999);?></td>
                  <td>+<?php echo mt_rand(0,99).'-'.mt_rand(100,999).'-'.mt_rand(100,999).'-'.mt_rand(1000,9999) ?></td>
                  <td>google@abc.xyz</td>
                  <td>Premium</td>
                  <td>01 Jan, 2019</td>
                  <td>31 Dec, 2019</td>
                  <td>2.15%</td>
                  <td>Active</td>
                  <td>
                    <select class="btn btn-primary">
                      <option><i class="fa fa-check"></i> Active</option>
                      <option><i class="fa fa-times"></i> In-Active</option>
                    </select>
                    <a href="#" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-list"></i> All products</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-print"></i> Order History</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-money"></i> Commission Details</a>
                  </td>
                  <td>A-1, Abc Colony, PQR City, XYZ Country <?php echo mt_rand(400000,999999); ?></td>
                </tr>

                <tr>
                  <td></td>
                  <td>Microsoft</td>
                  <td>DELS<?php echo mt_rand(10000,99999).'NM'.mt_rand(10000,99999);?></td>
                  <td>+<?php echo mt_rand(0,99).'-'.mt_rand(100,999).'-'.mt_rand(100,999).'-'.mt_rand(1000,9999) ?></td>
                  <td>Microsoft@abc.xyz</td>
                  <td>Premium</td>
                  <td>01 Jan, 2019</td>
                  <td>31 Dec, 2019</td>
                  <td>2.15%</td>
                  <td>Active</td>
                  <td>
                    <select class="btn btn-primary">
                      <option><i class="fa fa-check"></i> Active</option>
                      <option><i class="fa fa-times"></i> In-Active</option>
                    </select>
                    <a href="#" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-list"></i> All products</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-print"></i> Order History</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-money"></i> Commission Details</a>
                  </td>
                  <td>A-1, Abc Colony, PQR City, XYZ Country <?php echo mt_rand(400000,999999); ?></td>
                </tr>

                <tr>
                  <td></td>
                  <td>IBM</td>
                  <td>DEALS<?php echo mt_rand(10000,99999).'NM'.mt_rand(10000,99999);?></td>
                  <td>+<?php echo mt_rand(0,99).'-'.mt_rand(100,999).'-'.mt_rand(100,999).'-'.mt_rand(1000,9999) ?></td>
                  <td>IBM@abc.xyz</td>
                  <td>Normal</td>
                  <td>01 Jan, 2019</td>
                  <td>31 Dec, 2019</td>
                  <td>2.15%</td>
                  <td>Active</td>
                  <td>
                    <select class="btn btn-primary">
                      <option><i class="fa fa-check"></i> Active</option>
                      <option><i class="fa fa-times"></i> In-Active</option>
                    </select>
                    <a href="#" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-list"></i> All products</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-print"></i> Order History</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-money"></i> Commission Details</a>
                  </td>
                  <td>A-1, Abc Colony, PQR City, XYZ Country <?php echo mt_rand(400000,999999); ?></td>
                </tr>

                <tr>
                  <td></td>
                  <td>AT&T</td>
                  <td>DELS<?php echo mt_rand(10000,99999).'NM'.mt_rand(10000,99999);?></td>
                  <td>+<?php echo mt_rand(0,99).'-'.mt_rand(100,999).'-'.mt_rand(100,999).'-'.mt_rand(1000,9999) ?></td>
                  <td>AT&T@abc.xyz</td>
                  <td>Premium</td>
                  <td>01 Jan, 2019</td>
                  <td>31 Dec, 2019</td>
                  <td>2.15%</td>
                  <td>Active</td>
                  <td>
                    <select class="btn btn-primary">
                      <option><i class="fa fa-check"></i> Active</option>
                      <option><i class="fa fa-times"></i> In-Active</option>
                    </select>
                    <a href="#" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-list"></i> All products</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-print"></i> Order History</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-money"></i> Commission Details</a>
                  </td>
                  <td>A-1, Abc Colony, PQR City, XYZ Country <?php echo mt_rand(400000,999999); ?></td>
                </tr>

                <tr>
                  <td></td>
                  <td>Apple</td>
                  <td>DELS<?php echo mt_rand(10000,99999).'NM'.mt_rand(10000,99999);?></td>
                  <td>+<?php echo mt_rand(0,99).'-'.mt_rand(100,999).'-'.mt_rand(100,999).'-'.mt_rand(1000,9999) ?></td>
                  <td>Apple@abc.xyz</td>
                  <td>Normal</td>
                  <td>01 Jan, 2019</td>
                  <td>31 Dec, 2019</td>
                  <td>2.15%</td>
                  <td>Active</td>
                  <td>
                    <select class="btn btn-primary">
                      <option><i class="fa fa-check"></i> Active</option>
                      <option><i class="fa fa-times"></i> In-Active</option>
                    </select>
                    <a href="#" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-list"></i> All products</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-print"></i> Order History</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-money"></i> Commission Details</a>
                  </td>
                  <td>A-1, Abc Colony, PQR City, XYZ Country <?php echo mt_rand(400000,999999); ?></td>
                </tr>

                <tr>
                  <td></td>
                  <td>Samsung Vendor Group</td>
                  <td>DELS<?php echo mt_rand(10000,99999).'NM'.mt_rand(10000,99999);?></td>
                  <td>+<?php echo mt_rand(0,99).'-'.mt_rand(100,999).'-'.mt_rand(100,999).'-'.mt_rand(1000,9999) ?></td>
                  <td>SamsungVendorGroup@abc.xyz</td>
                  <td>Premium</td>
                  <td>01 Jan, 2019</td>
                  <td>31 Dec, 2019</td>
                  <td>2.15%</td>
                  <td>Active</td>
                  <td>
                    <select class="btn btn-primary">
                      <option><i class="fa fa-check"></i> Active</option>
                      <option><i class="fa fa-times"></i> In-Active</option>
                    </select>
                    <a href="#" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-list"></i> All products</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-print"></i> Order History</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-money"></i> Commission Details</a>
                  </td>
                  <td>A-1, Abc Colony, PQR City, XYZ Country <?php echo mt_rand(400000,999999); ?></td>
                </tr>

                <tr>
                  <td></td>
                  <td>Dell Technologies Vendor Group</td>
                  <td>DELS<?php echo mt_rand(10000,99999).'NM'.mt_rand(10000,99999);?></td>
                  <td>+<?php echo mt_rand(0,99).'-'.mt_rand(100,999).'-'.mt_rand(100,999).'-'.mt_rand(1000,9999) ?></td>
                  <td>DellTechnologiesVendorGroup@abc.xyz</td>
                  <td>Normal</td>
                  <td>01 Jan, 2019</td>
                  <td>31 Dec, 2019</td>
                  <td>2.15%</td>
                  <td>Active</td>
                  <td>
                    <select class="btn btn-primary">
                      <option><i class="fa fa-check"></i> Active</option>
                      <option><i class="fa fa-times"></i> In-Active</option>
                    </select>
                    <a href="#" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-list"></i> All products</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-print"></i> Order History</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-money"></i> Commission Details</a>
                  </td>
                  <td>A-1, Abc Colony, PQR City, XYZ Country <?php echo mt_rand(400000,999999); ?></td>
                </tr>

                <tr>
                  <td></td>
                  <td>Intel</td>
                  <td>DELS<?php echo mt_rand(10000,99999).'NM'.mt_rand(10000,99999);?></td>
                  <td>+<?php echo mt_rand(0,99).'-'.mt_rand(100,999).'-'.mt_rand(100,999).'-'.mt_rand(1000,9999) ?></td>
                  <td>Intel@abc.xyz</td>
                  <td>Premium</td>
                  <td>01 Jan, 2019</td>
                  <td>31 Dec, 2019</td>
                  <td>2.15%</td>
                  <td>Active</td>
                  <td>
                    <select class="btn btn-primary">
                      <option><i class="fa fa-check"></i> Active</option>
                      <option><i class="fa fa-times"></i> In-Active</option>
                    </select>
                    <a href="#" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-list"></i> All products</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-print"></i> Order History</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-money"></i> Commission Details</a>
                  </td>
                  <td>A-1, Abc Colony, PQR City, XYZ Country <?php echo mt_rand(400000,999999); ?></td>
                </tr>

                <tr>
                  <td></td>
                  <td>HP Inc </td>
                  <td>DELS<?php echo mt_rand(10000,99999).'NM'.mt_rand(10000,99999);?></td>
                  <td>+<?php echo mt_rand(0,99).'-'.mt_rand(100,999).'-'.mt_rand(100,999).'-'.mt_rand(1000,9999) ?></td>
                  <td>HP Inc @abc.xyz</td>
                  <td>Premium</td>
                  <td>01 Jan, 2019</td>
                  <td>31 Dec, 2019</td>
                  <td>2.15%</td>
                  <td>Active</td>
                  <td>
                    <select class="btn btn-primary">
                      <option><i class="fa fa-check"></i> Active</option>
                      <option><i class="fa fa-times"></i> In-Active</option>
                    </select>
                    <a href="#" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-list"></i> All products</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-print"></i> Order History</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-money"></i> Commission Details</a>
                  </td>
                  <td>A-1, Abc Colony, PQR City, XYZ Country <?php echo mt_rand(400000,999999); ?></td>
                </tr>

                <tr>
                  <td></td>
                  <td>HPE</td>
                  <td>DELS<?php echo mt_rand(10000,99999).'NM'.mt_rand(10000,99999);?></td>
                  <td>+<?php echo mt_rand(0,99).'-'.mt_rand(100,999).'-'.mt_rand(100,999).'-'.mt_rand(1000,9999) ?></td>
                  <td>HPE@abc.xyz</td>
                  <td>Normal</td>
                  <td>01 Jan, 2019</td>
                  <td>31 Dec, 2019</td>
                  <td>2.15%</td>
                  <td>Active</td>
                  <td>
                    <select class="btn btn-primary">
                      <option><i class="fa fa-check"></i> Active</option>
                      <option><i class="fa fa-times"></i> In-Active</option>
                    </select>
                    <a href="#" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-list"></i> All products</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-print"></i> Order History</a>
                    <a href="#" class="btn btn-primary"><i class="fa fa-money"></i> Commission Details</a>
                  </td>
                  <td>A-1, Abc Colony, PQR City, XYZ Country <?php echo mt_rand(400000,999999); ?></td>
                </tr> -->
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

