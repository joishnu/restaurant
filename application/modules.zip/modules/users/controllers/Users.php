<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

	class Users extends CI_Controller {
		public $user_type = array( 1=>"Main", 2=>"Sub" );
		public $active_status = array('1' => "Activate" , '2'=>"Deactivate");
		function __construct(){
			parent::__construct();
			$this->load->library('external');
			$this->load->model('users_model','users');
			$this->load->model('general/general_model','general');
		}
		/* ** ** ** User management  Starts ** ** ** */

		public function edit_vendor($vendor_id = ''){
			if(!$vendor_id){
				redirect('/users/vendor', 'refresh');
			}
			$data['title'] = 'Vendor Details';
			$data['page'] = 'edit_vendor';
			$data['countries'] = $this->general->get_all_country();
			$data['role'] = $this->users->get_roles();
			$data['extra_datatable_data'] = $this->external->validation_extra_js_css();
			$data['extra_datatable_data'] .= $this->external->wizard();
			$data['extra_datatable_data'] .= $this->external->datetimepciker();
			$data['info'] = $this->users->get_vendor_complete_info_by_id($vendor_id);

			$data['extra_datatable_data'] .= '<script>
				$("#valid_date").datetimepicker({
					format: "DD-MM-YYYY"
				});

				var selectData = "'.$data["info"]["cities"]["country_id"].'";

					$.ajax({
						type: "POST",
						url: "'.base_url('general/states_ajax').'",
						data: {
							"country": selectData },
							success: function (json) {
								$("#state").html(json);
								$("#state").val("'.$data["info"]["cities"]["state_id"].'");
							}
						});

				var selectData = "'.$data["info"]["cities"]["state_id"].'";
						$.ajax({
							type: "POST",
							url: "'.base_url('general/cities_ajax').'",
							data: {"state": selectData },
							success: function (json) {
								$("#city").html(json);
								$("#city").val("'.$data["info"]["city_id"].'");

							}
						});


				$("#country").on("change", function () {
					var selectData = $(this).val();
					$.ajax({
						type: "POST",
						url: "'.base_url('general/states_ajax').'",
						data: {
							"country": selectData },
							success: function (json) {
								$("#state").html(json);
							}
						});
					});
					$("#state").on("change", function () {
						var selectData = $(this).val();
						$.ajax({
							type: "POST",
							url: "'.base_url('general/cities_ajax').'",
							data: {"state": selectData },
							success: function (json) {
								$("#city").html(json);
							}
						});
					});

					

    				
			</script>';
			

			$this->load->view('template',$data);
		}
		public function index(){
			
			$data['title'] = 'Users Management';
			$data['page'] = 'vendor_list';
			$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();
			$data['extra_datatable_data'] .= '<script type="text/javascript">
										$(document).ready(function (){
										$("#vendortable").DataTable({
										"processing": true,
										"serverSide": true,
										"ajax":{
										"url": "'.base_url('users/vendor_list').'",
										"dataType": "json",
										"type": "POST",
										"data":{
										"'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'"
										}
										},
										"columns": [
										{ "data": "id" },
										{ "data": "bln" },
										{ "data": "vendor" },
										{ "data": "contact_person" },
										{ "data": "email" },
										{ "data": "phone" },
										{ "data": "type" },
										{ "data": "registered" },
										{ "data": "profile" },
										{ "data": "status" },
										{ "data": "action" },
										]
										});
										});
										function change_status(that){
											var number = $(that).attr("data-number");
											var status = $(that).val();
											$.ajax({
												url: "'.base_url('users/change_status_users').'",
												data: {
													"number": number,
													"status": status
												},
												cache: false,
												type: "POST",
												success: function(response) {
													console.log(response);
													$("#vendortable").DataTable().ajax.reload();
												},
												error: function(xhr) {
													console.log(xhr);
												}
											});
										}
	</script>
	';
	$this->load->view('template',$data);
	}
	/* ** ** ** Vendor Panel ** ** ** */
	public function vendor(){
		self::index();
	}
	public function addvendor($value=''){
		$this->load->library('external');
		
		$data['title'] = 'Add New Vendor';
		$data['page'] = 'addvendor';
		$data['countries'] = $this->general->get_all_country();
		$data['role'] = $this->users->get_roles();
		$data['extra_datatable_data'] = $this->external->validation_extra_js_css();
		$data['extra_datatable_data'] .= $this->external->wizard();
		$data['extra_datatable_data'] .= $this->external->datetimepciker();
		$data['extra_datatable_data'] .= '<script>
			$("#valid_date").datetimepicker({
				format: "DD-MM-YYYY"
			});
			$("#country").on("change", function () {
				var selectData = $(this).val();
				$.ajax({
					type: "POST",
					url: "'.base_url('general/states_ajax').'",
					data: {
						"country": selectData },
						success: function (json) {
							$("#state").html(json);
						}
					});
				});
				$("#state").on("change", function () {
					var selectData = $(this).val();
					$.ajax({
						type: "POST",
						url: "'.base_url('general/cities_ajax').'",
						data: {"state": selectData },
						success: function (json) {
							$("#city").html(json);
						}
					});
				});
		</script>';
		$this->load->view('template',$data);
	}
	public function viewvendor($vendor_id = ''){
		if(!$vendor_id){
			redirect('/users/vendor', 'refresh');
		}
		$data['title'] = 'Vendor Details';
		$data['page'] = 'view_vendor';
		$data['info'] = $this->users->get_vendor_complete_info_by_id_view($vendor_id);

		//echo "<pre>";print_r($data['info']);exit();
		$this->load->view('template',$data);
		}
	public function vendor_list(){
		$columns = array(
		0=> 'id',
		1=> 'bln',
		2=> 'vendor',
		3=> 'contact_person',
		4=> 'email',
		5=> 'phone',
		6=> 'type',
		7=> 'registered',
		8=> 'profile',
		9=> 'status',
		10=> 'action',
		);
		$limit = $this->input->post('length');
		        $start = $this->input->post('start');
		        $order ="";
		        $dir="";
		        //$order = $columns[$this->input->post('order')[0]['column']];
		        //$dir = $this->input->post('order')[0]['dir'];
		        $totalData = $this->users->table_items_count_admin('admins');
		        $totalFiltered = $totalData; 
		        if(empty($this->input->post('search')['value'])){
		        $posts = $this->users->all_items_vendor($limit,$start,$order,$dir, 'vendors', " vendors.id as id, vendors.user_id as user_id, vendors.vendor_name as company_name, CONCAT(users.first_name,' ',users.last_name) as contact_person, CONCAT('+',users.country_code,'-',users.phone) as phone, users.email as email, users.status as status, users.added_on as register_date, vendors.profile as profile , users.role as type , vendors.business_license_number as bln");
		        }else {
		            $search = $this->input->post('search')['value']; 
		            $posts =  $this->users->item_search($limit,$start,$search,$order,$dir, 'vendors', " vendors.id as id, vendors.user_id as user_id, vendors.vendor_name as company_name, CONCAT(users.first_name,' ',users.last_name) as contact_person, CONCAT('+',users.country_code,'-',users.phone) as phone, users.email as email, vendors.commission as commissions, users.status as status, users.added_on as register_date, vendors.validity as validity, vendors.profile as profile ,users.role as type, vendors.business_license_number as bln ");
		            $totalFiltered = $this->users->item_count_search($search,  'admins');
		        }
		  
		  $data = array();
		if(!empty($posts)){
		foreach ($posts as $post){
		$nestedData['id'] = '';
		$nestedData['bln'] = $post->bln;
		$nestedData['vendor'] = $post->company_name;
		$nestedData['contact_person'] = $post->contact_person;
		$nestedData['email'] = $post->email;
		$nestedData['phone'] = $post->phone;
		$nestedData['type'] = ' Vendor';
		$nestedData['registered'] = $post->register_date;
		$nestedData['profile'] = ($post->profile)? '<img style="max-width:30px; " src="'.CUSTOM_VENDOR_PROFILE.$post->profile.'">' : '<img src="'.ADMIN_PROFILE.'"default.jpg">';
		
		$nestedData['status'] = $this->active_status[$post->status];
		$nestedData['action'] = '
		<select class="btn btn-primary" data-number="'.$post->user_id.'" onchange="return change_status(this)">
			<option value="2" '.(($post->status == 2)? 'selected="selected"' :" ").' >Deactivate </option>
			<option value="1" '.(($post->status == 1)? 'selected="selected"' :" ").'>Activate</option>
		</select>
		<a href="'.base_url('users/viewvendor').'/'.$post->user_id.'" class="btn btn-primary"><i class="fa fa-eye"></i> View </a>
		                <a href="'.base_url('users/edit_vendor').'/'.$post->user_id.'" class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</a>
		               <!-- <a href="#" class="btn btn-primary"><i class="fa fa-list"></i> All products</a>
		                <a href="#" class="btn btn-primary"><i class="fa fa-print"></i> Order History</a>-->
		<!-- <a href="#" class="btn btn-primary"><i class="fa fa-money"></i> Commission Details</a>-->
		';
		// $nestedData['name'] = $post->name;
		// $nestedData['type'] = $this->user_type[$post->type];
		// $nestedData['profile'] = ($post->profile)? '<img style="max-width:30px; " src="'.ADMIN_PROFILE.$post->profile.'">' : '<img src="'.ADMIN_PROFILE.'"default.jpg">';
		// $nestedData['status'] = $this->active_status[$post->status];
		// $nestedData['action'] = '
		// <select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
			// <option value="2" '.(($post->status == 2)? 'selected="selected"' :" ").' >Deactivate </option>
			// <option value="1" '.(($post->status == 1)? 'selected="selected"' :" ").'>Activate</option>
		// </select>
		// <a data-toggle="modal" data-target=".bs-example-modal-lg"><button class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</button></a>
		// ';
		$data[] = $nestedData;
		}
		}
		$json_data = array(
		"draw"            => intval($this->input->post('draw')),  
		"recordsTotal"    => intval($totalData),  
		"recordsFiltered" => intval($totalFiltered), 
		"data"            => $data   
		);
		echo json_encode($json_data); 
	}
	
	public function addvendor_back(){
			$this->load->helper('security');
				$this->form_validation->set_rules('first_name','first_name','required');
				$this->form_validation->set_rules('last_name','last_name','required');
				$this->form_validation->set_rules('email','email','required');
				$this->form_validation->set_rules('country_code','country_code','required');
				$this->form_validation->set_rules('phone','phone','required');
				// $this->form_validation->set_rules('role','role','required');
				// $this->form_validation->set_rules('valid_date','valid_date','required');
				$this->form_validation->set_rules('company_name','company_name','required');
				// $this->form_validation->set_rules('type','type','required');
				//$this->form_validation->set_rules('commission','commission','required');
				// $this->form_validation->set_rules('address','address','required');
				// $this->form_validation->set_rules('country','country','required');
				// $this->form_validation->set_rules('state','state','required');
				$this->form_validation->set_rules('city','city','required');
				// $this->form_validation->set_rules('officenumber','officenumber','required');
				$this->form_validation->set_rules('license','license','required');
				// $this->form_validation->set_rules('license_file','license_file','required');
				// $this->form_validation->set_rules('address_proof','address_proof','required');
				// $this->form_validation->set_rules('address_proof_file','address_proof_file','required');
				// $this->form_validation->set_rules('identity','identity','required');
				// $this->form_validation->set_rules('identity_file','identity_file','required');
				// $this->form_validation->set_rules('files','files','required');
				// $this->form_validation->set_rules('additional','additional','required');
				$this->form_validation->set_rules('status','license_file','required');
				$this->form_validation->set_rules('password','license_file','required');
				//echo "<pre>";print_r($this->input->post(NULL, true));exit();
			if ($this->form_validation->run() == FALSE){
					echo "error";
					echo validation_errors();
				}else{
			$info=$this->input->post(NULL, true);
			$i=1;
		
			for($i=1;$i<=5;$i++)
			{
				if($info['address'.$i]!='')
				{
					$add[]= array(
						'address'=>trim($this->input->post('address'.$i)),
						'latitude'=>trim($this->input->post('address'.$i.'_lat')),
						'longtitude'=>trim($this->input->post('address'.$i.'_long')),
						'created_on'=>date('Y-m-d h:i:s'));
				}
			}

		$user_information = array(
				'users'=>array(
				'first_name'=>trim($this->input->post('first_name')),
				'last_name'=>trim($this->input->post('last_name')),
				'country_code'=>trim($this->input->post('country_code')),
				'phone'=>trim($this->input->post('phone')),
				'email'=>trim($this->input->post('email')),
				'password'=>do_hash(trim($this->input->post('password'))),
				'user_type'=>2,
				'role'=>1,
				'is_email'=>1,
				'is_phone'=>1,
				'status'=>trim($this->input->post('status')),
				'updated_on'=>date('Y-m-d h:i:s')),
				'vendor_information' => array(
				'vendor_name' =>trim($this->input->post('company_name')) ,
				'type' =>1 ,
				'city_id' =>trim($this->input->post('city')) ,
				//'commission' => trim($this->input->post('commission')),
				'commission' => 0,
				'validity' => date('Y-m-d', strtotime(trim($this->input->post('valid_date')))),
				'address' =>trim($this->input->post('address')) ,
				'office_number' => trim($this->input->post('officenumber')),
				'business_license_number' =>trim($this->input->post('license')) ,
				'address_proof_number' =>trim($this->input->post('address_proof')) ,
				'identity_number' => trim($this->input->post('identity')),
				'additional' => trim($this->input->post('additional')),
				'gst' => trim($this->input->post('gst')),
				'is_document' => 1,
		),
		
		'address'=>$add,
		'bank'=>array(
		'branch_name'=>trim($this->input->post('branch_name')),
		'bank_name'=>trim($this->input->post('bank_name')),
		'account_name'=>trim($this->input->post('bank_ac')),
		'account_number'=>trim($this->input->post('account_no')),
		'ifsc'=>trim($this->input->post('ifsc')),
		'added_on'=>date('Y-m-d h:i:s')
		),
		/*'commission_information' => array(
		'amount'=>trim($this->input->post('commission')),
		'updated_on'=>date('Y-m-d h:i:s'),
		'added_by'=>'1' // here put admin session id
		)*/
		);

		//echo "<pre>";print_r($add);exit();
		if(isset($_FILES['license_file'])){
		            foreach ($_FILES['license_file']['name'] as $key => $value) {
		                $_FILES['images[]']['name']= $_FILES['license_file']['name'][$key];
		                $_FILES['images[]']['type']= $_FILES['license_file']['type'][$key];
		                $_FILES['images[]']['tmp_name']= $_FILES['license_file']['tmp_name'][$key];
		                $_FILES['images[]']['error']= $_FILES['license_file']['error'][$key];
		                $_FILES['images[]']['size']= $_FILES['license_file']['size'][$key];
		unset( $config);
		                
		                //$config['upload_path']          = './assets/uploads/documents/vendor/';
		                $config['upload_path']          = $_SERVER['DOCUMENT_ROOT'].'/'.PROJECT_NAME.'/admin/uploads/documents/vendor/';
		                $config['allowed_types']        = 'gif|jpg|png|jpeg';
		                $config['max_size']             = '*';
		                $config['max_width']            = '*';
		                $config['max_height']           = '*';
		                $config['file_name']            = date('ymdHis').mt_rand(1000,99999) ;
		                $images = array();
		                $this->load->library('upload', $config);
		                if ( ! $this->upload->do_upload('images[]')){
		                    $error = array('error' => $this->upload->display_errors());
		                    print_r($error);
		                    break;
		                }else{
		                    $data = array('upload_data' => $this->upload->data());
		                    $arr[]=  $data['upload_data']['raw_name'].$data['upload_data']['file_ext'];
		                }
		            }
		            if(isset($arr)){
		                $user_information['vendor_information']['business_license_doc'] = implode(',', $arr);
		                unset($arr);
		            }
		        }
		if(isset($_FILES['address_proof_file'])){
		            foreach ($_FILES['address_proof_file']['name'] as $key => $value) {
		                $_FILES['images[]']['name']= $_FILES['address_proof_file']['name'][$key];
		                $_FILES['images[]']['type']= $_FILES['address_proof_file']['type'][$key];
		                $_FILES['images[]']['tmp_name']= $_FILES['address_proof_file']['tmp_name'][$key];
		                $_FILES['images[]']['error']= $_FILES['address_proof_file']['error'][$key];
		                $_FILES['images[]']['size']= $_FILES['address_proof_file']['size'][$key];
		unset( $config);
		                //$config['upload_path']          = './assets/uploads/documents/vendor/';
		                $config['upload_path']          = $_SERVER['DOCUMENT_ROOT'].'/'.PROJECT_NAME.'/admin/uploads/documents/vendor/';
		                $config['allowed_types']        = 'gif|jpg|png|jpeg';
		                $config['max_size']             = '*';
		                $config['max_width']            = '*';
		                $config['max_height']           = '*';
		                $config['file_name']            = date('ymdHis').mt_rand(1000,99999) ;
		                $images = array();
		                $this->load->library('upload', $config);
		                if ( ! $this->upload->do_upload('images[]')){
		                    $error = array('error' => $this->upload->display_errors());
		                    print_r($error);
		                    break;
		                }else{
		                    $data = array('upload_data' => $this->upload->data());
		                    $arr[]=  $data['upload_data']['raw_name'].$data['upload_data']['file_ext'];
		                }
		            }
		            if(isset($arr)){
		                $user_information['vendor_information']['address_proof_doc'] = implode(',', $arr);
		            unset($arr);
		            }
		        }
		if(isset($_FILES['identity_file'])){
		            foreach ($_FILES['identity_file']['name'] as $key => $value) {
		                $_FILES['images[]']['name']= $_FILES['identity_file']['name'][$key];
		                $_FILES['images[]']['type']= $_FILES['identity_file']['type'][$key];
		                $_FILES['images[]']['tmp_name']= $_FILES['identity_file']['tmp_name'][$key];
		                $_FILES['images[]']['error']= $_FILES['identity_file']['error'][$key];
		                $_FILES['images[]']['size']= $_FILES['identity_file']['size'][$key];
		unset( $config);
		                //$config['upload_path']          = './assets/uploads/documents/vendor/';
		                $config['upload_path']          = $_SERVER['DOCUMENT_ROOT'].'/'.PROJECT_NAME.'/admin/uploads/documents/vendor/';
		                $config['allowed_types']        = 'gif|jpg|png|jpeg';
		                $config['max_size']             = '*';
		                $config['max_width']            = '*';
		                $config['max_height']           = '*';
		                $config['file_name']            = date('ymdHis').mt_rand(1000,99999) ;
		                $images = array();
		                $this->load->library('upload', $config);
		                if ( ! $this->upload->do_upload('images[]')){
		                    $error = array('error' => $this->upload->display_errors());
		                    print_r($error);
		                    break;
		                }else{
		                    $data = array('upload_data' => $this->upload->data());
		                    $arr[]=  $data['upload_data']['raw_name'].$data['upload_data']['file_ext'];
		                }
		            }
		            if(isset($arr)){
		                $user_information['vendor_information']['identity_doc'] = implode(',', $arr);
		                unset($arr);
		            }
		        }
		        if(isset($_FILES['files'])){
		            foreach ($_FILES['files']['name'] as $key => $value) {
		                $_FILES['images[]']['name']= $_FILES['files']['name'][$key];
		                $_FILES['images[]']['type']= $_FILES['files']['type'][$key];
		                $_FILES['images[]']['tmp_name']= $_FILES['files']['tmp_name'][$key];
		                $_FILES['images[]']['error']= $_FILES['files']['error'][$key];
		                $_FILES['images[]']['size']= $_FILES['files']['size'][$key];
		unset( $config);
		                //$config['upload_path']          = './assets/uploads/profiles/vendor/';
		                $config['upload_path']          = $_SERVER['DOCUMENT_ROOT'].'/'.PROJECT_NAME.'/admin/uploads/profiles/vendor/';
		                $config['allowed_types']        = 'gif|jpg|png|jpeg';
		                $config['max_size']             = '*';
		                $config['max_width']            = '*';
		                $config['max_height']           = '*';
		                $config['file_name']            = date('ymdHis').mt_rand(1000,99999) ;
		                $images = array();
		                $this->load->library('upload', $config);
		                if ( ! $this->upload->do_upload('images[]')){
		                    $error = array('error' => $this->upload->display_errors());
		                    print_r($error);
		                    break;
		                }else{
		                    $data = array('upload_data' => $this->upload->data());
		                    $arr[]=  $data['upload_data']['raw_name'].$data['upload_data']['file_ext'];
		                }
		            }
		            if(isset($arr)){
		                $user_information['vendor_information']['profile'] = implode(',', $arr);
		                unset($arr);
		            }
		        }
		$daa =$this->users->add_vendor($user_information);
		if($daa)
		redirect('/users/vendor', 'refresh');
		else
		echo "already exist";
		
		}
		}
		/* ** ** ** Customer Panel ** ** ** */
		public function customer(){
		$data['title'] = 'Users Management';
		$data['page'] = 'customer_list';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();       
		$data['extra_datatable_data'] .= '<script type="text/javascript">
		$(document).ready(function (){
		    $("#customertable").DataTable({
		        "processing": true,
		        "serverSide": true,
		        "ajax":{
		            "url": "'.base_url('users/customer_list').'",
		            "dataType": "json",
		            "type": "POST",
		            "data":{
		              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
		            }
		        },
		        "columns": [
		          { "data": "id" },
		          { "data": "name" },
		          { "data": "contact" },
		          { "data": "email" },
		          { "data": "type" },
		          { "data": "regsiter" },
		          { "data": "status" },
		          { "data": "action" },
		        ]
		    });
		});
		function change_status(that){
		var number = $(that).attr("data-number");
		var status = $(that).val();
		$.ajax({
		url: "'.base_url('users/change_status_users').'",
		data: { 
		"number": number, 
		"status": status
		},
		cache: false,
		type: "POST",
		success: function(response) {
		console.log(response);
		$("#customertable").DataTable().ajax.reload();
		},
		error: function(xhr) {
		console.log(xhr);
		}
		});
		}
		</script>
		';
		$this->load->view('template',$data);
		}
		public function customer_list(){
		$columns = array(
				0=> 'id',
				1=> 'name',
				2=> 'contact',
				3=> 'email',
				4=> 'type',
				5=> 'regsiter',
				6=> 'status',
				7=> 'action',
		);
		$limit = $this->input->post('length');
		        $start = $this->input->post('start');
		        $order = $columns[$this->input->post('order')[0]['column']];
		        $dir = $this->input->post('order')[0]['dir'];
		        $totalData = $this->users->table_items_count_customer('users');
		        $totalFiltered = $totalData; 
		        if(empty($this->input->post('search')['value'])){
		        $posts = $this->users->all_items_customer($limit,$start,$order,$dir, 'users', "users.id as user_id, CONCAT(users.first_name,' ',users.last_name) as name, CONCAT('+',users.country_code,'-',users.phone) as phone, users.email as email, users.status as status, users.added_on as added_on,users.role as type");
		        }else {
		            $search = $this->input->post('search')['value']; 
		            $posts =  $this->users->item_search($limit,$start,$search,$order,$dir, 'users', "users.id as user_id, CONCAT(users.first_name,' ',users.last_name) as name, CONCAT('+',users.country_code,'-',users.phone) as phone, users.email as email, users.status as status, users.added_on as added_on, users.role as type");
		            $totalFiltered = $this->users->item_count_search($search,  'admins');
		        }
		$data = array();
		if(!empty($posts)){
		foreach ($posts as $post){
			$txt="";
			if($post->type==1)
			{
				$txt="Admin";
			}else if($post->type==2)
			{
				$txt="Vendor";
			}else{
				$txt="Customer";
			}
		$nestedData['id'] = '';
		$nestedData['name'] = $post->name;
		$nestedData['contact'] = $post->phone;
		$nestedData['email'] = $post->email;
		$nestedData['type'] = $txt;
		$nestedData['regsiter'] = $post->added_on;
		// $nestedData['profile'] = ($post->profile)? '<img style="max-width:30px; " src="'.ADMIN_PROFILE.$post->profile.'">' : '<img src="'.ADMIN_PROFILE.'"default.jpg">';
		$nestedData['status'] = $this->active_status[$post->status];
		$nestedData['action'] = '
		<select class="btn btn-primary" data-number="'.$post->user_id.'" onchange="return change_status(this)">
			<option value="2" '.(($post->status == 2)? 'selected="selected"' :" ").' >Deactivate </option>
			<option value="1" '.(($post->status == 1)? 'selected="selected"' :" ").'>Activate</option>
		</select>
		                <a href="'.base_url('order_management/customer_order/').$post->user_id.'" class="btn btn-primary">Order History</a>
		';
		// $nestedData['name'] = $post->name;
		// $nestedData['type'] = $this->user_type[$post->type];
		// $nestedData['profile'] = ($post->profile)? '<img style="max-width:30px; " src="'.ADMIN_PROFILE.$post->profile.'">' : '<img src="'.ADMIN_PROFILE.'"default.jpg">';
		// $nestedData['status'] = $this->active_status[$post->status];
		// $nestedData['action'] = '
		// <select class="btn btn-primary" data-number="'.$post->id.'" onchange="return change_status(this)">
			// <option value="2" '.(($post->status == 2)? 'selected="selected"' :" ").' >Deactivate </option>
			// <option value="1" '.(($post->status == 1)? 'selected="selected"' :" ").'>Activate</option>
		// </select>
		// <a data-toggle="modal" data-target=".bs-example-modal-lg"><button class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</button></a>
		// ';
		$data[] = $nestedData;
		}
		}
		$json_data = array(
		"draw"            => intval($this->input->post('draw')),  
		"recordsTotal"    => intval($totalData),  
		"recordsFiltered" => intval($totalFiltered), 
		"data"            => $data   
		);
		echo json_encode($json_data); 
		}
		/* ** ** ** admin Panel ** ** ** */
		public function admin(){
		//country list
		$this->load->model('general/general_model','general');
		$data['countries'] = $this->general->get_all_country();
		$data['title'] = 'Users Management';
		$data['page'] = 'admin_list';       
		$data['extra_datatable_data'] = $this->external->datatable_extra_js_css();       
		$data['extra_datatable_data'] .= $this->external->validation_extra_js_css();       
		$data['extra_datatable_data'] .= $this->external->datetimepciker();       
		$data['extra_datatable_data'] .= '<script type="text/javascript">
		$(document).ready(function (){
		    $("#admintable").DataTable({
		        "processing": true,
		        "serverSide": true,
		        "ajax":{
		            "url": "'.base_url('users/admin_list').'",
		            "dataType": "json",
		            "type": "POST",
		            "data":{
		              "'.$this->security->get_csrf_token_name().'" : "'.$this->security->get_csrf_hash().'" 
		            }
		        },
		        "columns": [
		          { "data": "id" },
		          { "data": "name" },
		          { "data": "phone" },
		          { "data": "email" },
		          { "data": "type" },
		          { "data": "registered" },
		          { "data": "status" },
		          { "data": "action" },
		        ]
		    });
		});
		function change_status(that){
		var number = $(that).attr("data-number");
		var status = $(that).val();
		
		$.ajax({
		url: "'.base_url('users/change_status_users').'",
		data: { 
		"number": number, 
		"status": status
		},
		cache: false,
		type: "POST",
		success: function(response) {
		console.log(response);
		$("#admintable").DataTable().ajax.reload();
		},
		error: function(xhr) {
		console.log(xhr);
		}
		});
		}
		
		</script>
		';
		$this->load->view('template',$data);
		}







	public function update_vendor(){
		
			$this->load->helper('security');
				$this->form_validation->set_rules('first_name','first_name','required');
				$this->form_validation->set_rules('last_name','last_name','required');
				$this->form_validation->set_rules('email','email','required');
				$this->form_validation->set_rules('country_code','country_code','required');
				$this->form_validation->set_rules('phone','phone','required');
				// $this->form_validation->set_rules('role','role','required');
				// $this->form_validation->set_rules('valid_date','valid_date','required');
				$this->form_validation->set_rules('company_name','company_name','required');
				// $this->form_validation->set_rules('type','type','required');
				//$this->form_validation->set_rules('commission','commission','required');
				// $this->form_validation->set_rules('address','address','required');
				// $this->form_validation->set_rules('country','country','required');
				// $this->form_validation->set_rules('state','state','required');
				$this->form_validation->set_rules('city','city','required');
				// $this->form_validation->set_rules('officenumber','officenumber','required');
				$this->form_validation->set_rules('license','license','required');
				// $this->form_validation->set_rules('license_file','license_file','required');
				// $this->form_validation->set_rules('address_proof','address_proof','required');
				// $this->form_validation->set_rules('address_proof_file','address_proof_file','required');
				// $this->form_validation->set_rules('identity','identity','required');
				// $this->form_validation->set_rules('identity_file','identity_file','required');
				// $this->form_validation->set_rules('files','files','required');
				// $this->form_validation->set_rules('additional','additional','required');
				$this->form_validation->set_rules('status','license_file','required');
				$this->form_validation->set_rules('password','license_file','required');
				//echo "<pre>";print_r($this->input->post(NULL, true));exit();
			if ($this->form_validation->run() == FALSE){
					echo "error";
					echo validation_errors();
				}else{
			$info=$this->input->post(NULL, true);
			$i=1;
		
			for($i=1;$i<=5;$i++)
			{
				if($info['address'.$i]!='')
				{
					$add[]= array(
						'address'=>trim($this->input->post('address'.$i)),
						'latitude'=>trim($this->input->post('address'.$i.'_lat')),
						'longtitude'=>trim($this->input->post('address'.$i.'_long')),
						'id'=>trim($this->input->post('address'.$i.'_id')),
						'created_on'=>date('Y-m-d h:i:s'));
				}
			}

		$user_information = array(
				'users'=>array(
				'first_name'=>trim($this->input->post('first_name')),
				'last_name'=>trim($this->input->post('last_name')),
				'country_code'=>trim($this->input->post('country_code')),
				'phone'=>trim($this->input->post('phone')),
				'email'=>trim($this->input->post('email')),
				'password'=>do_hash(trim($this->input->post('password'))),
				'user_type'=>2,
				'role'=>1,
				'status'=>trim($this->input->post('status')),
				'updated_on'=>date('Y-m-d h:i:s')),
				'vendor_information' => array(
				'vendor_name' =>trim($this->input->post('company_name')) ,
				'type' =>1 ,
				'city_id' =>trim($this->input->post('city')) ,
				//'commission' => trim($this->input->post('commission')),
				'commission' => 0,
				'validity' => date('Y-m-d', strtotime(trim($this->input->post('valid_date')))),
				'address' =>trim($this->input->post('address')) ,
				'office_number' => trim($this->input->post('officenumber')),
				'business_license_number' =>trim($this->input->post('license')) ,
				'address_proof_number' =>trim($this->input->post('address_proof')) ,
				'identity_number' => trim($this->input->post('identity')),
				'additional' => trim($this->input->post('additional')),
				'gst' => trim($this->input->post('gst')),
				'is_document' => 1,
		),
		
		'address'=>$add,
		'bank'=>array(
		'bank_name'=>trim($this->input->post('bank_name')),
		'account_name'=>trim($this->input->post('bank_ac')),
		'account_number'=>trim($this->input->post('account_no')),
		'ifsc'=>trim($this->input->post('ifsc')),
		'added_on'=>date('Y-m-d h:i:s')
		),
		/*'commission_information' => array(
		'amount'=>trim($this->input->post('commission')),
		'updated_on'=>date('Y-m-d h:i:s'),
		'added_by'=>'1' // here put admin session id
		)*/
		);

		
		if((isset($_FILES['license_file']))&&!empty($_FILES['license_file']['name'][0])){
		            foreach ($_FILES['license_file']['name'] as $key => $value) {
		                $_FILES['images[]']['name']= $_FILES['license_file']['name'][$key];
		                $_FILES['images[]']['type']= $_FILES['license_file']['type'][$key];
		                $_FILES['images[]']['tmp_name']= $_FILES['license_file']['tmp_name'][$key];
		                $_FILES['images[]']['error']= $_FILES['license_file']['error'][$key];
		                $_FILES['images[]']['size']= $_FILES['license_file']['size'][$key];
		unset( $config);
		                
		                //$config['upload_path']          = './assets/uploads/documents/vendor/';
		                $config['upload_path']          = $_SERVER['DOCUMENT_ROOT'].'/'.PROJECT_NAME.'/admin/uploads/documents/vendor/';
		                $config['allowed_types']        = 'gif|jpg|png|jpeg';
		                $config['max_size']             = '*';
		                $config['max_width']            = '*';
		                $config['max_height']           = '*';
		                $config['file_name']            = date('ymdHis').mt_rand(1000,99999) ;
		                $images = array();
		                $this->load->library('upload', $config);
		                if ( ! $this->upload->do_upload('images[]')){
		                    $error = array('error' => $this->upload->display_errors());
		                    print_r($error);
		                    break;
		                }else{
		                    $data = array('upload_data' => $this->upload->data());
		                    $arr[]=  $data['upload_data']['raw_name'].$data['upload_data']['file_ext'];
		                }
		            }
		            if(isset($arr)){
		                $user_information['vendor_information']['business_license_doc'] = implode(',', $arr);
		                unset($arr);
		            }
		        }
		if((isset($_FILES['address_proof_file']))&&!empty($_FILES['address_proof_file']['name'][0])){
		            foreach ($_FILES['address_proof_file']['name'] as $key => $value) {
		                $_FILES['images[]']['name']= $_FILES['address_proof_file']['name'][$key];
		                $_FILES['images[]']['type']= $_FILES['address_proof_file']['type'][$key];
		                $_FILES['images[]']['tmp_name']= $_FILES['address_proof_file']['tmp_name'][$key];
		                $_FILES['images[]']['error']= $_FILES['address_proof_file']['error'][$key];
		                $_FILES['images[]']['size']= $_FILES['address_proof_file']['size'][$key];
		unset( $config);
		                //$config['upload_path']          = './assets/uploads/documents/vendor/';
		                $config['upload_path']          = $_SERVER['DOCUMENT_ROOT'].'/'.PROJECT_NAME.'/admin/uploads/documents/vendor/';
		                $config['allowed_types']        = 'gif|jpg|png|jpeg';
		                $config['max_size']             = '*';
		                $config['max_width']            = '*';
		                $config['max_height']           = '*';
		                $config['file_name']            = date('ymdHis').mt_rand(1000,99999) ;
		                $images = array();
		                $this->load->library('upload', $config);
		                if ( ! $this->upload->do_upload('images[]')){
		                    $error = array('error' => $this->upload->display_errors());
		                    print_r($error);
		                    break;
		                }else{
		                    $data = array('upload_data' => $this->upload->data());
		                    $arr[]=  $data['upload_data']['raw_name'].$data['upload_data']['file_ext'];
		                }
		            }
		            if(isset($arr)){
		                $user_information['vendor_information']['address_proof_doc'] = implode(',', $arr);
		            unset($arr);
		            }
		        }
		if((isset($_FILES['identity_file']))&&!empty($_FILES['identity_file']['name'][0])){
		            foreach ($_FILES['identity_file']['name'] as $key => $value) {
		                $_FILES['images[]']['name']= $_FILES['identity_file']['name'][$key];
		                $_FILES['images[]']['type']= $_FILES['identity_file']['type'][$key];
		                $_FILES['images[]']['tmp_name']= $_FILES['identity_file']['tmp_name'][$key];
		                $_FILES['images[]']['error']= $_FILES['identity_file']['error'][$key];
		                $_FILES['images[]']['size']= $_FILES['identity_file']['size'][$key];
		unset( $config);
		                //$config['upload_path']          = './assets/uploads/documents/vendor/';
		                $config['upload_path']          = $_SERVER['DOCUMENT_ROOT'].'/'.PROJECT_NAME.'/admin/uploads/documents/vendor/';
		                $config['allowed_types']        = 'gif|jpg|png|jpeg';
		                $config['max_size']             = '*';
		                $config['max_width']            = '*';
		                $config['max_height']           = '*';
		                $config['file_name']            = date('ymdHis').mt_rand(1000,99999) ;
		                $images = array();
		                $this->load->library('upload', $config);
		                if ( ! $this->upload->do_upload('images[]')){
		                    $error = array('error' => $this->upload->display_errors());
		                    print_r($error);
		                    break;
		                }else{
		                    $data = array('upload_data' => $this->upload->data());
		                    $arr[]=  $data['upload_data']['raw_name'].$data['upload_data']['file_ext'];
		                }
		            }
		            if(isset($arr)){
		                $user_information['vendor_information']['identity_doc'] = implode(',', $arr);
		                unset($arr);
		            }
		        }
		if((isset($_FILES['files']))&&!empty($_FILES['files']['name'][0])){
		            foreach ($_FILES['files']['name'] as $key => $value) {
		                $_FILES['images[]']['name']= $_FILES['files']['name'][$key];
		                $_FILES['images[]']['type']= $_FILES['files']['type'][$key];
		                $_FILES['images[]']['tmp_name']= $_FILES['files']['tmp_name'][$key];
		                $_FILES['images[]']['error']= $_FILES['files']['error'][$key];
		                $_FILES['images[]']['size']= $_FILES['files']['size'][$key];
		unset( $config);
		                //$config['upload_path']          = './assets/uploads/profiles/vendor/';
		                $config['upload_path']          = $_SERVER['DOCUMENT_ROOT'].'/'.PROJECT_NAME.'/admin/uploads/profiles/vendor/';
		                $config['allowed_types']        = 'gif|jpg|png|jpeg';
		                $config['max_size']             = '*';
		                $config['max_width']            = '*';
		                $config['max_height']           = '*';
		                $config['file_name']            = date('ymdHis').mt_rand(1000,99999) ;
		                $images = array();
		                $this->load->library('upload', $config);
		                if ( ! $this->upload->do_upload('images[]')){
		                    $error = array('error' => $this->upload->display_errors());
		                    print_r($error);
		                    break;
		                }else{
		                    $data = array('upload_data' => $this->upload->data());
		                    $arr[]=  $data['upload_data']['raw_name'].$data['upload_data']['file_ext'];
		                }
		            }
		            if(isset($arr)){
		                $user_information['vendor_information']['profile'] = implode(',', $arr);
		                unset($arr);
		            }
		        }
		
		$daa =$this->users->update_vendor($user_information, $this->input->post('user_id'));
		if($daa)
		redirect('/users/vendor', 'refresh');
		else
		echo "already exist";
		
		}
		}


		public function admin_list(){
		$columns = array(
		0 => "id",
		1 => "name",
		2 => "phone",
		3 => "email",
		4 => "type",
		5 => "type",
		6 => "registered",
		//6 => "validity",
		// 7 => "profile",
		7 => "status",
		8 => "action"
		);
		$limit = $this->input->post('length');
		        $start = $this->input->post('start');
		        $order = "";
		        $dir = "";
		        $totalData = $this->users->table_items_count('admins');
		        $totalFiltered = $totalData; 
		        if(empty($this->input->post('search')['value'])){
		        $posts = $this->users->all_items($limit,$start,$order,$dir, 'admins', "admins.id as id, admins.user_id as user_id, CONCAT(users.first_name,' ',users.last_name) as name, CONCAT('+',users.country_code,'-',users.phone) as phone, users.email AS email, users.role as type, users.added_on as registered, admins.validity as validity, admins.profile as profile, users.status as status");
		        }else {
		            $search = $this->input->post('search')['value']; 
		            $posts =  $this->users->item_search($limit,$start,$search,$order,$dir, 'admins', "admins.id as id, admins.user_id as user_id, CONCAT(users.first_name,' ',users.last_name) as name, CONCAT('+',users.country_code,'-',users.phone) as phone, users.email AS email, users.role as type, users.added_on as registered, admins.validity as validity, admins.profile as profile, users.status as status");
		            $totalFiltered = $this->users->item_count_search($search,  'admins');
		        }
		  
		  $data = array();
		if(!empty($posts)){
		foreach ($posts as $post){
		$nestedData['id'] = '';
		$nestedData['name'] = (($post->profile)? '<img style="max-width:30px; " src="'.ADMIN_PROFILE.$post->profile.'">' : '<img style="max-width:30px; " src="'.ADMIN_PROFILE.'default.jpg">').(' '.$post->name);
		$nestedData['phone'] = $post->phone;
		$nestedData['email'] = $post->email;
		$nestedData['type'] = 'Admin';
		$nestedData['registered'] = $post->registered;
		$nestedData['validity'] = $post->validity;
		$nestedData['profile'] = ($post->profile)? '<img style="max-width:30px; " src="'.ADMIN_PROFILE.$post->profile.'">' : '<img src="'.ADMIN_PROFILE.'"default.jpg">';
		$nestedData['status'] = $this->active_status[$post->status];
		$nestedData['action'] = '
		<select class="btn btn-primary" data-number="'.$post->user_id.'" onchange="return change_status(this)">
			<option value="2" '.(($post->status == 2)? 'selected="selected"' :" ").' >Deactivate </option>
			<option value="1" '.(($post->status == 1)? 'selected="selected"' :" ").'>Activate</option>
		</select>
		<a href="'.base_url('/users/admin_edit_back').'/'.$post->id.'"><button class="btn btn-primary"><i class="fa fa-pencil"></i> Edit</button></a>
		';
		$data[] = $nestedData;
		}
		}
		$json_data = array(
		"draw"            => intval($this->input->post('draw')),  
		"recordsTotal"    => intval($totalData),  
		"recordsFiltered" => intval($totalFiltered), 
		"data"            => $data   
		);
		echo json_encode($json_data); 
		}
		    
		public function admin_edit($admin_id = null){
		if(isset($admin_id) && ($admin_id != null)){
		$data['admins'] = $this->users->get_user_info($admin_id, 'admins','*, admins.id AS admin_id');
		$data['admins'] = $data['admins'][0];
		}
		$this->load->model('general/general_model','general');
		$data['countries'] = $this->general->get_all_country();
		$data['title'] = 'Users Management';
		$data['page'] = 'add_update_admin';       
		$data['extra_datatable_data'] = $this->external->validation_extra_js_css();       
		$data['extra_datatable_data'] .= $this->external->datetimepciker();       
		$data['extra_datatable_data'] .= '<script>// or post-initialization
var validator = new FormValidator();
validator.texts.date = "not a real date";$("#valid_date").datetimepicker({
		        format: "DD-MM-YYYY"
		})</script>';
		$this->load->view('template',$data);
		}
		public function admin_edit_back($admin_id = null){
			error_reporting(0);
			$this->form_validation->set_rules('first_name', 'first name', 'required');
			$this->form_validation->set_rules('last_name', 'last name', 'required');
			$this->form_validation->set_rules('email', 'email address', 'required');
			$this->form_validation->set_rules('country_code', 'country code', 'required');
			$this->form_validation->set_rules('phone', 'phone number', 'required');
			$this->form_validation->set_rules('role', 'role of the user like main user or sub user', 'required');
			$this->form_validation->set_rules('status', 'status for activation', 'required');
			if ($this->form_validation->run() == FALSE){
				if(isset($admin_id) && ($admin_id != null)){
					$data['admins'] = $this->users->get_user_info($admin_id, 'admins','*, admins.id AS admin_id');
				}
				
				$this->load->model('general/general_model','general');
				$data['countries'] = $this->general->get_all_country();
				$data['title'] = 'Users Management';
				$data['page'] = 'add_update_admin';       
				$data['extra_datatable_data'] = $this->external->validation_extra_js_css();       
				$data['extra_datatable_data'] .= $this->external->datetimepciker();       
				$data['extra_datatable_data'] .= '<script>$("#valid_date").datetimepicker({
				        format: "DD-MM-YYYY"
				})</script>';
				$this->load->view('template',$data);
			}else{
				$array = array(
				'first_name'=>trim($this->input->post('first_name')),
				'last_name'=>trim($this->input->post('last_name')),
				'email'=>trim($this->input->post('email')),
				'country_code'=>trim($this->input->post('country_code')),
				'phone'=>trim($this->input->post('phone')),
				'role'=>trim($this->input->post('role')),
				'status'=>trim($this->input->post('status')),
				);
				if(isset($_FILES['images'])){
		            foreach ($_FILES['images']['name'] as $key => $value) {
		                $_FILES['images[]']['name']= $_FILES['images']['name'][$key];
		                $_FILES['images[]']['type']= $_FILES['images']['type'][$key];
		                $_FILES['images[]']['tmp_name']= $_FILES['images']['tmp_name'][$key];
		                $_FILES['images[]']['error']= $_FILES['images']['error'][$key];
		                $_FILES['images[]']['size']= $_FILES['images']['size'][$key];
		                $config['upload_path']          = './assets/uploads/profiles/admin/';
		                $config['allowed_types']        = 'gif|jpg|png|jpeg';
		                $config['max_size']             = '*';
		                $config['max_width']            = '*';
		                $config['max_height']           = '*';
		                $config['file_name']            = date('ymdHis');
		                $images = array();
		                $this->load->library('upload', $config);
		                if ( ! $this->upload->do_upload('images[]')){
		                    $error = array('error' => $this->upload->display_errors());
		                    break;
		                }else{
		                    $data = array('upload_data' => $this->upload->data());
		                    $arr[]=  $data['upload_data']['raw_name'].$data['upload_data']['file_ext'];
		                }
		            }
		            if(isset($arr))
		                $array['profile'] = implode(',', $arr);
			    }
				
				$this->users->admin_edit_back($array, $this->input->post('user_id'));
				redirect('/users/admin', 'refresh');
			}
		}
		// Extras
		public function change_status_users(){
		return $this
		->users
		->change_status(
		'users', 
		$this->input->post('status'), 
		$this->input->post('number')
		);
		}

}
