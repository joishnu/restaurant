<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Model for User Management
 */
class Users_model extends CI_Model
{
	
	// for datatable
	public function table_items_count($table){
		$query = $this->db->join('users',  'users.id = '.$table.'.user_id',"left")->where('user_type',"1")->where('status<>',"4")->get($table);
		return $query->num_rows();
	}

    public function table_items_count_admin($table){
        $query = $this->db->join('users',  'users.id = '.$table.'.user_id',"left")->where('user_type',"2")->where('status<>',"4")->get($table);
        return $query->num_rows();
    }
    

    public function table_items_count_customer($table){
        $query = $this->db->where('user_type',"3")->where('status<>',"4")->get($table);
        return $query->num_rows();
    }

	public function all_items($limit,$start,$col,$dir, $table, $select = '*'){
		$this->db->select($select);
		$this->db->join('users', 'users.id = '.$table.'.user_id',"left");
        $this->db->where('user_type',"1");
        $this->db->where('status<>',"4");
		$query = $this->db
				->limit($limit,$start)
				//->order_by($col,$dir)
				->get($table);

		if($query->num_rows()>0){
            $result= $query->result(); 
            return $result;
        }else{
            return null;
        }
        
	}

    public function all_items_vendor($limit,$start,$col,$dir, $table, $select = '*'){
        $this->db->select($select);
        $this->db->join('users', 'users.id = '.$table.'.user_id',"left");
        $this->db->where('user_type',"2");
        $query = $this->db
                ->limit($limit,$start)
                //->order_by($col,$dir)
                ->get($table);

        if($query->num_rows()>0){
            $result= $query->result(); 
            return $result;
        }else{
            return null;
        }
        
    }

    public function all_items_customer($limit,$start,$col,$dir, $table, $select = '*'){
        $this->db->select($select);
        $this->db->where('user_type',"3");
      //  $this->db->join('users', 'users.id = '.$table.'.user_id','right');
        $query = $this->db
                ->limit($limit,$start)
                //->order_by($col,$dir)
                ->get($table);

        if($query->num_rows()>0){
            $result= $query->result(); 
            return $result;
        }else{
            return null;
        }
        
    }

	function item_search($limit,$start,$search,$col,$dir, $table, $select)
    {
    	$this->db->select($select);
		$this->db->join('users', 'users.id = '.$table.'.user_id');
        $query = $this->db
        	->like($table.'.id',$search)
        	->or_like('address',$search)
            //->order_by($table.'.'.$col,$dir)->get($table);
        	->limit($limit,$start)->get($table);
        if($query->num_rows()>0)
            return $query->result();  
        else
            return null;
    }

    function item_count_search($search, $table)
    {

        $query = $this->db
                ->like('id',$search)
        		->or_like('address',$search)
                ->get($table);
        return $query->num_rows();
    } 


    public function change_status($tablename, $status, $id_value, $id_field = 'id' ){
    	switch ($status) {
    		case 1:
    			$status_array = array('status'=>1);		
    			break;

    		case 2:
    			$status_array = array('status'=>2);		
    			break;

    		case 3:
    			$status_array = array('status'=>3);		
    			break;

    		case 4:
    			$status_array = array('status'=>4);		
    			break;
    		
    		default:
    			$status_array = array('status'=>0);		
    			break;
    	}
    	
    	$this->db->where($id_field, $id_value);
    	$this->db->update($tablename, $status_array);
        return true;

    }

    public function get_user_info($user_id, $table, $select='*'){
        
        $this->db->select($select);
        $this->db->where($table.'.id', $user_id);
        $this->db->join('users', 'users.id = '.$table.'.user_id');
        return $this->db->get($table)->row_array();
    }   

    public function admin_edit_back($data, $id = null){

        $user_info = array(
            'first_name'=>$data['first_name'],
            'last_name'=>$data['last_name'],
            'email'=>$data['email'],
            'country_code'=>$data['country_code'],
            'phone'=>$data['phone'],
            'role'=>$data['role'],
            'user_type'=>1,
            'is_email'=>1,
            'updated_on'=>date('Y-m-d H:i:s'),
            'is_phone'=>1,
            'status'=>$data['role'],
        );
      /*  $admin_info = array(
            'validity'=>date('Y-m-d', strtotime($data['valid_date'])),
        );
*/
        if(isset($data['profile'])){
            $admin_info['profile'] = $data['profile'];
        }

        if(isset($id) && $id != null){

            $this->db->select('id, user_id');
            $this->db->where('id', $id);
            $data = $this->db->get('admins')->row_array();
            
            /*$this->db->where('id',$data['id']);
            $res = $this->db->update('admins', $admin_info);*/

            $this->db->where('id',$data['user_id']);
            $res = $this->db->update('users', $user_info);

            if($res)
                return true;
            else
                return false;
        }
        else{
            
            $this->db->insert('users', $user_info);
            $last = $this->db->insert_id();
            
            $admin_info['user_id']= $last;
            $res = $this->db->insert('admins', $admin_info);
            
            //print_r($this->db->last_query());exit();

            if($res)
                return true;
            else
                return false;
        }

        
    }

    public function add_vendor($data){

        try {
            $this->db->trans_begin();

            $this->db->where('email', $data['users']['email']);
            $rs = $this->db->get('users')->row_array();
            if($rs)
                return false;

                $vendor_information = $data['vendor_information'];
                unset($data['vendor_information']);


                $user_information = $data['users'];
                unset($data['users']);
/*                

                $commission_information = $data['commission_information'];
                unset($data['commission_information']);*/
        
                if(!$this->db->insert('users', $user_information)) {
                    throw new Exception("Error Processing Request", 1);
                }


                $insert_user = $this->db->insert_id();
                $vendor_information['user_id'] = $insert_user;
                
                if(!$this->db->insert('vendors', $vendor_information)) {
                    throw new Exception("Error Processing Request", 1);
                }
                $vendor_id = date('Ymd').$this->db->insert_id();
                $this->db->where('id', $this->db->insert_id());
                $this->db->update('vendors', array('vendor_id'=>$vendor_id));

                $bank_information = $data['bank'];
                $bank_information['user_id'] = $insert_user;

                if(!$this->db->insert('bank_details', $bank_information)) {
                    throw new Exception("Error Processing Request", 1);
                }

                $address_information = $data['address'];
                //echo "<pre>";print_r($address_information);exit();
               // $address_information['user_id'] = $insert_user;

                $cnt=count($data['address']);


                for($i=0;$i<=$cnt-1;$i++)
                {   
                    $insert_dt[]=array(
                                    'store_address'=>$address_information[$i]['address'],'latitude'=>$address_information[$i]['latitude'],'longtitude'=>$address_information[$i]['longtitude'],'created_on'=>$address_information[$i]['created_on'],'user_id'=>$insert_user);
                }
                
                if(!$this->db->insert_batch('stores', $insert_dt)) {
                    throw new Exception("Error Processing Request", 1);
                }
                
                /*$insert_vendor = $this->db->insert_id();
                $commission_information['vendor_id'] =$insert_vendor;
            
            $data = $this->db->insert('commissions', $commission_information);*/
            //return $data;
            
            $this->db->trans_commit();
            return 1;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }


    public function update_vendor($data,$id){

        try {
            $this->db->trans_begin();

                $vendor_information = $data['vendor_information'];
                unset($data['vendor_information']);


                $user_information = $data['users'];
                unset($data['users']);
                
                $where= array('user_id' => $id );
                $where_user= array('id' => $id );


                $this->db->update('users', $user_information, $where_user);

                $this->db->update('vendors', $vendor_information, $where);


                $this->db->update('bank_details', $data['bank'], $where);


                $address_information = $data['address'];
                //echo "<pre>";print_r($address_information);exit();
               // $address_information['user_id'] = $insert_user;

                $cnt=count($data['address']);
                $updt_dt=[];
                $insert_dt=[];
                $update_wher=[];

                for($i=0;$i<=$cnt-1;$i++)
                {   
                    if($address_information[$i]['id']!='')
                    {
                        $updt_dt[]=array(
                                    'store_address'=>$address_information[$i]['address'],'latitude'=>$address_information[$i]['latitude'],'longtitude'=>$address_information[$i]['longtitude'],'created_on'=>$address_information[$i]['created_on'],
                                        'id' => $address_information[$i]['id']);
                    }
                    else
                    {
                       $insert_dt[]=array(
                                    'store_address'=>$address_information[$i]['address'],'latitude'=>$address_information[$i]['latitude'],'longtitude'=>$address_information[$i]['longtitude'],'created_on'=>$address_information[$i]['created_on'],'user_id'=>$id);
                    }
                    
                }
                
                if($insert_dt)
                {
                    if(!$this->db->insert_batch('stores', $insert_dt)) {
                        throw new Exception("Error Processing Request", 1);
                    }    
                }
                
                if($updt_dt)
                {
                    $this->db->update_batch('stores', $updt_dt, 'id');
                }

            $this->db->trans_commit();
            return 1;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    
    public function get_vendor_complete_info_by_id($vendor_id){
        $this->db->select('vendors.*, users.first_name, users.last_name, users.country_code, users.phone, users.email, users.status, bank_details.bank_name, bank_details.account_name, bank_details.ifsc, bank_details.account_number, bank_details.branch_name');
        $this->db->join('users', 'users.id = vendors.user_id');
        $this->db->join('bank_details', 'users.id = bank_details.user_id',"left");
        //$this->db->join('addresses', 'users.id = addresses.user_id',"left");
       // $this->db->join('commissions', 'commissions.vendor_id = vendors.id');
        $this->db->where('vendors.user_id',$vendor_id);
        $vendor_info=$this->db->get('vendors')->row_array();
       /* echo "<pre>";print_r($this->db->last_query());exit();
        echo "<pre>";print_r($vendor_info);exit();*/
        $this->db->select('*');
        $this->db->where('stores.user_id',$vendor_id);
        $vendor_info['stores']=$this->db->get('stores')->result_array();

        $this->db->select('state_id, country_id');
        $this->db->join('states', 'states.id = cities.state_id');
        $this->db->join('countries', 'states.country_id = countries.id');
        $this->db->where('cities.id',$vendor_info['city_id']);
        $vendor_info['cities']=$this->db->get('cities')->row_array();

        return $vendor_info;
       
    }

      public function get_vendor_complete_info_by_id_view($vendor_id){
        $this->db->select('*');
        $this->db->join('users', 'users.id = vendors.user_id');
        $this->db->join('bank_details', 'users.id = bank_details.user_id',"left");
        //$this->db->join('addresses', 'users.id = addresses.user_id',"left");
       // $this->db->join('commissions', 'commissions.vendor_id = vendors.id');
        $this->db->where('vendors.user_id',$vendor_id);
        $vendor_info=$this->db->get('vendors')->row_array();
       /* echo "<pre>";print_r($this->db->last_query());exit();
        echo "<pre>";print_r($vendor_info);exit();*/
        $this->db->select('*');
        $this->db->where('stores.user_id',$vendor_id);
        $vendor_info['stores']=$this->db->get('stores')->result_array();

        $this->db->select('state_id, country_id');
        $this->db->join('states', 'states.id = cities.state_id');
        $this->db->join('countries', 'states.country_id = countries.id');
        $this->db->where('cities.id',$vendor_info['city_id']);
        $vendor_info['cities']=$this->db->get('cities')->row_array();

        return $vendor_info;
       
    }

    public function get_roles()
    {
        $this->db->select('');
        $this->db->where('status',1);
        $result = $this->db->get('roles')->result_array();
        return $result;
    }
}

?>