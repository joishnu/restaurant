<?php
if (!defined('BASEPATH'))
exit('No direct script access allowed');
class Authenticate_model extends CI_Model {

    public function login($params) {
        try{
            $where = array(
            'email' => $params['email'],
            //'password' => $params['password']
            );
            $this->db->select('id,password,email, first_name, last_name,user_type,password,country_code,phone,status,role');
            $data = $this->db->get_where('users', $where)->row_array();
            
            if(!$data){
                throw new Exception("Invalid user id or password.", 1);
            }
            if($data['user_type']=='1' || $data['user_type']=='2'){
                
            }else{
                throw new Exception("You dont have permission for this portal", 1);
            }
            if($data['status'] !=1){
                if($data['status'] == 2){
                    throw new Exception("Your account is inactive", 1);
                    
                }
                else if($data['status'] == 3){
                    throw new Exception("Your account is blocked", 1);
                    
                }else if($data['status'] == 4){
                    throw new Exception("Your account is deleted", 1);
                    
                }
            }
            if($data['user_type'] == 2){
                $password = do_hash($params['password']);
            }else{
                $password = $params['password'];
            }     
            if($data['password'] != $password){
                throw new Exception("You entered a wrong password.", 1);
            }       
            $response['status'] = true;
            $response['data'] = $data;
            return $data;
        }catch(Exception $e){
            $response['status'] = false;
            $response['message'] = $e->getMessage();
        }
        return $response;
    }


}