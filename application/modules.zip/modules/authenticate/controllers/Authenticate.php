<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Authenticate extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->helper('security');
		$this->load->model('authenticate_model','auth');
	}
	public function index()
	{	
		if($this->session->userdata('id')){
			redirect('dashboard');
		}else{
		$data['title'] = 'log In';
        $this->load->view('login',$data);			
		}

	}

	function do_login(){
		try{
			$this->form_validation->set_rules('email', 'Email Id', 'trim|required|valid_email');
			$this->form_validation->set_rules('password', 'password', 'trim|required');
			$input=$this->input->post(null,true);
			if(!$this->form_validation->run()){
				throw new Exception(validation_errors(), 1);
			}
    		$rs = $this->auth->login($input);
    		if(!$rs['status']){
    			throw new Exception($rs['message'], 1);
    		}
    		$rs['permissions'] = (array) ($this->auth_lib->get_role_info($rs['role']));
    		
			$this->session->set_userdata($rs);
			   
			redirect(site_url());            
	    }catch(Exception $e){
	    	$this->session->set_flashdata('error',$e->getMessage());
	    	redirect(site_url());
	    }

	}
	
	
	public function logout(){
		$sess_items = $this->session->all_userdata();
		$this->session->unset_userdata('id');
/*        $this->db->cache_delete_all();
        $this->session->sess_destroy();
*/        $this->session->set_flashdata('success','Logged out successfully');
        redirect(base_url());
    }
}
