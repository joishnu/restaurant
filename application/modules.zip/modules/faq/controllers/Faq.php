<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


class Faq extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('faq_model','faq');

	}
	public function add(){
		$data['title'] = 'Question Answer';
        $data['list']=$this->faq->faq_result();
      //  echo"<pre>";print_r($data['list']);die;

		$data['page'] = 'add';       
		$this->load->view('template',$data);
	}
    public function edit($id=""){
        $data['title'] = 'Question Answer';
        $data['list']=$this->faq->faq_results($id);
      //echo"<pre>";print_r($data['list']);die;
        $data['page'] = 'edit';       
        $this->load->view('template',$data);
    }


	public function add_faq(){
        $this->form_validation->set_rules('faq_question','faq_question','trim|required');
        $this->form_validation->set_rules('faq_answer','faq_answer','trim|required');
        $info = $this->input->post(NULL,true);
        if($this->form_validation->run()) {
        $rs = $this->faq->do_add_faq($info);
        if($rs) {
        $this->session->set_flashdata('success', 'cms has been updated successfully');
        redirect(site_url('faq/add'));
        } 
        else {
        $this->session->set_flashdata('error', 'Some error occurred. Please try again.');
        }
        } 
        else {
        $this->session->set_flashdata('error',validation_errors());
        }
        redirect(site_url('faq/add'));
    }
    public function update_faq(){
        $this->form_validation->set_rules('question','faq_question','trim|required');
        $this->form_validation->set_rules('answer','faq_answer','trim|required');
        $info = $this->input->post(NULL,true);
   // echo"<pre>";print_r($info);die;

        if($this->form_validation->run()) {
        $rs = $this->faq->do_update_faq($info);
        if($rs) {
        $this->session->set_flashdata('success', 'cms has been updated successfully');
        redirect(site_url('faq/add'));
        } 
        else {
        $this->session->set_flashdata('error', 'Some error occurred. Please try again.');
        }
        } 
        else {
        $this->session->set_flashdata('error',validation_errors());
        }
        redirect(site_url('faq/add/'.$info['faq_id']));
    }

}