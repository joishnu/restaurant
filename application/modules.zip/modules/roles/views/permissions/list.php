<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Permission Management(Only For Developer)</h3>
            </div>
        </div>
        <div class="title_right">
            <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search" style="text-align: right">
                <a href="<?=base_url('roles/add/permission');?>" class="btn btn-primary"> <i class="fa fa-plus"></i> Add Permission</a>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Permission List</h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <p class="text-muted font-13 m-b-30"><!-- If you want to write somting you can write here --></p>
                    <table id="permissiontable" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
			            <thead class="the-box dark full">
						    <tr>
							    <th>#</th>   
							    <th>Permission Name</th>
							    <th>Created On</th>
							    <th>Created By</th>
							    <th>Status</th>
							    <th>Action</th>
						    </tr>
			    		</thead>
			    		<tbody>
			    			<?php foreach ($permissions as $key => $perm): //show($perm);?>
			    				<tr>
			    					<td><?=$key+1;?></td>
			    					<td><?=$perm['permission_name'];?></td>
			    					<td><?=date('m/d/Y h:i A', strtotime($perm['permission_created_on']));?></td>
			    					<td><?=$perm['first_name'] ? $perm['first_name'].' '.$perm['last_name'] : 'NA';?></td>
			    					<td>
			    						<?php if ($perm['permission_status'] == 1): ?>
			    							<button class="btn btn-primary">Active</button>
			    						<?php else: ?>
			    							<button class="btn btn-primary">Deactivate</button>
			    						<?php endif ?>
			    					</td>
			    					<td>
			    						<?php //if(in_array("edit_permission", $permission['_permissions'])){?>
			    							<a class="btn btn-primary" href="<?=site_url('roles/edit/permission/'.$perm['permission_id']);?>"><i class="fa fa-pencil"></i> Edit</a>
			    						<?php //}?>
			    						<!-- <a class="btn btn-xs btn-danger"><i class="fa fa-trash"></i> Delete</a> -->
			    					</td>

			    				</tr>
			    			<?php endforeach ?>
			    		</tbody>
					</table>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<script type="text/javascript">
    $(document).ready(function (){
        $("#permissiontable").DataTable({});
    });
</script>