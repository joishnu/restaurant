<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet">
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Add Permission</h3>
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Add Permission (Strictly meant for developers) </h2>
                    <ul class="nav navbar-right panel_toolbox">
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div class="x_content">
                        <form method="post" class="form" action="<?=site_url('roles/do_update_permission');?>" role="form" data-toggle="validator">
                    
                    <div class="form-group">
                        <label class="control-label">Permission Name</label>
                        <div class="">
                            <input type="text" class="form-control" name="permission_name" placeholder="Please enter Permission Name" value="<?=$permission['permission_name'];?>" required>
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label">Description</label>
                        <div class="">
                            <textarea class="form-control" name="permission_desc" rows="2" placeholder="Please enter role description"><?=$permission['permission_desc'];?></textarea>
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label">Select Module</label>
                        <div class="">
                            <div class="input-group">
                                <select name="module[]" class="form-control select2" multiple>
                                    <?php
                                        foreach ($modules as $key => $module):
                                            $selected = in_array($module['module_id'], $permission['modules']) ? 'selected' : '';
                                    ?>
                                        <option value="<?=$module['module_id'];?>" <?=$selected;?>><?=ucfirst($module['module_name']);?></option>
                                    <?php endforeach ?>
                                </select>
                                <span class="input-group-btn">
                                    <button type="button" class="btn btn-danger nbr" data-toggle="tooltip" title="Refresh all modules." id="refresh-modules"><i class="fa fa-fw fa-refresh"></i></button>
                                </span>
                            </div>
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>
                    <div class="__method">
                        <?php
                        foreach ($methods as $key => $method): if(count($method['method']) < 1) continue; ?>
                        <div class="form-group" id="methods_for_<?=$method['module_id'];?>">
                           <label class="control-label">Select Method(s) for <?=$permission['module_names'][$method['module_id']];?></label>
                           <div class="">
                                <select name="method[]" class="form-control select2" multiple="" required="" tabindex="-1" aria-hidden="true">
                                    <?php
                                    foreach ($method['method'] as $key => $meth):
                                        $selected = in_array($meth['method_id'], $permission['methods']) ? 'selected' : '';
                                    ?>
                                    <option value="<?=$meth['method_id'];?>" <?=$selected;?>><?=$meth['method_name'];?></option>
                                    <?php endforeach ?>
                               </select>
                               <span class="help-block with-errors"></span>
                           </div>
                        </div>
                        <?php endforeach ?>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Permission Status</label>
                        <div class="">
                            <select class="form-control" name="permission_status">
                                <?php
                                    $active = $permission['permission_status'] == 1 ? 'selected' : '';
                                    $inactive = $permission['permission_status'] == 0 ? 'selected' : '';
                                ?>
                                <option value="1" <?=$active;?>>Active</option>
                                <option value="0" <?=$inactive;?>>Inactive</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="">
                            <input type="hidden" name="permission_id" value="<?=$permission['permission_id'];?>">
                            <button type="submit" class="btn btn-sm btn-primary">Update Permission</button>
                            <a href="<?=site_url('roles/permissions');?>" class="btn btn-sm btn-warning">Back to Permissions</a>
                        </div>
                    </div>

                </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script type="text/javascript">
    $("#modules").select2({
        placeholder: "Select Module",
        width: "resolve" 
    });
    $(".method").select2({
        placeholder: "Select Module",
        width: "resolve" 
    });

    var form_selector = $('[data-toggle=validator]');
    var baseurl = '<?php echo base_url();?>';
    function retrive_method(module_id, module_name) {
        if(typeof module_id == 'undefined') { return false; }
        var html = ''+
        '<div class="form-group" id="methods_for_'+module_id+'">'+
        '   <label class="control-label">Select Method(s) for '+module_name+'</label>'+
        '   <div class="">'+
        '       <select name="method[]" class="form-control" multiple required></select>'+
        '       <span class="help-block with-errors"></span>'+
        '   </div>'+
        '</div>';
        html_selector = $(html);
        method = html_selector.find('select');
        $.ajax({
            url:baseurl+'roles/get_methods',
            data:{id:module_id},
            type:'post',
            dataType:'json',
            success:function(data) {
                if(!data.status) { alert(data.message, data.status); return; }
                $.each(data.response, function(index, value) {
                method.append('<option value="'+value.method_id+'">'+value.method_name+'</option>');
                });
                method_selector = $('.__method');
                method_selector.removeClass('hidden').append(html_selector[0].outerHTML);
                method_selector.find('#methods_for_'+module_id+' select[name="method[]"]').select2({
                placeholder:"Select method(s)"
                });
                // method_selector
                form_selector.validator('update');
            },
            error:function(data) {
            alert('Some error occurred',false);
            }
        });
        return true;
    }
    $(document).ready(function(){
        $('select[name="module[]"]').select2({
            placeholder:'Select module(s)'
        }).on('select2:select', function(event) {
            retrive_method(event.params.data.id, event.params.data.text);
        }).on('select2:unselect', function(event) {
        $('.__method').find('#methods_for_'+event.params.data.id+' select[name="method[]"]').parents('.form-group').remove();
        });
        $('button#refresh-modules').on('click', function(e) {
            e.preventDefault();
            clicked = $(this);
            clicked.blur();
            clicked.prop('disabled',true).find('i.fa').addClass('fa-spin');
            $.ajax({
                url:baseurl+'roles/refresh_modules',
                dataType:'json',
                success: function(data) {
                    alert(data.message, data.status);
                    clicked.prop('disabled',false).find('i.fa').removeClass('fa-spin');
                    //console.log(data);return false;
                    location.reload();
                },
                error:function(data) {
                    alert('Some error occurred',false);
                    clicked.prop('disabled',false).find('i.fa').removeClass('fa-spin');
                }
            });
        })
    });
</script>