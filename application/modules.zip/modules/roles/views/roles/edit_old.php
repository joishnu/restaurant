<div class="row wrapper border-bottom white-bg page-heading breadcrumb-wrapper ">
    <div class="col-lg-10">
        <h2><?=isset($title) && !empty($title) ? ucwords($title) : 'Users' ;?></h2>
        <?php echo breadcrumb(array('home' => '','roles' => 'roles','edit' => ''));?>
    </div>
</div>
<div class="row main-content">
    <?php $this->load->view('includes/show_flashdata');?>
	<div class="col-md-12">
		<div class="ibox float-e-margins">
			<div class="ibox-title">
                <h5>Update Role</h5>
			    <div class="ibox-tools">
			        <a class="collapse-link">
			            <i class="fa fa-chevron-up"></i>
			        </a>
			    </div>
			</div>
			<div class="ibox-content">
				<form method="post" class="form" action="<?=site_url('roles/do_update_role');?>" role="form" data-toggle="validator">
                    
                    <div class="form-group">
                        <label class="control-label">Role Name</label>
                        <div class="">
                            <input type="text" class="form-control" name="role_name" placeholder="Please enter Role Name" value="<?=$role['role_name'];?>" required>
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label">Description</label>
                        <div class="">
                            <textarea class="form-control" name="role_desc" rows="2" placeholder="Please enter role description"><?=$role['role_desc'];?></textarea>
                            <span class="help-block with-errors"></span>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label">Permissions</label> <label class="checkbox-inline"><input type="checkbox" id="select-all-permissions"> Select All</label>
                        <div class="">
                            <!-- <select class="form-control" name="permissions[]" multiple>

                                <?php foreach ($permissions as $key => $perms): ?>
                                    <?php $selected = in_array($perms['permission_id'], $assigned_perms) ? 'selected' : ''; ?>
                                    <option value="<?=$perms['permission_id'];?>" <?=$selected;?>><?=$perms['permission_name'];?></option>
                                <?php endforeach ?>
                            </select>
                            <span class="help-block with-errors"></span> -->
                        </div>
                    </div>
                    <!-- <div class="form-group">
                        <label class="control-label">Role Level</label>
                        <div class="">
                            <select name="role_level" class="form-control" required>
                                <option value="">Select Role Level</option>
                                <?php
                                    for($i = $current_role_level; $i <= $role_count; $i++):
                                        $selected = $i == $role['role_level'] ? 'selected' : '';
                                ?>
                                    <option value="<?=$i;?>" <?=$selected;?>>Level <?=$i?></option>
                                <?php endfor; ?>
                            </select>
                        </div>
                    </div> -->
                    <div class="form-group">
                        <label class="control-label">Role Status</label>
                        <div class="">
                            <select class="form-control" name="role_status">
                                <?php
                                    $active = $role['role_status'] == 1 ? 'selected' : '';
                                    $inactive = $role['role_status'] == 0 ? 'selected' : '';
                                ?>
                                <option value="1" <?=$active;?>>Active</option>
                                <option value="0" <?=$inactive;?>>Inactive</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                    	<div class="">
                            <input type="hidden" name="role_id" value="<?=$role['role_id'];?>">
                    		<button type="submit" class="btn btn-sm btn-tokeit-red">Update Role</button>
                            <a href="<?=site_url('roles');?>" class="btn btn-sm btn-tokeit-dark">Back to Roles</a>
                    	</div>
                    </div>

				</form>
			</div>
		</div>
	</div>
</div>

<script type="text/javascript">
    $(document).ready(function(){
        $('select[name="permissions[]"]').select2({
            placeholder: "Select Permissions"
        });
        $("#select-all-permissions").change(function(e){
            console.log(e);
            select_all_click = $(this);
            permission_target = $('select[name="permissions[]"]');
            if(select_all_click.is(':checked') ){
                permission_target.find('option').prop("selected",true);
            }else{
                permission_target.find('option').prop("selected",false);
            }
            permission_target.trigger('change');
        });
    })
</script>