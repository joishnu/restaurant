<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet">
<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
            </div>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Edit Role<small></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a></li>
                        <li><a class="close-link"><i class="fa fa-close"></i></a></li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <form method="post" class="form" action="<?=site_url('roles/do_update_role');?>" role="form" data-toggle="validator">
                        <div class="item form-group">
                            <label class="control-label">Role Name</label>
                            <div class="">
                                <input type="text" class="form-control" name="role_name" placeholder="Please enter Role Name" value="<?=$role['name'];?>" required>
                                <span class="help-block with-errors"></span>
                            </div>
                        </div>
                        <!-- <div class="item form-group">
                            <label class="control-label">Description</label>
                            <div class="">
                                <textarea class="form-control" name="role_desc" rows="2" placeholder="Please enter role description"><?=$role['role_desc'];?></textarea>
                                <span class="help-block with-errors"></span>
                            </div>
                        </div> -->
                        <div class="item form-group">
                            <label class="control-label">Permission</label>
                            <!-- <label class="checkbox-inline">
                                <input type="checkbox" id="select-all-permissions"> Select All
                            </label> -->
                            <div class="">
                                <table class="table table-stripped table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Modules</th>
                                            <th>Permissions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($permissions as $key=>$value){?>
                                        <tr>
                                            <td><b>
                                                <?php //echo "1";
                                                $key1 = str_replace("_"," ",$key);
                                                echo ucfirst($key1);
                                                ?></b>
                                            </td>
                                            <td>
                                                <select name="permissions[]" class="form-control select2" multiple  id="modules">
                                                <!-- <select class="form-control" name="permissions[]" multiple=""> -->
                                                    <option value="">Select Permission</option>
                                                    <?php foreach($value as $val){?>
                                                    <option value="<?=$val['permission_id'];?>" <?php if(in_array($val['permission_id'], $assigned_perms)) echo "selected";?>><?=$val['permission_name'];?></option>
                                                    <?php }?>
                                                </select>
                                            </td>
                                        </tr>
                                        <?php }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="item form-group">
                            <label class="control-label">Role Status</label>
                            <div class="">
                                <select class="form-control" name="role_status">
                                    <?php
                                    $active = $role['status'] == 1 ? 'selected' : '';
                                    $inactive = $role['status'] == 0 ? 'selected' : '';
                                    ?>
                                    <option value="1" <?=$active;?>>Active</option>
                                    <option value="0" <?=$inactive;?>>Inactive</option>
                                </select>
                            </div>
                        </div>
                        <div class="item form-group">
                            <div class="">
                                <input type="hidden" name="role_id" value="<?=$role['id'];?>">
                                <button type="submit" class="btn btn-primary">Update Role</button>
                                <a href="<?=site_url('roles');?>" class="btn btn-default">Back to Roles</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
<script type="text/javascript">
$(document).ready(function(){
     $("#modules").select2({
        placeholder: "Select Module",
        width: "resolve" 
    });
    $('select[name="permissions[]"]').select2({
        placeholder: "Select Permissions"
    });
    $("#select-all-permissions").change(function(e){
        console.log(e);
        select_all_click = $(this);
        permission_target = $('select[name="permissions[]"]');
        if(select_all_click.is(':checked') ){
            permission_target.find('option').prop("selected",true);
        }else{
            permission_target.find('option').prop("selected",false);
        }
        permission_target.trigger('change');
    });
})
</script>