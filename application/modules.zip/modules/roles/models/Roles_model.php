<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Roles_model extends CI_Model {
    
    public function get_all_roles() {
        $this->db->select('roles.*, users.first_name, users.last_name');
        $this->db->join('users','users.id = roles.created_by','left');
        $where['roles.status !='] = 3;
        return $this->db->get_where('roles', $where)->result_array();
    }

    public function get_all_permissions() 
    {
        $this->db->select('permissions.*, users.first_name, users.last_name');
        $this->db->join('users','users.id = permissions.perm_created_by','left');
        $this->db->order_by('permissions.permission_id', 'desc');
        $result = $this->db->get('permissions')->result_array();
        return $result;
    }

    public function add_role($data)
    {
        try {
            $this->db->trans_begin();
            $role= array(
                'name' => $data['role_name'],
                'created_by' => $data['created_by']
            );
            
            $this->db->insert('roles',$role);

            if(!$this->db->affected_rows()) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return 1;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function add_permission($params = []) {
        try {
            $this->db->trans_begin();
            //show($params);
            $insert_data = array(
                'permission_name' => $params['permission_name'],
                'permission_updated_on' => date('Y-m-d H:i:s'),
                'permission_status' => $params['permission_status'] ? 1 : 0,
                'permission_slug' => $params['slug']
            );

            if(isset($params['permission_desc'])) {
                $insert_data['permission_desc'] = $params['permission_desc'];
            }

            if(isset($params['created_by'])) {
                $insert_data['perm_created_by'] = $params['created_by'];
            }

            $this->db->insert('permissions', $insert_data);
            if(!$this->db->affected_rows()) {
                throw new Exception("Error while adding permission", 1);
            }

            $permission_id = $this->db->insert_id();
            $insert_data = array();
            foreach ($params['method'] as $key => $method) {
                $insert_data[] = array(
                    'permission_id' => $permission_id,
                    'method_id' => $method,
                    'created_on' => date('Y-m-d H:i:s')
                );
            }

            if (count($insert_data)) {
                $this->db->insert_batch('permission_methods', $insert_data);
                if (!$this->db->affected_rows()) {
                    throw new Exception("Permission method issue", 1);
                }
            }
            $this->db->trans_commit();
            return $permission_id;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function get_role($role_id = 0) {
        $this->db->select('roles.*, users.first_name, users.last_name');
        $this->db->join('users','users.id = roles.created_by','left');
        return $this->db->get_where('roles', array('roles.id' => $role_id))->row_array();
    }

    public function get_role_count() {
        return $this->db->count_all('roles');
    }

    public function get_assigned_permissions($role_id = 0) {
        $permissions =  $this->db->select('permission_id')->get_where('assigned_perms', array(
            'role_id' => $role_id
        ))->result_array();
        return array_map(function($arr) { return $arr['permission_id']; }, $permissions);
    }

    public function permission_name()
    {   
        $this->db->select('DISTINCT(p.permission_id),p.permission_name,p.permission_status,m.module_name');
        //$this->db->select('p.*,m.module_name');
        $this->db->join('permission_methods pm', 'pm.permission_id = p.permission_id', 'left');
        $this->db->join('module_methods mm', 'mm.method_id = pm.method_id', 'left');
        $this->db->join('modules m', 'm.module_id = mm.module_id', 'left');
        $result = $this->db->get('permissions p')->result_array();
        $res_arr = array();
        foreach ($result as $key => $value) {
            $res_arr[$value['module_name']][] = $value;
        }
        //echo "<pre>";print_r($result);die();
        return $res_arr;
    }

    public function update_role($params = []) {
        $update_data = array(
            'name' => $params['role_name'],
            'status' => $params['role_status'] ? 1 : 0,
            //'role_level' => $params['role_level'],
            //'role_slug' => $params['slug']
        );

        if(isset($params['role_desc'])) {
            $update_data['role_desc'] = $params['role_desc'];
        }

        if(isset($params['created_by'])) {
            $update_data['role_created_by'] = $params['created_by'];
        }

        $where = array(
            'id' => isset($params['role_id']) ? $params['role_id'] : 0
        );

        $this->db->update('roles', $update_data, $where);
        $basic_info = $this->db->affected_rows() ;
        $this->db->where('role_id', $params['role_id']);
        $this->db->delete('assigned_perms');

        $perm_info = true;
        if(isset($params['permissions'])) {
            $perm_array = array();
            foreach ($params['permissions'] as $perms) {
                $perm_array[] = array(
                    'role_id' => $params['role_id'],
                    'permission_id' => $perms
                );
            }
            if(count($perm_array)) {
                $this->db->insert_batch('assigned_perms', $perm_array);
                $perm_info = $this->db->affected_rows();
            }
        }
        return  $basic_info || $perm_info;
    }

    public function get_permission($permission_id = 0) {
        $this->db->select('permissions.*, users.first_name, users.last_name, modules.module_id, module_methods.method_id, modules.module_name');
        $this->db->join('permission_methods','permission_methods.permission_id = permissions.permission_id','left');
        $this->db->join('module_methods','permission_methods.method_id = module_methods.method_id','left');
        $this->db->join('modules','modules.module_id = module_methods.module_id','left');
        $this->db->join('users','users.id = permissions.perm_created_by','left');
        return $this->db->get_where('permissions', array('permissions.permission_id' => $permission_id))->result_array();
    }

    public function update_permission($params = []) {
        try {
            $this->db->trans_begin();
            $permission_id = isset($params['permission_id']) ? $params['permission_id'] : 0;
            $update_data = array(
                'permission_name' => $params['permission_name'],
                'permission_updated_on' => date('Y-m-d H:i:s'),
                'permission_status' => $params['permission_status'] ? 1 : 0,
                'permission_slug' => $params['slug']
            );

            if(isset($params['permission_desc'])) {
                $update_data['permission_desc'] = $params['permission_desc'];
            }

            if(isset($params['created_by'])) {
                $update_data['perm_created_by'] = $params['created_by'];
            }

            $where = array(
                'permission_id' => $permission_id
            );
            $this->db->update('permissions', $update_data, $where);
            $update_status = $this->db->affected_rows() ? true : false;

            $this->db->where('permission_id', $permission_id)->delete('permission_methods');
            $delete_status = $this->db->affected_rows() ? true : false;
            $insert_status = true;
            $insert_data = array();
            foreach ($params['method'] as $key => $method) {
                $insert_data[] = array(
                    'permission_id' => $permission_id,
                    'method_id' => $method
                );
            }

            if (count($insert_data)) {
                $this->db->insert_batch('permission_methods', $insert_data);
                $insert_status = $this->db->affected_rows() ? true : false;
            }
            
            if(count($insert_data) && !$insert_status) {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function change_status($table,$status,$id)
    {
        try {
            $this->db->trans_begin();
            $where= array('id' => $id );
            $update_data = array(
                'status' =>$status,
                'updated_on'=>date('Y-m-d H:i:s')
            );
            $result = $this->db->update($table, $update_data, $where);
            if(!$result)
            {
                throw new Exception("Error Processing Request", 1);
            }
            $this->db->trans_commit();
            return true;
        } catch (Exception $e) {
            $this->db->trans_rollback();
            return false;
        }
    }

    public function do_delete($id)
    {   
        $this->db->where('id', $id);
        $result = $this->db->delete('roles');
        return $result;
    }
}