<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Roles extends MX_Controller {
    
    public function __construct() {
        parent::__construct();
        /*if(!$this->auth_lib->is('logged_in')) {
            $this->session->set_flashdata('error','Please login to access requested page.');
            redirect(site_url('auth'));
        }*/
        $this->load->library('external');
        $this->load->model('roles_model','roles');
    }

    /**
     * Roles
     */
    
    public function index() {
        self::list_roles();
    }

    public function list_roles() 
    {   
        $permission = $this->session->userdata('permissions');
        /*if(in_array("view_role", $permission['_permissions']))
        {*/
            $data['title'] = "Roles";
            $data['page'] = "roles/roles/list";
            $data['extra_datatable_data'] = $this->external->datatable_extra_js_css();
            $data['roles'] = $this->roles->get_all_roles();
            $data['permission'] = $this->session->userdata('permissions');
            //show($data);
            $this->load->view('template', $data);
        /*}else{
            $this->session->set_flashdata('error','You dont have permission for this page.');
            redirect(site_url('dashboard'));
        }*/
    }

    public function add($action = "role") 
    {   
        $permission = $this->session->userdata('permissions');
        /*if(in_array("view_role", $permission['_permissions']) && in_array("add_roles", $permission['_permissions']))
        {*/
            if($action == "role") {
                self::add_role();
            } else if($action == "permission") {
                self::add_permission();
            } else {
                show_404();
            }
       /* }else{
            $this->session->set_flashdata('error','You dont have permission for this page.');
            redirect(site_url('dashboard'));
        }*/
    }

    public function edit($action = "role", $id = 0) {
        $permission = $this->session->userdata('permissions');
        /*if(in_array("view_role", $permission['_permissions']) && in_array("edit_role", $permission['_permissions']))
        {*/
            if($action == "role") {
                self::edit_role($id);
            } else if($action == "permission") {
                self::edit_permission($id);
            } else {
                show_404();
            }
        /*}else{
            $this->session->set_flashdata('error','You dont have permission for this page.');
            redirect(site_url('dashboard'));
        }*/
    }
    
    protected function add_role() 
    {
        
        $data['title'] = "Add Role";
        $data['permissions'] = $this->roles->get_all_permissions();
        $data['page'] = 'roles/roles/add';
        $this->load->view('template', $data);
    }

    public function do_add_role() 
    {   
        $permission = $this->session->userdata('permissions');
        /*if(in_array("view_role", $permission['_permissions']) && in_array("add_roles", $permission['_permissions']))
        {*/
            try {
                $this->form_validation->set_rules('role_name','Role Name','required');
                if (!$this->form_validation->run()) {
                    throw new Exception(validation_errors(), 1);
                }

                $info = $this->input->post(NULL,true);
                $info['created_by'] = $this->session->userdata('id');
                $rs = $this->roles->add_role($info);
                if(!$rs) {
                    throw new Exception("Some error occurred", 1);
                }
                $this->session->set_flashdata('success','Role added successfully');
                redirect(site_url('roles'));
            
            } catch (Exception $e) {
                $this->session->set_flashdata('error', $e->getMessage());
            }
            redirect(site_url('roles/add'));
        /*}else{
            $this->session->set_flashdata('error','You dont have permission for this page.');
            redirect(site_url('dashboard'));
        }*/
    }

    protected function edit_role($role_id = 0) 
    {
        $data['role'] = $this->roles->get_role($role_id);
        if(!$data['role']){
            $this->session->set_flashdata('error','Invalid selection');
            redirect(site_url('roles'));
        }
        //$this->minify->add_cdn('select2');
        $data['role_count'] = $this->roles->get_role_count();
        $data['current_role_level'] = $this->session->role_level ? $this->session->role_level : $data['role_count'];
        $data['assigned_perms'] = $this->roles->get_assigned_permissions($role_id);
        //$data['permissions'] = $this->roles->get_all_permissions();
        $data['permissions'] = $this->roles->permission_name();
        //echo "<pre>";print_r($data['assigned_perms']);die();
        //$this->minify->add_js('validator.js');
        $data['title'] = "Edit Role";
        $data['page'] = 'roles/roles/edit';
        $this->load->view('template', $data);
    }

    public function do_update_role() 
    {   
        $permission = $this->session->userdata('permissions');
        /*if(in_array("view_role", $permission['_permissions']) && in_array("edit_role", $permission['_permissions']))
        {*/
            try {
                $this->form_validation->set_rules('role_id','Role ID','required');
                $this->form_validation->set_rules('role_name','Role Name','required');
                $this->form_validation->set_rules('role_status','Role Status','required');
                //$this->form_validation->set_rules('role_level','Role Level','required|is_natural_no_zero');
                $this->form_validation->set_rules('role_desc','Role Description','trim');
                if (!$this->form_validation->run()) {
                    throw new Exception(validation_errors(), 1);
                }
                $info = $this->input->post(NULL,true);

                $data['role_count'] = $this->roles->get_role_count();
                /*$data['current_role_level'] = $this->session->role_level ? $this->session->role_level : $data['role_count'];
                if((int) $info['role_level'] < $data['current_role_level']) {
                    throw new Exception("You are not allowed to access requested role", 1);
                }*/
//                $info['slug'] = slug($info['role_name']);
                $info['created_by'] = $this->session->userdata('user_id');
                $rs = $this->roles->update_role($info);
                if($info['role_id'] == $this->session->role_id) {
                    $this->session->set_userdata(array(
                        'permissions' => $this->auth_lib->get_role_info($info['role_id']),
                        'role_level' => $info['role_level']
                    ));
                }
                if(!$rs) {
                    throw new Exception("Some error occurred", 1);
                }

                $this->session->set_flashdata('success','Role updated successfully');
                redirect(site_url('roles'));
            
            } catch (Exception $e) {
                $this->session->set_flashdata('error', $e->getMessage());            
            }
            redirect(site_url('roles/edit/role/'.$this->input->post('role_id')));
        /*}else{
            $this->session->set_flashdata('error','You dont have permission for this page.');
            redirect(site_url('dashboard'));
        }*/
    }

    public function do_delete_role() 
    {   
        $permission = $this->session->userdata('permissions');
        if(in_array("view_role", $permission['_permissions']) && in_array("delete_role", $permission['_permissions']))
        {
            $this->form_validation->set_rules('role_id','Role id','required|integer');
            if($this->form_validation->run()) {
                $info = $this->input->post(NULL,true);
                $info['role_status'] = STATUS_DELETED;
                $rs = $this->roles->do_delete_role($info);
                if($rs) {
                    return true;
                } else {
                    return false;
                }
            }
        }else{
            $this->session->set_flashdata('error','You dont have permission for this page.');
            redirect(site_url('dashboard'));
        }
    }
    
    /**
     * Permissions
     */


    public function permissions() 
    {   
        $permission = $this->session->userdata('permissions');
        /*if(in_array("permission", $permission['_permissions']))
        {*/
            $data['title'] = "Permissions";
            $data['page'] = "roles/permissions/list";
            $data['extra_datatable_data'] = $this->external->datatable_extra_js_css();
            $data['permissions'] = $this->roles->get_all_permissions();
            $data['permission'] = $this->session->userdata('permissions');
            $this->load->view('template',$data);
        /*}else{
            $this->session->set_flashdata('error','You dont have permission for this page.');
            redirect(site_url('dashboard'));
        }*/
    }



    protected function add_permission() 
    {
        //$permission = $this->session->userdata('permissions');
        /*if(in_array("permission", $permission['_permissions']) && in_array("add_permission", $permission['_permissions']))
        {*/
            //show("working");
            $this->load->library('controller_list');
            $data['modules'] = $this->controller_list->list_modules_from_db();
            $data['toast'] = true;
            $data['title'] = "Add Permission";
            $data['page'] = 'roles/permissions/add';
            $this->load->view('template', $data);
        /*}else{
            $this->session->set_flashdata('error','You dont have permission for this page.');
            redirect(site_url('dashboard'));
        }*/
    }

    protected function edit_permission($permission_id =0) 
    {   
        $permission = $this->session->userdata('permissions');
        /*if(in_array("permission", $permission['_permissions']) && in_array("edit_permission", $permission['_permissions']))
        {*/
            $data['raw_permission'] = $this->roles->get_permission($permission_id);
            if(!$data['raw_permission']){
                $this->session->set_flashdata('error','Invalid selection');
                redirect(site_url('roles'));
            }
            $data['permission'] = [];
            foreach ($data['raw_permission'] as $key => $perm) {
                if($key === 0) { $data['permission']  = $perm; }
                $data['permission']['modules'][] = $perm['module_id'];
                $data['permission']['module_names'][$perm['module_id']] = ucfirst($perm['module_name']);
                $data['permission']['methods'][] = $perm['method_id'];
            }
            $data['permission']['modules'] = array_unique($data['permission']['modules']);
            $this->load->library('controller_list');
            $data['modules'] = $this->controller_list->list_modules_from_db();
            $data['methods'] = [];
            foreach ($data['permission']['modules'] as $key => $module) {
                $data['methods'][$key]['method'] = $this->controller_list->list_methods_from_db($module);
                $data['methods'][$key]['module_id'] = $module;
            }
            //$this->minify->add_js('validator.js');
            //$this->minify->add_cdn('select2');
            //show($data);
            $data['toast'] = true;
            $data['title'] = "Edit Permission";
            $data['page'] = 'roles/permissions/edit';
            $this->load->view('template', $data);
        /*}else{
            $this->session->set_flashdata('error','You dont have permission for this page.');
            redirect(site_url('dashboard'));
        }*/
    }

    public function do_add_permission() 
    {   
        $permission = $this->session->userdata('permissions');
        /*if(in_array("permission", $permission['_permissions']) && in_array("add_permission", $permission['_permissions']))
        {*/
            $this->form_validation->set_rules('permission_name','Permission Name','required');
            $this->form_validation->set_rules('permission_status','Permission Status','required');
            $this->form_validation->set_rules('permission_desc','Permission Description','trim');
            $this->form_validation->set_rules('module[]','Module(s)','required');
            $this->form_validation->set_rules('method[]','Method(s)','required');
            if ($this->form_validation->run()) {
                $info = $this->input->post(NULL,true);
                //$info['slug'] = slug($info['permission_name']);
                $info['created_by'] = $this->session->userdata('id');
                $rs = $this->roles->add_permission($info);
                if($rs) {
                    $this->session->set_flashdata('success','Permission added successfully');
                    redirect(site_url('roles/permissions'));
                } else {
                    $this->session->set_flashdata('error','Some error occurred!');
                }
            } else {
                $this->session->set_flashdata('error',validation_errors());
            }
            redirect(site_url('roles/add/permission'));
        /*}else{
            $this->session->set_flashdata('error','You dont have permission for this page.');
            redirect(site_url('dashboard'));
        }*/
    }

    public function do_update_permission() 
    {   
        $permission = $this->session->userdata('permissions');
        /*if(in_array("permission", $permission['_permissions']) && in_array("edit_permission", $permission['_permissions']))
        {*/
            $this->form_validation->set_rules('permission_id','Permission ID','required');
            $this->form_validation->set_rules('permission_name','Permission Name','required');
            $this->form_validation->set_rules('permission_status','Permission Status','required');
            $this->form_validation->set_rules('permission_desc','Permission Description','trim');
            if ($this->form_validation->run()) {
                $info = $this->input->post(NULL,true);
                //$info['slug'] = slug($info['permission_name']);
                $info['created_by'] = $this->session->userdata('user_id');
                $rs = $this->roles->update_permission($info);
                if($rs) {
                    $this->session->set_flashdata('success','Permission updated successfully');
                    redirect(site_url('roles/permissions'));
                } else {
                    $this->session->set_flashdata('error','Some error occurred!');
                }
            } else {
                $this->session->set_flashdata('error',validation_errors());
            }
            redirect(site_url('roles/edit/permission/'.$this->input->post('permission_id')));
        /*}else{
            $this->session->set_flashdata('error','You dont have permission for this page.');
            redirect(site_url('dashboard'));
        }*/
    }

    // Manage Classes & Methods of TOKEiT
    public function refresh_modules() {
        $this->load->library('controller_list');
        $this->controller_list->refresh_modules();
        $response['status'] = true;
        $response['message'] = "Module refreshed";
        echo json_encode($response);
    }

    public function get_modules() {
        $this->load->library('controller_list');
        $modules = $this->controller_list->list_modules_from_db();
        if($modules) {
            $response['status'] = true;
            $response['response'] = $modules;
        } else {
            $response['status'] = false;
            $response['message'] = "Some error occurred";
        }
        echo json_encode($response);
    }

    public function get_methods() {
        $this->load->library('controller_list');
        $methods = $this->controller_list->list_methods_from_db($this->input->post('id'));
        if($methods) {
            $response['status'] = true;
            $response['response'] = $methods;
        } else {
            $response['status'] = false;
            $response['message'] = "No method found for the requested module";
        }
        echo json_encode($response);
    }

    public function change_status(){
        $post_data = $this->input->post();
        $data = $this->roles->change_status('roles', $this->input->post('status'), $this->input->post('number'));
        print_r($data);

    }

    public function delete($id = 0)
    {
        try {
            if(!$id) {
                throw new Exception('Choose a Role', 1);
            }
            $rs = $this->roles->do_delete($id);

            if(!$rs){
                throw new Exception("Error Processing Request", 1);   
            }

            $this->session->set_flashdata('success', 'Role is deleted successfully');
            redirect(site_url('roles'));

        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
            redirect(site_url('roles'));

        }
    }
}